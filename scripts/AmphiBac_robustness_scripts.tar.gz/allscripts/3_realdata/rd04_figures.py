"""Figures for the real-data track. Run from rd/ (inside a kernel with figure-style helpers if available)."""
import pandas as pd, numpy as np, pickle, matplotlib as mpl, matplotlib.pyplot as plt
from scipy import stats
try: apply_figure_style(sizes=(8, 7, 6))
except NameError: plt.rcParams.update({'font.size': 8, 'axes.spines.top': False, 'axes.spines.right': False})
INH, NOE, FAC = '#2166AC', '#E08214', '#7B3294'
S = pickle.load(open('out/summary.pkl', 'rb')); C = S['contrasts']
NAMES = {'Inhibitory_Proportion': 'Pipeline (Inhibitory, 99%)', 'Inhibitory_Proportion_seed2': 'Pipeline, rarefaction seed 2',
 'Inhibitory@0.97_Proportion': 'Inhibitory subset, 97%', 'Inhibitory@0.98_Proportion': 'Inhibitory subset, 98%',
 'Inhibitory@1.00_Proportion': 'Inhibitory subset, 100%', 'Inhibitory_strict_Proportion': 'InhibitoryStrict, 99%',
 'Majority_Proportion': 'Majority vote (>50% inhibitory)', 'Consensus75_Proportion': '≥75% isolates inhibitory',
 'Majority_BdLabel_Proportion': 'Majority vote, Bd_label', 'Exh_AnyInhibitory_Proportion': 'Any inhibitory isolate (exhaustive)',
 'ScoreWeighted_mean': 'Score-weighted (mean)', 'ScoreWeighted_median': 'Score-weighted (median)',
 'Inhibitory_over_Full': 'Inhibitory / Full matched reads', 'Full_Proportion': 'Cultured share (Full, pipeline)',
 'Exh_Cultured_Proportion': 'Cultured share (exhaustive)', 'Majority_Proportion@0.97': 'Majority vote, 97%',
 'ScoreWeighted_mean@0.97': 'Score-weighted (mean), 97%', 'Facilitating_Proportion': 'Facilitating subset, 99%'}
out = []
# ---- Fig 1: baseline vs alternatives, both datasets
alts = ['Inhibitory@0.97_Proportion', 'Inhibitory_strict_Proportion', 'Majority_Proportion', 'Consensus75_Proportion', 'ScoreWeighted_mean', 'Full_Proportion']
fig, axs = plt.subplots(2, 6, figsize=(7.2, 3.3), constrained_layout=True)
for r, ds in enumerate(['meta', 'bf']):
    df = pd.read_csv(f'out/{ds}_per_sample_methods.csv', index_col=0); n = len(df)
    for c, a in enumerate(alts):
        ax = axs[r, c]; ok = df[a].notna()
        ax.scatter(df.loc[ok, 'Inhibitory_Proportion'], df.loc[ok, a], s=2 if ds == 'meta' else 6, alpha=.25 if ds == 'meta' else .8, color=INH, lw=0)
        if a != 'ScoreWeighted_mean': ax.plot([0, 1], [0, 1], color='0.6', lw=.6, ls='--'); ax.set_ylim(-.03, 1.03)
        else: ax.set_ylim(-5, 105)
        ax.set_xlim(-.03, 1.03 if ds == 'meta' else .6)
        rho = stats.spearmanr(df.loc[ok, 'Inhibitory_Proportion'], df.loc[ok, a])[0]
        ax.text(.04, .96, f'ρ={rho:.2f}', transform=ax.transAxes, va='top', fontsize=7)
        if r == 0: ax.set_title({'Inhibitory@0.97_Proportion':'Inhibitory\n97%','Inhibitory_strict_Proportion':'InhibitoryStrict\n99%','Majority_Proportion':'Majority vote\n(>50% inhib.)','Consensus75_Proportion':'Consensus\n(≥75% inhib.)','ScoreWeighted_mean':'Score-weighted\nmean (0–100)','Full_Proportion':'Cultured share\n(Full, 99%)'}[a], fontsize=7, loc='left')
        if c == 0: ax.set_ylabel(('Meta-analysis' if ds == 'meta' else 'Bullfrog') + f' (n={n})\nalternative metric')
        if r == 1: ax.set_xlabel('Pipeline inhib.\nproportion')
fig.suptitle('Per-sample inhibitory metrics vs the pipeline output (Inhibitory subset, 99% id); dashed = 1:1; score axis 0–100', fontsize=7)
fig.savefig('out/fig_rd1_method_scatter.png', dpi=300); out.append('out/fig_rd1_method_scatter.png'); plt.close(fig)
# ---- Fig 2: Spearman heatmap of all methods vs baseline + shift stats
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.6), constrained_layout=True, sharey=True)
for ax, ds in zip(axs, ['meta', 'bf']):
    cm = S[ds]['comparisons'].set_index('method')
    order = list(cm.index); y = np.arange(len(order))
    ax.barh(y, cm.spearman_rho, color=INH, height=.6)
    ax.axvline(0, color='k', lw=.6)
    for i, m in enumerate(order):
        q = cm.loc[m, 'pct_quartile_change']; sh = cm.loc[m, 'pct_shift_gt_X']
        lab = f'Δq {q:.0f}%' + ('' if np.isnan(sh) else f'; >{S[ds]["shift_X"]:.2f}: {sh:.0f}%')
        ax.text(max(cm.loc[m, 'spearman_rho'], 0) + .02, i, lab, va='center', fontsize=6)
    ax.set_yticks(y, [NAMES[m] for m in order]); ax.invert_yaxis(); ax.set_xlim(-.1, 1.75); ax.set_xticks([0, .5, 1])
    ax.set_xlabel('Spearman ρ with pipeline output')
    ax.set_title(f"{'Meta-analysis' if ds == 'meta' else 'Bullfrog'} (n={S[ds]['n_samples']}, depth {S[ds]['depth']})", loc='left')
fig.suptitle('Rank agreement with the pipeline; Δq = % samples changing quartile; >X = % samples shifting by more than X in proportion', fontsize=7)
fig.savefig('out/fig_rd2_rank_agreement.png', dpi=300); out.append('out/fig_rd2_rank_agreement.png'); plt.close(fig)
# ---- Fig 3: contrast effect sizes by method
ms = ['Inhibitory_Proportion', 'Inhibitory_Proportion_seed2', 'Inhibitory@0.97_Proportion', 'Inhibitory@0.98_Proportion', 'Inhibitory_strict_Proportion',
      'Majority_Proportion', 'Consensus75_Proportion', 'Majority_BdLabel_Proportion', 'ScoreWeighted_mean', 'ScoreWeighted_median', 'Inhibitory_over_Full']
cons = [c for c in C.contrast.unique() if 'KW' not in c]
TT = {'lifestage': ('Adult', 'Larvae'), 'country': ('Madagascar', 'USA'), 'host_scientific_name': ('$A.\\ boreas$', '$L.\\ catesbeianus$')}
fig, axs = plt.subplots(1, 3, figsize=(7.2, 3.4), sharey=True, gridspec_kw=dict(wspace=0.08))
fig.subplots_adjust(left=0.25, right=0.99, top=0.82, bottom=0.2)
for ax, ct in zip(axs, cons):
    d = C[(C.contrast == ct)].set_index('method').loc[ms]; y = np.arange(len(ms)); sig = (d.p_MWU < 0.05).values
    ax.axvline(0, color='0.5', lw=.6)
    ax.scatter(d.rank_biserial[sig], y[sig], color=INH, s=18, zorder=3, label='p < 0.05')
    ax.scatter(d.rank_biserial[~sig], y[~sig], facecolor='white', edgecolor=INH, s=18, zorder=3, label='p ≥ 0.05')
    for i, p in enumerate(d.p_MWU): ax.text(1.0, i, f'{p:.0e}' if p < 1e-3 else f'{p:.2f}', va='center', ha='left', fontsize=6)
    a, b = TT[ct.split(':')[0]]; na, nb = int(d.n_a.iloc[0]), int(d.n_b.iloc[0])
    ax.set_title(f'{a} (n={na})\nvs {b} (n={nb})', loc='left');
    ax.set_xlim(-.3, 1.3); ax.set_xticks([-.25, 0, .25, .5, .75]); ax.set_xlabel('Rank-biserial r')
axs[0].set_yticks(np.arange(len(ms)), [NAMES[m] for m in ms]); axs[0].invert_yaxis()
axs[0].legend(loc='upper left', frameon=False, fontsize=6, bbox_to_anchor=(-0.9, -0.1), ncol=2)
fig.suptitle('Meta-analysis contrasts under each inhibitory metric (r > 0: first-named group higher; numbers = Mann–Whitney p)', fontsize=8)
fig.savefig('out/fig_rd3_contrasts_by_method.png', dpi=300); out.append('out/fig_rd3_contrasts_by_method.png'); plt.close(fig)
# ---- Fig 4: where pipeline-'inhibitory' reads come from
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.6), constrained_layout=True)
bins = [-0.01, 0.25, 0.5 - 1e-9, 0.5, 0.75 - 1e-9, 1.0]; labs = ['<25%', '25–<50%', '50% (tie)', '>50–<75%', '≥75%']
cols = [NOE, '#F1B26A', '0.75', '#92C5DE', INH]
for k, ds in enumerate(['meta', 'bf']):
    L = pd.read_csv(f'out/{ds}_feature_labels.csv', index_col=0); L = L[L.pipeline_inhibitory_ref.notna() & (L.reads_rarefied_s1 > 0)]
    cut = pd.cut(L.frac_inh, bins, labels=labs); rd = L.reads_rarefied_s1.groupby(cut, observed=False).sum(); fc = cut.value_counts().reindex(labs)
    left = 0
    for lab, col in zip(labs, cols):
        v = rd[lab] / rd.sum() * 100; ax = axs[0]
        ax.barh(k, v, left=left, color=col, edgecolor='white', lw=.5, label=lab if k == 0 else None)
        if v > 6: ax.text(left + v / 2, k, f'{v:.0f}%', ha='center', va='center', fontsize=6, color='white' if col in (NOE, INH) else 'k')
        left += v
        axs[1].bar(labs.index(lab) + (k - .5) * .38, fc[lab], width=.38, color=col, edgecolor='k' if k else 'none', hatch='///' if k else None, lw=.4)
axs[0].set_yticks([0, 1], [f'Meta-analysis\n({int(S["meta"]["inh_reads_total"]/1e3)}k reads)', f'Bullfrog\n({S["bf"]["inh_reads_total"]:,} reads)']); axs[0].invert_yaxis()
axs[0].set_xlabel('% of pipeline-"inhibitory" reads'); axs[0].set_xlim(0, 100)
axs[0].legend(title='Inhibitory share of ≥99%-identical\ntested isolates (exhaustive)', ncol=5, fontsize=6, title_fontsize=6, frameon=False, loc='lower center', bbox_to_anchor=(.5, 1.0))
axs[1].set_xticks(range(5), labs, rotation=30); axs[1].set_ylabel('Matched features (n)')
axs[1].set_title('Features (solid = meta, hatched = bullfrog)', loc='left', fontsize=7)
fig.savefig('out/fig_rd4_inhibitory_read_composition.png', dpi=300); out.append('out/fig_rd4_inhibitory_read_composition.png'); plt.close(fig)
print(out)
