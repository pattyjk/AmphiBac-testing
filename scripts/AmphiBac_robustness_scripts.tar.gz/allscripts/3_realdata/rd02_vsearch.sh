#!/bin/bash
# Pipeline-equivalent closed-ref (exact q2-vsearch call) for 4 subsets x 4 thresholds x 2 datasets,
# plus exhaustive Full-db search (maxaccepts 0 / maxrejects 0) at id>=0.97 for label-consensus methods.
set -e; cd "$(dirname "$0")/../work"; mkdir -p uc
for ds in meta bf; do
 for mode in FullDatabase Inhibitory InhibitoryStrict Facilitating; do
  for id in 0.97 0.98 0.99 1.00; do
   vsearch --usearch_global ${ds}_query.fasta --id $id --db ../db/${mode}_2025.1.fasta --uc uc/${ds}_${mode}_${id}.uc \
     --strand both --qmask none --notmatched uc/${ds}_${mode}_${id}_unmatched.fasta --threads 12 --minseqlength 1 --fasta_width 0 --quiet
  done; done
 vsearch --usearch_global ${ds}_query.fasta --id 0.97 --db ../db/FullDatabase_2025.1.fasta --userout uc/${ds}_exhaustive_full_097.tsv \
   --userfields query+target+id+alnlen+qcov --strand both --qmask none --maxaccepts 0 --maxrejects 0 --threads 12 --minseqlength 1 --quiet
done
echo DONE
