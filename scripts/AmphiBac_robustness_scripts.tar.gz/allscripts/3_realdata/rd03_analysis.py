"""Real-data track step 1b+2: pipeline-equivalent outputs and alternative inhibitory metrics.
Inputs: work/ (from rd01_prepare.py, rd02_vsearch.sh), db/audit_per_sequence.csv, map file (argv[1]).
Outputs: out/*.csv, out/summary.pkl"""
import numpy as np, pandas as pd, scipy.sparse as sp, pickle, os, sys
from scipy import stats
MAP = sys.argv[1]; os.makedirs('out', exist_ok=True)
MODES = {'full': 'FullDatabase', 'inhibitory': 'Inhibitory', 'inhibitory_strict': 'InhibitoryStrict', 'facilitating': 'Facilitating'}
IDS = ['0.97', '0.98', '0.99', '1.00']
aud = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
TESTED = {'Inhibitory', 'NoEffect', 'Facilitating'}

def rarefy(M, depth, seed):
    rng = np.random.default_rng(seed); M = M.tocsc(); rows, cols, vals = [], [], []
    for j in range(M.shape[1]):
        s, e = M.indptr[j], M.indptr[j+1]; c = M.data[s:e].astype(np.int64)
        if c.sum() < depth: continue
        d = rng.multivariate_hypergeometric(c, depth); k = d > 0
        rows.append(M.indices[s:e][k]); cols.append(np.full(k.sum(), j)); vals.append(d[k])
    return sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=M.shape)

def read_uc(path):
    u = pd.read_csv(path, sep='\t', header=None, usecols=[0, 8, 9], names=['t', 'q', 'r'])
    u = u[u.t == 'H']; return dict(zip(u.q.str.split(';').str[0], u.r.astype(str).str.split().str[0]))

def load(ds):
    if ds == 'meta':
        feats = pd.read_csv('work/meta_features.csv').fid.tolist()
        samples = pd.read_csv('work/meta_samples.csv', header=None)[0].tolist(); depth = 1000
        R = {s: sp.load_npz(f'work/meta_rare_s{s}.npz').tocsr() for s in (1, 2)}
    else:
        bf = pd.read_csv('work/bf_raw.csv', index_col=0); bf = bf.loc[:, bf.sum(axis=0) >= 10]
        depth = int(bf.sum(axis=0).min()); feats = bf.index.tolist(); samples = bf.columns.tolist()
        M = sp.csc_matrix(bf.values.round().astype(np.int64))
        R = {s: rarefy(M, depth, s).tocsr() for s in (1, 2)}
    return feats, samples, depth, R

def pipeline_outputs(R, feats, hit, depth, prefix):
    """Total, Proportion, Richness(=distinct refs present), FeatRichness(=matched query features present)."""
    fi = {f: i for i, f in enumerate(feats)}
    pairs = [(fi[q], r) for q, r in hit.items() if q in fi]
    refs = sorted({r for _, r in pairs}); ri = {r: i for i, r in enumerate(refs)}
    A = sp.csr_matrix((np.ones(len(pairs)), ([ri[r] for _, r in pairs], [i for i, _ in pairs])), shape=(len(refs), len(feats)))
    C = A @ R  # clustered table refs x samples
    tot = np.asarray(C.sum(0)).ravel()
    out = {f'{prefix}_Total': tot, f'{prefix}_Proportion': tot / depth,
           f'{prefix}_Richness': np.asarray((C > 0).sum(0)).ravel(),
           f'{prefix}_FeatRichness': np.asarray((R[[i for i, _ in pairs]] > 0).sum(0)).ravel() if pairs else 0}
    return out, len(pairs), len(refs)

def feature_labels(ds, feats, t):
    """Exhaustive Full-db hits with id >= t (vsearch iddef2 %, as reported in userout)."""
    ex = pd.read_csv(f'work/uc/{ds}_exhaustive_full_097.tsv', sep='\t', header=None, names=['q', 'r', 'id', 'alnlen', 'qcov'])
    ex['q'] = ex.q.str.split(';').str[0]; ex = ex[ex.id >= t * 100 - 1e-9]
    ex = ex.join(aud[['Func', 'Bd_label', 'score']], on='r')
    g = ex.groupby('q')
    L = pd.DataFrame({'n_qual': g.size(),
                      'n_tested': g.Func.apply(lambda s: s.isin(TESTED).sum()),
                      'n_inh': g.Func.apply(lambda s: (s == 'Inhibitory').sum()),
                      'n_fac': g.Func.apply(lambda s: (s == 'Facilitating').sum()),
                      'n_bdlab': g.Bd_label.apply(lambda s: s.notna().sum()),
                      'n_bdinh': g.Bd_label.apply(lambda s: (s == 'Inhibitory').sum()),
                      'score_mean': g.score.mean(), 'score_median': g.score.median(), 'n_scored': g.score.count()})
    L['frac_inh'] = L.n_inh / L.n_tested.replace(0, np.nan)
    L['frac_bdinh'] = L.n_bdinh / L.n_bdlab.replace(0, np.nan)
    return L.reindex(feats)

def sample_metrics(R, L, depth, sfx):
    o = {}
    def prop(mask):
        return np.asarray(R[np.where(mask)[0]].sum(0)).ravel() / depth
    fi = L.frac_inh.values; fb = L.frac_bdinh.values
    o[f'Exh_Cultured_Proportion{sfx}'] = prop(L.n_qual.notna().values)
    o[f'Exh_AnyInhibitory_Proportion{sfx}'] = prop(L.n_inh.fillna(0).values > 0)
    o[f'Majority_Proportion{sfx}'] = prop(np.nan_to_num(fi) > 0.5)
    o[f'Consensus75_Proportion{sfx}'] = prop(np.nan_to_num(fi) >= 0.75)
    o[f'Majority_BdLabel_Proportion{sfx}'] = prop(np.nan_to_num(fb) > 0.5)
    for k in ('mean', 'median'):
        s = L[f'score_{k}'].values; ok = ~np.isnan(s)
        num = np.asarray(R[np.where(ok)[0]].T @ s[ok]).ravel(); den = np.asarray(R[np.where(ok)[0]].sum(0)).ravel()
        with np.errstate(invalid='ignore', divide='ignore'): o[f'ScoreWeighted_{k}{sfx}'] = num / den
    o[f'Scored_Proportion{sfx}'] = prop(L.score_mean.notna().values)
    return o

def quart(x):
    r = pd.Series(x).rank(method='average'); return np.clip(np.ceil(4 * r / r.notna().sum()), 1, 4)

summary = {}
for ds in ('meta', 'bf'):
    feats, samples, depth, R = load(ds); S = {}
    hits = {(m, t): read_uc(f'work/uc/{ds}_{MODES[m]}_{t}.uc') for m in MODES for t in IDS}
    collapse = []
    for seed in (1, 2):
        for m in MODES:
            for t in IDS:
                pre = m.capitalize() if (t == '0.99') else f'{m.capitalize()}@{t}'
                o, nf, nr = pipeline_outputs(R[seed], feats, hits[(m, t)], depth, pre)
                if seed == 1:
                    S.update(o)
                    present = np.asarray(R[1].sum(1)).ravel() > 0
                    fi = {f: i for i, f in enumerate(feats)}
                    hp = {q: r for q, r in hits[(m, t)].items() if present[fi[q]]}
                    collapse.append(dict(dataset=ds, mode=m, perc_identity=t, query_features_in_table=int(present.sum()),
                                         features_matched_all=nf, refs_matched_all=nr,
                                         features_matched_rarefied=len(hp), refs_matched_rarefied=len(set(hp.values()))))
                elif t == '0.99':
                    S.update({k + '_seed2': v for k, v in o.items()})
    Lab = {t: feature_labels(ds, feats, t) for t in (0.99, 0.97)}
    for t, L in Lab.items():
        S.update(sample_metrics(R[1], L, depth, '' if t == 0.99 else '@0.97'))
    S.update({k + '_seed2': v for k, v in sample_metrics(R[2], Lab[0.99], depth, '').items() if k.startswith(('Majority_P', 'ScoreWeighted_mean'))})
    df = pd.DataFrame(S, index=pd.Index(samples, name='SampleID'))
    with np.errstate(invalid='ignore', divide='ignore'):
        df['Inhibitory_over_Full'] = df.Inhibitory_Total / df.Full_Total
    df.insert(0, 'rarefying_depth', depth)
    # feature-level table
    fi = {f: i for i, f in enumerate(feats)}; L = Lab[0.99].copy()
    L['pipeline_inhibitory_ref'] = pd.Series(hits[('inhibitory', '0.99')]); L['pipeline_full_ref'] = pd.Series(hits[('full', '0.99')])
    L['pipeline_strict_ref'] = pd.Series(hits[('inhibitory_strict', '0.99')])
    L['reads_rarefied_s1'] = np.asarray(R[1].sum(1)).ravel()
    L.index.name = 'feature'
    # inhibitory reads from mostly non-inhibitory features
    inh = L.pipeline_inhibitory_ref.notna()
    rd_inh = L.loc[inh, 'reads_rarefied_s1']; fr = L.loc[inh, 'frac_inh']
    Rin = R[1][[fi[f] for f in L.index[inh]]]
    mostly_non = (fr < 0.5).values; half = (fr == 0.5).values
    per_s = np.asarray(Rin[np.where(mostly_non)[0]].sum(0)).ravel() / np.maximum(np.asarray(Rin.sum(0)).ravel(), 1)
    has = np.asarray(Rin.sum(0)).ravel() > 0
    summary[ds] = dict(depth=depth, n_samples=len(samples), collapse=collapse,
        inh_features=int(inh.sum()), inh_features_present=int((rd_inh > 0).sum()),
        inh_reads_total=int(rd_inh.sum()), inh_reads_from_mostly_noninh=int(rd_inh[mostly_non].sum()),
        inh_reads_from_tie=int(rd_inh[half].sum()), inh_feats_mostly_noninh_present=int(((rd_inh > 0).values & mostly_non).sum()),
        per_sample_median_frac_mostly_noninh=float(np.median(per_s[has])), n_samples_with_inh=int(has.sum()),
        frac_inh_dist_reads=pd.cut(fr, [-0.01, 0.25, 0.5 - 1e-9, 0.5, 0.75 - 1e-9, 1.0]).pipe(lambda c: rd_inh.groupby(c, observed=False).sum()).to_dict())
    # comparisons vs baseline
    base = 'Inhibitory_Proportion'
    noise = np.abs(df[base] - df[base + '_seed2']); X = max(0.05, float(np.quantile(noise, 0.95)))
    alts = ['Inhibitory@0.97_Proportion', 'Inhibitory@0.98_Proportion', 'Inhibitory@1.00_Proportion', 'Inhibitory_strict_Proportion',
            'Majority_Proportion', 'Consensus75_Proportion', 'Majority_BdLabel_Proportion', 'Exh_AnyInhibitory_Proportion',
            'ScoreWeighted_mean', 'ScoreWeighted_median', 'Inhibitory_over_Full', 'Full_Proportion', 'Exh_Cultured_Proportion',
            'Majority_Proportion@0.97', 'ScoreWeighted_mean@0.97', base + '_seed2']
    rows = []; qb = quart(df[base])
    for a in alts:
        ok = df[[base, a]].notna().all(axis=1)
        rho, p = stats.spearmanr(df.loc[ok, base], df.loc[ok, a])
        same_scale = a.endswith('Proportion') or a.endswith('_seed2') or a.endswith('@0.97') and 'Majority' in a
        d = (df[a] - df[base]).abs()
        rows.append(dict(dataset=ds, method=a, n=int(ok.sum()), spearman_rho=rho, spearman_p=p,
                         median_value=df[a].median(), mean_value=df[a].mean(),
                         shift_threshold=X if same_scale else np.nan,
                         n_shift_gt_X=int((d[ok] > X).sum()) if same_scale else np.nan,
                         pct_shift_gt_X=100 * (d[ok] > X).mean() if same_scale else np.nan,
                         n_quartile_change=int((quart(df[a])[ok.values] != qb[ok.values]).sum()),
                         pct_quartile_change=100 * (quart(df[a])[ok.values] != qb[ok.values]).mean()))
    summary[ds].update(shift_X=X, noise_p95=float(np.quantile(noise, 0.95)), noise_median=float(np.median(noise)), comparisons=pd.DataFrame(rows))
    summary[ds]['spearman_matrix'] = df[[base] + alts[:-1]].corr(method='spearman')
    df.to_csv(f'out/{ds}_per_sample_methods.csv'); L.to_csv(f'out/{ds}_feature_labels.csv')

# ---- meta-analysis biological contrasts
mp = pd.read_csv(MAP, sep='\t', dtype=str).set_index('#SampleID')
df = pd.read_csv('out/meta_per_sample_methods.csv', index_col=0).join(mp[['lifestage', 'country', 'host_scientific_name', 'doi']])
methods = ['Inhibitory_Proportion', 'Inhibitory_Proportion_seed2', 'Inhibitory@0.97_Proportion', 'Inhibitory@0.98_Proportion', 'Inhibitory@1.00_Proportion',
           'Inhibitory_strict_Proportion', 'Majority_Proportion', 'Consensus75_Proportion', 'Majority_BdLabel_Proportion',
           'ScoreWeighted_mean', 'ScoreWeighted_median', 'Inhibitory_over_Full', 'Full_Proportion', 'Facilitating_Proportion']
contrasts = [('lifestage', 'adult', 'larvae'), ('country', 'madagascar', 'usa'), ('host_scientific_name', 'anaxyrus boreas', 'lithobates catesbeianus')]
crow = []
for col, a, b in contrasts:
    for m in methods:
        x = df.loc[df[col] == a, m].dropna(); y = df.loc[df[col] == b, m].dropna()
        U, p = stats.mannwhitneyu(x, y, alternative='two-sided')
        crow.append(dict(contrast=f'{col}: {a} vs {b}', method=m, n_a=len(x), n_b=len(y), median_a=x.median(), median_b=y.median(),
                         mean_a=x.mean(), mean_b=y.mean(), rank_biserial=2 * U / (len(x) * len(y)) - 1, p_MWU=p))
for m in methods:
    g = [df.loc[df.lifestage == s, m].dropna() for s in ('adult', 'juvenile_pupae', 'larvae')]
    H, p = stats.kruskal(*g)
    crow.append(dict(contrast='lifestage: adult/juvenile_pupae/larvae (KW)', method=m, n_a=len(g[0]), n_b=len(g[2]), median_a=g[0].median(), median_b=g[2].median(),
                     mean_a=g[0].mean(), mean_b=g[2].mean(), rank_biserial=np.nan, p_MWU=p, KW_H=H, n_juv=len(g[1]), median_juv=g[1].median()))
C = pd.DataFrame(crow); C['sig_0.05'] = C.p_MWU < 0.05; C['direction'] = np.sign(C.median_a - C.median_b).where(C.median_a != C.median_b, np.sign(C.mean_a - C.mean_b))
C.to_csv('out/meta_contrasts.csv', index=False); summary['contrasts'] = C
pickle.dump(summary, open('out/summary.pkl', 'wb'))
for ds in ('meta', 'bf'):
    s = summary[ds]; print(ds, {k: v for k, v in s.items() if k not in ('collapse', 'comparisons', 'spearman_matrix', 'frac_inh_dist_reads')})
