"""Build xlsx summary for the real-data track. Run from rd/ after rd03."""
import pandas as pd, numpy as np, pickle
S = pickle.load(open('out/summary.pkl', 'rb'))
def rd(p):
    u = pd.read_csv(p, sep='\t', header=None, usecols=[0, 8, 9]); u = u[u[0] == 'H']; return dict(zip(u[8].str.split(';').str[0], u[9]))
rows = []
for ds in ('meta', 'bf'):
    L = pd.read_csv(f'out/{ds}_feature_labels.csv', index_col=0); inh = L.pipeline_inhibitory_ref.notna(); r = L.reads_rarefied_s1
    both = inh & L.pipeline_fac_ref.notna(); s = S[ds]
    rows += [dict(dataset=ds, metric=k, value=v) for k, v in {
        'n_samples': s['n_samples'], 'rarefying_depth': s['depth'], 'pipeline_inhibitory_matched_features': s['inh_features'],
        'pipeline_inhibitory_reads_(rarefied_seed1)': s['inh_reads_total'],
        'reads_from_features_with_<50%_inhibitory_isolates': s['inh_reads_from_mostly_noninh'],
        'pct_reads_from_features_with_<50%_inhibitory_isolates': 100 * s['inh_reads_from_mostly_noninh'] / s['inh_reads_total'],
        'reads_from_features_with_exactly_50%': s['inh_reads_from_tie'],
        'per_sample_median_frac_inh_reads_from_<50%_features': s['per_sample_median_frac_mostly_noninh'],
        'pipeline_inhibitory_features_also_hitting_Facilitating_subset': int(both.sum()),
        'pct_inhibitory_reads_also_hitting_Facilitating_subset': 100 * r[both].sum() / r[inh].sum(),
        'pct_inhibitory_reads_top_feature': 100 * r[inh].max() / r[inh].sum(),
        'rarefaction_noise_|seed1-seed2|_median': s['noise_median'], 'rarefaction_noise_p95': s['noise_p95'], 'shift_threshold_X': s['shift_X']}.items()]
with pd.ExcelWriter('out/realdata_impact_summary.xlsx') as w:
    pd.DataFrame({'sheet': ['headline', 'comparisons', 'contrasts', 'ref_collapse', 'spearman_meta', 'spearman_bf', 'inh_read_composition'],
                  'content': ['Headline numbers per dataset', 'Each alternative metric vs pipeline Inhibitory_Proportion (99%): Spearman, shifts >X, quartile changes',
                              'Meta-analysis Mann-Whitney / Kruskal-Wallis contrasts under each metric', 'Query features vs distinct reference IDs matched (richness collapse)',
                              'Spearman matrix (meta)', 'Spearman matrix (bullfrog)', 'Pipeline-inhibitory reads binned by inhibitory share of qualifying isolates']}).to_excel(w, sheet_name='README', index=False)
    pd.DataFrame(rows).to_excel(w, sheet_name='headline', index=False)
    pd.concat([S[d]['comparisons'] for d in ('meta', 'bf')]).to_excel(w, sheet_name='comparisons', index=False)
    S['contrasts'].to_excel(w, sheet_name='contrasts', index=False)
    pd.DataFrame(S['meta']['collapse'] + S['bf']['collapse']).to_excel(w, sheet_name='ref_collapse', index=False)
    S['meta']['spearman_matrix'].round(3).to_excel(w, sheet_name='spearman_meta'); S['bf']['spearman_matrix'].round(3).to_excel(w, sheet_name='spearman_bf')
    pd.DataFrame([dict(dataset=d, bin=str(k), reads=v) for d in ('meta', 'bf') for k, v in S[d]['frac_inh_dist_reads'].items()]).to_excel(w, sheet_name='inh_read_composition', index=False)
print(pd.DataFrame(rows).to_string())
