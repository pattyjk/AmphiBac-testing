"""AmphiBac 2025.1 database audit: lengths, ambiguity codes, V4 coverage, label conflicts among identical sequences."""
import re, pandas as pd, numpy as np, collections
def rf(p):
    d={};k=None
    for l in open(p):
        l=l.strip()
        if l.startswith('>'): k=l[1:].split()[0]; d[k]=[]
        elif k: d[k].append(l)
    return {k:''.join(v).upper() for k,v in d.items()}
mods=['FullDatabase','Inhibitory','InhibitoryStrict','Facilitating']
S={m:rf(f'db/{m}_2025.1.fasta') for m in mods}
full=S['FullDatabase']
md=pd.read_csv('AmphiBac-2025.1/metadata/AmphibBac_Metadata_2025.1.tsv',sep='\t',low_memory=False).set_index('FastaID')
# --- labels
def bdlab(x):
    if pd.isna(x): return 'NA'
    x=str(x).strip().lower()
    if x.startswith('inhib'): return 'Inhibitory'
    if x in ('noninhibitory','noeffect','no effect','non-inhibitor','ns'): return 'NonInhibitory'
    if x in ('facilitating','enhancing'): return 'Facilitating'
    return 'NA'
md['Bd_label']=md['Bd.Inhibition'].map(bdlab)
md['Func']=md['AntiFungal.Function.with.AP.function']
md['score']=(1-pd.to_numeric(md['Proportional.Growth.Bd'],errors='coerce'))*100
for m in mods: md['in_'+m]=md.index.isin(list(S[m]))
# --- sequence properties
F515=re.compile('GTG[CT]CAGC[AC]GCCGCGGTAA'); R806rc=re.compile('ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC')
rows=[]
for k,s in full.items():
    f=F515.search(s); r=R806rc.search(s)
    rc=s[::-1].translate(str.maketrans('ACGTRYKMSWBDHVN','TGCAYRMKSWVHDBN'))
    strand='+'
    if not f and F515.search(rc): s2=rc; f=F515.search(rc); r=R806rc.search(rc); strand='-'
    else: s2=s
    amb=sum(c not in 'ACGT' for c in s)
    v4start=f.end() if f else None
    v4len=(r.start()-f.end()) if (f and r and r.start()>f.end()) else None
    after515=len(s2)-f.end() if f else None
    rows.append(dict(FastaID=k,length=len(s),n_ambig=amb,n_N=s.count('N'),strand_in_db=strand if f else 'NA',
                     has_515F=bool(f),has_806R=bool(r and f and r.start()>f.end()),V4_len=v4len,bp_after_515F=after515))
A=pd.DataFrame(rows).set_index('FastaID').join(md[['Bd_label','Func','score','Assay.Method','Sequencing.Primers','Reference','Bd.Inhibition','Bsal.Inhibition']+['in_'+m for m in mods]])
# a 'V4 class': how much of a 515F-start fragment the reference covers
def cov(x):
    if not x['has_515F']: return 'no 515F site'
    a=x['bp_after_515F']
    return '>=253 bp' if a>=253 else ('150-252 bp' if a>=150 else ('90-149 bp' if a>=90 else '<90 bp'))
A['V4_coverage']=A.apply(cov,axis=1)
A.to_csv('out/audit_per_sequence.csv')
# --- identical sequence groups (exact full-length) and exact V4-90/120/253 groups
def frag(k,L):
    x=A.loc[k]
    if not x['has_515F'] or x['bp_after_515F']<L: return None
    s=full[k]
    f=F515.search(s)
    if not f:
        s=s[::-1].translate(str.maketrans('ACGTRYKMSWBDHVN','TGCAYRMKSWVHDBN')); f=F515.search(s)
    return s[f.end():f.end()+L]
grp=[]
for L in [90,120,150,253]:
    fr={k:frag(k,L) for k in A.index}; fr={k:v for k,v in fr.items() if v}
    g=collections.defaultdict(list)
    for k,v in fr.items(): g[v].append(k)
    for v,ks in g.items():
        labs=A.loc[ks,'Bd_label']; labs=labs[labs!='NA']
        grp.append(dict(L=L,seq=v,n=len(ks),n_labelled=len(labs),n_inh=(labs=='Inhibitory').sum(),n_non=(labs=='NonInhibitory').sum(),n_fac=(labs=='Facilitating').sum(),
                        n_func_inh=(A.loc[ks,'Func']=='Inhibitory').sum(),n_studies=A.loc[ks,'Reference'].nunique()))
G=pd.DataFrame(grp)
G['conflict']=(G[['n_inh','n_non','n_fac']]>0).sum(axis=1)>1
G.to_csv('out/audit_identical_V4_groups.csv',index=False)
# --- what InhibitoryStrict removed
inh=set(S['Inhibitory']); strict=set(S['InhibitoryStrict']); fac=set(S['Facilitating'])
removed=inh-strict; added=strict-inh
facseqs=set(full[k] for k in fac)
summ={
 'n_full':len(full),'n_inhibitory':len(inh),'n_strict':len(strict),'n_fac':len(fac),
 'strict_not_in_inhibitory':len(added),'removed_by_strict':len(removed),
 'removed_identical_fulllength_to_facilitating':sum(full[k] in facseqs for k in removed),
 'strict_retained_identical_fulllength_to_facilitating':sum(full[k] in facseqs for k in strict),
}
print(summ)
print(A['V4_coverage'].value_counts().to_string())
print(A.groupby('V4_coverage')['Bd_label'].value_counts().unstack().to_string())
print('length quantiles',A.length.quantile([0,.05,.25,.5,.75,.95,1]).to_dict())
print('ambig seqs',(A.n_ambig>0).sum(),'N seqs',(A.n_N>0).sum(),'max ambig',A.n_ambig.max())
print('strand rc in db', (A.strand_in_db=='-').sum())
for L in [90,120,253]:
    g=G[(G.L==L)&(G.n_labelled>=2)]
    print(L,'groups>=2 labelled',len(g),'conflicting',g.conflict.sum(),'isolates in conflicting groups',g[g.conflict].n.sum())
pd.Series(summ).to_csv('out/audit_subset_summary.csv')
