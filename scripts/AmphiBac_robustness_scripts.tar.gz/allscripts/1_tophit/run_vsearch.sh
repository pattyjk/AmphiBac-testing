#!/bin/bash
# Battery of vsearch runs emulating q2-vsearch cluster-features-closed-reference (0.99, strand both)
set -e
cd "$(dirname "$0")"
F="userout_fields=query+target+id+alnlen+mism+gaps+qcov+tcov+qilo+qihi+tilo+tihi+ql+tl"
UF=query+target+id+alnlen+mism+gaps+qcov+tcov+qilo+qihi+tilo+tihi+ql+tl
q2(){ # q2 exact: $1 query $2 db $3 out-prefix [$4 extra]
 vsearch --usearch_global $1 --id ${ID:-0.99} --db $2 --uc $3.uc --strand ${STRAND:-both} --qmask none --notmatched $3.unmatched.fasta --threads ${T:-12} --minseqlength 1 --fasta_width 0 --quiet $4 2>>runs/log.txt; }
# shuffled dbs
python - <<'P'
import random
recs=[];h=None
for l in open('db/FullDatabase_2025.1.fasta'):
    l=l.rstrip()
    if l.startswith('>'): recs.append([l,''])
    else: recs[-1][1]+=l
for s in range(10):
    r=recs[:]; random.Random(s).shuffle(r)
    open(f'runs/Full_shuf{s}.fasta','w').write(''.join(f'{a}\n{b}\n' for a,b in r))
P
for S in bull meta; do
 for D in FullDatabase Inhibitory InhibitoryStrict Facilitating NoEffect; do q2 ${S}_q.fasta db/${D}_2025.1.fasta runs/${S}_${D}_q2; done
 q2 ${S}_q.fasta db/FullDatabase_2025.1.fasta runs/${S}_Full_q2u "--userout runs/${S}_Full_q2u.tsv --userfields $UF"
 q2 ${S}_q.fasta db/FullDatabase_2025.1.fasta runs/${S}_Full_mr0 "--maxrejects 0 --userout runs/${S}_Full_mr0.tsv --userfields $UF"
 STRAND=plus q2 ${S}_q.fasta db/FullDatabase_2025.1.fasta runs/${S}_Full_plus
 for s in $(seq 0 9); do q2 ${S}_q.fasta runs/Full_shuf$s.fasta runs/${S}_shuf$s; done
 for r in 1 2 3; do T=1 q2 ${S}_q.fasta db/FullDatabase_2025.1.fasta runs/${S}_t1_r$r; T=12 q2 ${S}_q.fasta db/FullDatabase_2025.1.fasta runs/${S}_t12_r$r; done
 echo "$S default battery done $(date)" >> runs/log.txt
done
# exhaustive (0.97 superset; 0.99 = filter id>=99)
cp bull_exh097.tsv runs/bull_exh097.tsv 2>/dev/null || true
for S in bull meta; do
 [ -s runs/${S}_exh097.tsv ] || vsearch --usearch_global ${S}_q.fasta --id 0.97 --db db/FullDatabase_2025.1.fasta --userout runs/${S}_exh097.tsv --userfields $UF --strand both --qmask none --threads 12 --minseqlength 1 --maxaccepts 0 --maxrejects 0 --quiet 2>>runs/log.txt
done
# check: exhaustive at 0.99 for bullfrog equals filtered 0.97
vsearch --usearch_global bull_q.fasta --id 0.99 --db db/FullDatabase_2025.1.fasta --userout runs/bull_exh099.tsv --userfields $UF --strand both --qmask none --threads 12 --minseqlength 1 --maxaccepts 0 --maxrejects 0 --quiet 2>>runs/log.txt
echo ALLDONE $(date) >> runs/log.txt
