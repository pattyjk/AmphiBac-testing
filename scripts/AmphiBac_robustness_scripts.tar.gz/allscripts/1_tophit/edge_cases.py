"""Step 3: controlled vsearch experiments on identity definition and edge cases.
Uses the exact q2-vsearch call (plus --userout / --maxaccepts 0 --maxrejects 0 where noted)."""
import re, random, subprocess, pandas as pd, numpy as np, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
UF='query+target+id+alnlen+mism+gaps+qcov+tcov+qilo+qihi+tilo+tihi+ql+tl'
def rc(s):
    return s.translate(str.maketrans('ACGTRYKMSWBDHVN','TGCAYRMKSWVHDBN'))[::-1]
def readfa(p):
    d={};k=None
    for l in open(p):
        l=l.rstrip()
        if l.startswith('>'): k=l[1:].split()[0]; d[k]=[]
        else: d[k].append(l)
    return {k:''.join(v) for k,v in d.items()}
def writefa(p,d):
    with open(p,'w') as w:
        for k,v in d.items(): w.write(f'>{k}\n{v}\n')
def vs(q,db,tag,exhaustive=False,strand='both',ident=0.99):
    out=f'edge/{tag}.tsv'
    cmd=['vsearch','--usearch_global',q,'--id',str(ident),'--db',db,'--uc',f'edge/{tag}.uc','--strand',strand,'--qmask','none',
         '--notmatched',f'edge/{tag}.unm.fasta','--threads','4','--minseqlength','1','--fasta_width','0','--quiet',
         '--userout',out,'--userfields',UF,'--output_no_hits']
    if exhaustive: cmd+=['--maxaccepts','0','--maxrejects','0']
    r=subprocess.run(cmd,capture_output=True,text=True)
    df=pd.read_csv(out,sep='\t',header=None,names=UF.split('+'))
    df['stderr_warn']=r.stderr.strip().replace('\n',' ')[:300]
    return df
F515=re.compile('GTG[CT]CAGC[AC]GCCGCGGTAA'); R806=re.compile('ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC')
db=readfa('db/FullDatabase_2025.1.fasta'); au=pd.read_csv('db/audit_per_sequence.csv',index_col=0)
oriented={k:(rc(s) if au.at[k,'strand_in_db']=='-' else s) for k,s in db.items()}
rng=random.Random(1)
# ---------- (i) terminal-gap exclusion ----------
cand=[k for k,s in oriented.items() if au.at[k,'n_ambig']==0 and F515.search(s) and R806.search(s)]
src=rng.sample(cand,25)
rows=[]
qs={};refs={}
for k in src:
    s=oriented[k]; a=F515.search(s).end(); b=R806.search(s).start(); v4=s[a:b]
    for L in (253,120,90):
        frag=v4[:L] if L<253 else v4
        qs[f'{k}|L{L}']=frag
        for cov in (20,40,60,90,'full'):
            c=len(frag) if cov=='full' else cov
            if c>len(frag): continue
            # reference = all upstream sequence + first c bp of the fragment (ref ends inside the amplicon)
            refs[f'{k}|L{L}|cov{cov}|exact']=s[:a+c]
            # same but with 1 mismatch inside the overlapping c bp
            t=list(s[:a+c]); p=a+c//2; t[p]={'A':'C','C':'G','G':'T','T':'A'}[t[p]]
            refs[f'{k}|L{L}|cov{cov}|1mm']=''.join(t)
            # reference that starts inside the fragment (missing 5' part): covers last c bp
            refs[f'{k}|L{L}|cov{cov}|startinside']=frag[len(frag)-c:]+s[a+len(frag):]
writefa('edge/tg_q.fasta',qs)
res=[]
for key,refseq in refs.items():
    k,L,cov,kind=key.split('|')
    writefa('edge/one_ref.fasta',{key:refseq}); writefa('edge/one_q.fasta',{f'{k}|{L}':qs[f'{k}|{L}']})
    d=vs('edge/one_q.fasta','edge/one_ref.fasta','tg_one')
    r=d.iloc[0].to_dict(); r.update(src=k,frag_len=int(L[1:]),ref_cov=cov,kind=kind,hit=r['target']!='*')
    res.append(r)
tg=pd.DataFrame(res); tg.to_csv('edge/terminal_gap_controlled.csv',index=False)
print(tg.groupby(['kind','frag_len','ref_cov']).agg(n=('hit','size'),pass099=('hit','mean'),id_med=('id','median'),alnlen_med=('alnlen','median')).to_string())
# real database refs with <90 bp after 515F / ending inside V4: query the 90/120 bp fragment from a full-length ref of the same sequence? -> use the ref's own available V4 prefix as query
short=au[(au.has_515F==True)&(au.bp_after_515F<120)].index.tolist()
print('real refs with 515F and <120 bp after it:',len(short), 'of which <90:',int((au.loc[short,'bp_after_515F']<90).sum()))
# for each, build a query = its own post-515F sequence extended to 90/120 bp with random bases (simulating a true ASV that matches over the available part)
res=[]
for k in short:
    s=oriented[k]; a=F515.search(s).end(); part=s[a:]
    for L in (90,120):
        ext=part[:L]+''.join(rng.choice('ACGT') for _ in range(max(0,L-len(part))))
        writefa('edge/one_q.fasta',{f'{k}|L{L}':ext}); writefa('edge/one_ref.fasta',{k:db[k]})
        d=vs('edge/one_q.fasta','edge/one_ref.fasta','tg_real')
        r=d.iloc[0].to_dict(); r.update(src=k,frag_len=L,bp_after_515F=len(part),hit=r['target']!='*'); res.append(r)
tr=pd.DataFrame(res); tr.to_csv('edge/terminal_gap_realshortrefs.csv',index=False)
print(tr.groupby('frag_len').agg(n=('hit','size'),pass_rate=('hit','mean'),id_med=('id','median'),aln_med=('alnlen','median')).to_string())
# ---------- (ii) IUPAC / N handling ----------
comp={'A':'RMWDHVN','C':'YMSBHVN','G':'RKSBDVN','T':'YKWBDHN'}
inc={'A':'YKSB','C':'RKWD','G':'YMWH','T':'RMSV'}
res=[]
src2=rng.sample(cand,30)
for where in ('ref','query'):
  for code in ('N','compatible','incompatible','mismatch_base'):
    for n in (1,2,3):
        qd={};rd={}
        for k in src2:
            s=oriented[k]; a=F515.search(s).end(); frag=s[a:a+90]; full=s
            pos=rng.sample(range(10,80),n)
            def mut(x,off):
                x=list(x)
                for p in pos:
                    b=x[off+p]
                    x[off+p]={'N':'N','compatible':rng.choice(comp[b][:-1]),'incompatible':rng.choice(inc[b]),'mismatch_base':rng.choice([c for c in 'ACGT' if c!=b])}[code]
                return ''.join(x)
            if where=='ref': rd[k]=mut(full,a); qd[k]=frag
            else: rd[k]=full; qd[k]=mut(frag,0)
        writefa('edge/iu_q.fasta',qd); writefa('edge/iu_r.fasta',rd)
        d=vs('edge/iu_q.fasta','edge/iu_r.fasta','iu',exhaustive=True,ident=0.5)
        d=d[d['query']==d['target']]
        res.append(dict(where=where,code=code,n_codes=n,n_queries=len(src2),n_aligned=len(d),id_median=d['id'].median(),id_min=d['id'].min(),
                        mism_median=d['mism'].median(),pass_099=int((d['id']>=99).sum()),expected_id_if_mismatch=round(100*(90-n)/90,2)))
iu=pd.DataFrame(res); iu.to_csv('edge/iupac_controlled.csv',index=False); print(iu.to_string())
# ---------- (iii) very short refs & k-mer prefilter ----------
sh=au[au.length<100].index.tolist(); print('refs <100 bp:',len(sh))
res=[]
for k in sh:
    s=db[k]
    for ctx in ('Full','ShortOnly'):
        # query: the ref itself embedded in a 90-bp V4-like query (random flanks)
        fl=90-len(s) if len(s)<90 else 0
        left=''.join(rng.choice('ACGT') for _ in range(fl//2)); right=''.join(rng.choice('ACGT') for _ in range(fl-fl//2))
        q=(left+s+right) if len(s)<90 else s[:90]
        writefa('edge/one_q.fasta',{k:q})
        dbp='db/FullDatabase_2025.1.fasta' if ctx=='Full' else 'edge/short_db.fasta'
        if ctx=='ShortOnly': writefa('edge/short_db.fasta',{x:db[x] for x in sh})
        for mode in ('q2default','exhaustive'):
            d=vs('edge/one_q.fasta',dbp,'sh',exhaustive=(mode=='exhaustive'))
            self_hit=d[d.target==k]
            res.append(dict(ref=k,ref_len=len(s),n_ambig=au.at[k,'n_ambig'],db=ctx,mode=mode,default_target=d.iloc[0].target,
                            self_found=len(self_hit)>0,self_id=self_hit['id'].max() if len(self_hit) else np.nan,
                            n_hits=int((d.target!='*').sum()),warn=d.iloc[0].stderr_warn[:120]))
shr=pd.DataFrame(res); shr.to_csv('edge/short_refs.csv',index=False)
shr['lenbin']=pd.cut(shr.ref_len,[0,8,20,60,100])
print(shr.groupby(['db','mode','lenbin'],observed=True).agg(n=('ref','size'),self_found=('self_found','sum'),hijack_by_other=('default_target',lambda x:(x!='*').sum())).to_string())
