"""Steps 1-2: default (q2-vsearch) top hit vs all qualifying hits; order/thread/subset sensitivity."""
import pandas as pd, numpy as np, os, glob, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
UF='query+target+id+alnlen+mism+gaps+qcov+tcov+qilo+qihi+tilo+tihi+ql+tl'.split('+')
au=pd.read_csv('db/audit_per_sequence.csv',index_col=0)
FUNC=au['Func']; INH=(FUNC=='Inhibitory')
BDI=au['Bd_label'].astype(str).str.lower().str.startswith('inhib')   # sensitivity label
def uc(p):
    d=pd.read_csv(p,sep='\t',header=None,usecols=[0,3,8,9],names=['t','id','q','target'],dtype=str)
    d=d[d.t.isin(['H','N'])].copy(); d['q']=d.q.str.split(';').str[0]
    d.loc[d.t=='N','target']=np.nan; d['id']=pd.to_numeric(d.id,errors='coerce')
    return d.set_index('q')[['target','id']]
def uo(p):
    d=pd.read_csv(p,sep='\t',header=None,names=UF); d['query']=d['query'].str.split(';').str[0]
    d['idx']=100*(d.alnlen-d.mism-d.gaps)/d.alnlen  # exact iddef-2 identity (userout 'id' is rounded to 0.1)
    return d
summary={}; tables={}
for S,qf in (('meta','meta_queries.csv'),('bull','bull_queries.csv')):
    Q=pd.read_csv(qf).set_index('qid'); w=Q['reads']; N=len(Q); W=w.sum()
    T=pd.DataFrame(index=Q.index); T['query_seq']=Q['query']; T['reads']=w; T['n_samples']=Q['n_samples']
    # default q2 runs per subset
    for D,lab in (('FullDatabase','Full'),('Inhibitory','Inh'),('InhibitoryStrict','InhStrict'),('Facilitating','Fac'),('NoEffect','NoEff')):
        u=uc(f'runs/{S}_{D}_q2.uc').reindex(T.index); T[f'{lab}_hit']=u.target; T[f'{lab}_id']=u.id
    d=uo(f'runs/{S}_Full_q2u.tsv').drop_duplicates('query').set_index('query').reindex(T.index)
    assert (d.target.fillna('*').values==T.Full_hit.fillna('*').values).mean()>0.999
    for c in ['alnlen','mism','gaps','qcov','tcov','qilo','qihi','tilo','tihi','tl']: T[f'def_{c}']=d[c]
    T['Full_id_uc']=T['Full_id']; T['Full_id']=d['idx']
    T['def_Func']=T.Full_hit.map(FUNC); T['def_score']=T.Full_hit.map(au['score']); T['def_Bd_label']=T.Full_hit.map(au['Bd_label']); T['def_ref_study']=T.Full_hit.map(au['Reference'])
    mr0=uc(f'runs/{S}_Full_mr0.uc').reindex(T.index); T['mr0_hit']=mr0.target; T['mr0_id']=mr0.id
    # exhaustive
    E=uo(f'runs/{S}_exh097.tsv'); E['Func']=E.target.map(FUNC); E['inh']=E.target.map(INH); E['bdinh']=E.target.map(BDI); E['score']=E.target.map(au['score'])
    E99raw=E[E.idx>=99.0-1e-9].copy(); E99raw['id']=E99raw['idx']
    # PRIMARY 'qualifying' set = >=99% AND alignment spans the whole query (qilo==1, qihi==ql); raw set keeps partial overlaps
    E99raw['fullcov']=(E99raw.qilo==1)&(E99raw.qihi==E99raw.ql)
    E99=E99raw[E99raw.fullcov].copy()
    T['n_qual99_raw']=E99raw.groupby('query').size().reindex(T.index).fillna(0).astype(int)
    T['n_qual99_partial']=E99raw[~E99raw.fullcov].groupby('query').size().reindex(T.index).fillna(0).astype(int)
    T['best_partial_alnlen']=E99raw[~E99raw.fullcov].groupby('query').alnlen.max().reindex(T.index)
    assert len(E[(E.id>=99)&(E.idx<99)])>=0
    g=E99.groupby('query')
    T['n_qual99']=g.size().reindex(T.index).fillna(0).astype(int)
    T['n_qual97']=E[(E.idx>=97-1e-9)&(E.qilo==1)&(E.qihi==E.ql)].groupby('query').size().reindex(T.index).fillna(0).astype(int)
    T['n_nearmiss_97_99']=T.n_qual97-T.n_qual99
    T['max_id99']=g['id'].max()
    T['n_at_max_id']=E99[E99.id==E99['query'].map(T['max_id99'])].groupby('query').size().reindex(T.index).fillna(0).astype(int)
    for f in ['Inhibitory','NoEffect','Facilitating','NotTested','PossibleContamination']:
        T[f'n_qual_{f}']=E99[E99.Func==f].groupby('query').size().reindex(T.index).fillna(0).astype(int)
    T['frac_inhib_qual']=T.n_qual_Inhibitory/T.n_qual99.replace(0,np.nan)
    T['frac_inhib_qual_Bdlabel']=g['bdinh'].mean()
    T['median_score_qual']=g['score'].median()
    # majority label among qualifying refs
    cnt=T[[f'n_qual_{f}' for f in ['Inhibitory','NoEffect','Facilitating','NotTested','PossibleContamination']]].values
    mx=cnt.max(1); labs=np.array(['Inhibitory','NoEffect','Facilitating','NotTested','PossibleContamination'])
    tie=(cnt==mx[:,None]).sum(1)>1
    T['majority_Func']=pd.Series(np.where(tie,'tie',labs[cnt.argmax(1)]),index=T.index,dtype=object).where(T.n_qual99>0)
    T['def_vs_majority']=np.select([T.Full_hit.isna(),T.majority_Func=='tie',T.def_Func==T.majority_Func],['nohit','tie','agree'],'disagree')
    T.loc[T.Full_hit.isna()&(T.n_qual99>0),'def_vs_majority']='missed_by_default'
    T['def_inhib']=T.def_Func=='Inhibitory'
    T['def_label_mixed']=(T.frac_inhib_qual>0)&(T.frac_inhib_qual<1)
    T['def_is_max_id']=np.where(T.Full_hit.isna(),np.nan,(T.Full_id>=T.max_id99-1e-9).astype(float))
    T['strictly_higher_exists']=np.where(T.Full_hit.isna(),np.nan,(T.max_id99>T.Full_id+1e-9).astype(float))
    pairs=set(zip(E99['query'],E99['target']))
    T['def_hit_in_exhaustive']=[((q_,h) in pairs) if isinstance(h,str) else np.nan for q_,h in zip(T.index,T.Full_hit)]
    T['missed_by_maxrejects']=T.Full_hit.isna()&(T.n_qual99>0)   # full-coverage ref exists but default found nothing
    T['missed_raw_partial_only']=T.Full_hit.isna()&(T.n_qual99==0)&(T.n_qual99_partial>0)
    T['mr0_changes_hit']=(T.mr0_hit.fillna('*')!=T.Full_hit.fillna('*'))
    m0=uo(f'runs/{S}_Full_mr0.tsv').drop_duplicates('query').set_index('query').reindex(T.index)
    T['mr0_alnlen']=m0.alnlen; T['mr0_partial']=T.mr0_hit.notna()&~((m0.qilo==1)&(m0.qihi==m0.ql))
    T['partial_cov_default']=T.Full_hit.notna()&(T.def_alnlen<Q['length'])
    # ambiguity codes in aligned region of default hit
    import re
    db={};k=None
    for l in open('db/FullDatabase_2025.1.fasta'):
        l=l.rstrip()
        if l.startswith('>'): k=l[1:]; db[k]=''
        else: db[k]+=l
    amb=[]
    for h,lo,hi in zip(T.Full_hit,T.def_tilo,T.def_tihi):
        if not isinstance(h,str): amb.append(np.nan); continue
        lo,hi=sorted((int(lo),int(hi))); amb.append(len(re.findall('[^ACGT]',db[h][lo-1:hi])))
    T['def_ambig_in_aln']=amb
    # shuffle and thread runs
    sh=pd.concat({s:uc(f'runs/{S}_shuf{s}.uc').reindex(T.index).target for s in range(10)},axis=1)
    th=pd.concat({f't{t}_r{r}':uc(f'runs/{S}_t{t}_r{r}.uc').reindex(T.index).target for t in (1,12) for r in (1,2,3)},axis=1)
    allsh=pd.concat([T.Full_hit.rename('orig'),sh],axis=1).fillna('*')
    T['n_distinct_ref_shuffle']=allsh.nunique(1)
    T['n_distinct_Func_shuffle']=allsh.apply(lambda c:c.map(FUNC).fillna('nohit')).nunique(1)
    T['shuffle_ref_changed']=T.n_distinct_ref_shuffle>1; T['shuffle_Func_changed']=T.n_distinct_Func_shuffle>1
    T['shuffle_inhib_call_changed']=allsh.apply(lambda c:c.map(FUNC).eq('Inhibitory')).nunique(1)>1
    tha=pd.concat([T.Full_hit.rename('orig'),th],axis=1).fillna('*')
    T['n_distinct_ref_threads']=tha.nunique(1); T['threads_ref_changed']=T.n_distinct_ref_threads>1
    T['threads_Func_changed']=tha.apply(lambda c:c.map(FUNC).fillna('nohit')).nunique(1)>1
    t1=th[[c for c in th if c.startswith('t1_')]].fillna('*')
    T['t1_reps_differ']=t1.nunique(1)>1
    # strand
    pl=uc(f'runs/{S}_Full_plus.uc').reindex(T.index); T['plus_hit']=pl.target; T['plus_Func']=pl.target.map(FUNC)
    T['def_ref_stored_rc']=T.Full_hit.map(au['strand_in_db']).eq('-')
    tables[S]=T.drop(columns=[]).reset_index().rename(columns={'index':'qid'})
    T.reset_index().to_csv(f'{S}_per_query_tophit.csv',index=False)
    # ---------- summary numbers ----------
    def pf(mask,base=None):
        base=T.index==T.index if base is None else base
        m=mask&base; return dict(n=int(m.sum()),of=int(base.sum()),pct_feat=round(100*m.sum()/max(1,base.sum()),2),
                                 reads=float(w[m].sum()),pct_reads=round(100*w[m].sum()/max(1,w[base].sum()),2))
    hit=T.Full_hit.notna(); q=T.n_qual99>0
    s={}
    s['rounded_id_pairs_excluded']=int(((E.id>=99)&(E.idx<99)).sum())
    s['n_queries']=N; s['total_reads']=float(W)
    s['default_hit_Full']=pf(hit); s['qualifying_any_exhaustive']=pf(q)
    s['n_qual99_dist_among_hit']=T.loc[q,'n_qual99'].describe().round(2).to_dict()
    s['n_qual99_ge2']=pf(T.n_qual99>=2,q); s['n_qual99_ge10']=pf(T.n_qual99>=10,q)
    s['nearmiss_only_97_99']=pf((T.n_qual99==0)&(T.n_qual97>0))
    s['default_is_max_id']=pf(T.def_is_max_id==1,hit); s['strictly_higher_exists']=pf(T.strictly_higher_exists==1,hit)
    s['ties_at_max_id_ge2']=pf(T.n_at_max_id>=2,q)
    s['mixed_label_qualifying']=pf(T.def_label_mixed,q)
    s['frac_inhib_qual_bins']={b:pf(m,q) for b,m in {'0':T.frac_inhib_qual==0,'(0,0.5)':(T.frac_inhib_qual>0)&(T.frac_inhib_qual<0.5),'0.5':T.frac_inhib_qual==0.5,'(0.5,1)':(T.frac_inhib_qual>0.5)&(T.frac_inhib_qual<1),'1':T.frac_inhib_qual==1}.items()}
    s['default_vs_majority']={k:pf(T.def_vs_majority==k) for k in ['agree','disagree','tie','missed_by_default','nohit']}
    s['default_inhib_but_majority_not']=pf(T.def_inhib&(T.frac_inhib_qual<0.5),hit)
    s['default_not_inhib_but_majority_inhib']=pf((~T.def_inhib)&(T.frac_inhib_qual>0.5),hit)
    s['missed_by_maxrejects32']=pf(T.missed_by_maxrejects,q)
    s['raw_any_overlap_qualifying']=pf(T.n_qual99_raw>0)
    s['raw_partial_only_qualifying']=pf((T.n_qual99_raw>0)&(T.n_qual99==0))
    s['raw_partial_only_best_alnlen_median']=float(T.loc[(T.n_qual99_raw>0)&(T.n_qual99==0),'best_partial_alnlen'].median()) if ((T.n_qual99_raw>0)&(T.n_qual99==0)).any() else None
    s['raw_partial_pairs_among_qualifying_pairs_pct']=round(100*(~E99raw.fullcov).mean(),2)
    s['raw_top_partial_targets']=E99raw[~E99raw.fullcov].target.value_counts().head(8).to_dict()
    s['mr0_hit']=pf(T.mr0_hit.notna()); s['mr0_partial_hit']=pf(T.mr0_partial)
    s['maxrejects0_changes_hit']=pf(T.mr0_changes_hit)
    s['default_hit_not_in_exhaustive_set']=pf(T.def_hit_in_exhaustive==False,hit)
    s['Bdlabel_frac_inhib_mixed']=pf((T.frac_inhib_qual_Bdlabel>0)&(T.frac_inhib_qual_Bdlabel<1),q)
    s['Bdlabel_default_inhib_majority_not']=pf(T.Full_hit.map(BDI).fillna(False).astype(bool)&(T.frac_inhib_qual_Bdlabel<0.5),hit)
    # step 2
    base=hit|q
    s['shuffle_ref_changed']=pf(T.shuffle_ref_changed,base); s['shuffle_Func_changed']=pf(T.shuffle_Func_changed,base)
    s['shuffle_inhib_call_changed']=pf(T.shuffle_inhib_call_changed,base)
    s['shuffle_n_matched_per_run']=[int(sh[c].notna().sum()) for c in sh]
    s['threads_ref_changed']=pf(T.threads_ref_changed,base); s['threads_Func_changed']=pf(T.threads_Func_changed,base); s['t1_replicates_differ']=pf(T.t1_reps_differ,base)
    s['threads_n_matched_per_run']={c:int(th[c].notna().sum()) for c in th}
    for lab in ['Inh','InhStrict','Fac','NoEff']: s[f'{lab}_mode_hit']=pf(T[f'{lab}_hit'].notna())
    for lab in ['Inh','InhStrict']:
        m=T[f'{lab}_hit'].notna()
        s[f'{lab}_by_fracinhib']={b:pf(mm,m) for b,mm in {'<0.5':T.frac_inhib_qual<0.5,'=0.5':T.frac_inhib_qual==0.5,'(0.5,1)':(T.frac_inhib_qual>0.5)&(T.frac_inhib_qual<1),'1':T.frac_inhib_qual==1,'no_full_qual':T.n_qual99==0}.items()}
        s[f'{lab}_median_qual_score_by_bin']={b:(float(T.loc[m&mm,'median_score_qual'].median()) if (m&mm).any() else None) for b,mm in {'<0.5':T.frac_inhib_qual<0.5,'>=0.5':T.frac_inhib_qual>=0.5}.items()}
        s[f'{lab}_median_assigned_ref_score_by_bin']={b:(float(T.loc[m&mm,f'{lab}_hit'].map(au['score']).median()) if (m&mm).any() else None) for b,mm in {'<0.5':T.frac_inhib_qual<0.5,'>=0.5':T.frac_inhib_qual>=0.5}.items()}
        s[f'{lab}_but_default_Full_not_inhib']=pf(m&~T.def_inhib,m)
    s['Inh_and_Fac_both']=pf(T.Inh_hit.notna()&T.Fac_hit.notna())
    s['InhStrict_and_Fac_both']=pf(T.InhStrict_hit.notna()&T.Fac_hit.notna())
    s['InhStrict_with_NoEffect_qualifying']=pf(T.InhStrict_hit.notna()&(T.n_qual_NoEffect>0),T.InhStrict_hit.notna())
    s['InhStrict_and_NoEffect_mode_hit']=pf(T.InhStrict_hit.notna()&T.NoEff_hit.notna(),T.InhStrict_hit.notna())
    s['InhStrict_with_Facilitating_qualifying']=pf(T.InhStrict_hit.notna()&(T.n_qual_Facilitating>0),T.InhStrict_hit.notna())
    # strand
    s['plus_hit']=pf(T.plus_hit.notna()); s['both_hit']=pf(hit)
    s['lost_with_plus']=pf(hit&T.plus_hit.isna(),hit); s['default_ref_stored_rc']=pf(T.def_ref_stored_rc,hit)
    s['plus_vs_both_Func_changed']=pf(hit&(T.plus_Func.fillna('nohit')!=T.def_Func.fillna('nohit')),hit)
    # edge on real hits
    s['default_partial_cov_alnlen_lt_qlen']=pf(T.partial_cov_default,hit)
    s['default_partial_qcov_lt100']=pf(T.Full_hit.notna()&((T.def_qilo!=1)|(T.def_qihi!=Q['length'])),hit)
    s['default_partial_alnlen_values']=T.loc[T.Full_hit.notna()&((T.def_qilo!=1)|(T.def_qihi!=Q['length'])),'def_alnlen'].describe().round(1).to_dict()
    s['default_alnlen_dist']=T.loc[hit,'def_alnlen'].value_counts().sort_index().head(15).to_dict()
    s['default_ambig_in_aln']=pf(T.def_ambig_in_aln>0,hit)
    s['default_hit_short_ref_lt100']=pf(T.Full_hit.map(au['length']).lt(100),hit)
    s['default_hit_ref_lt90_after515F']=pf(T.Full_hit.map(au['bp_after_515F']).lt(90),hit)
    summary[S]=s
json.dump(summary,open('tophit_summary.json','w'),indent=1,default=str)
print(json.dumps({S:{k:v for k,v in summary[S].items() if not isinstance(v,dict) or 'pct_feat' in v} for S in summary},default=str)[:6000])
