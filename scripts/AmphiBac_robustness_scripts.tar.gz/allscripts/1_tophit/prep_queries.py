"""Prepare query FASTAs (with ;size=) for meta-analysis sOTUs and bullfrog ASVs."""
import zipfile, io, numpy as np, pandas as pd, re
ZIP="/Users/p.kearns/.claude-science/orgs/02812373-138d-4a58-874b-33e46fa50871/artifacts/proj_63ce8813f8d0/b0479e52-4706-4c27-8c31-08d65a6b07f0/v9ab57aec_amphib_only_otu_table.zip"
ASV="/Users/p.kearns/.claude-science/orgs/02812373-138d-4a58-874b-33e46fa50871/artifacts/proj_63ce8813f8d0/a94982cf-bfd4-4385-8c61-48b9a494cf8c/vb3169217_asv_table.txt"
SEQ="/Users/p.kearns/.claude-science/orgs/02812373-138d-4a58-874b-33e46fa50871/artifacts/proj_63ce8813f8d0/658b1f2f-4736-40e1-a6f9-b65c3dfa58a0/v5d7e73fe_dna-sequences.fasta"
seqre=re.compile(r'^[ACGTNacgtn]+$')  # numeric IDs are dropped; lowercase sequence IDs kept and uppercased
ids=[];rows=[];header=None;bad=0;numeric=0
with zipfile.ZipFile(ZIP) as z, z.open('amphib_only_otu_table.txt') as fh:
    for line in io.TextIOWrapper(fh):
        f=line.rstrip('\n').split('\t')
        if header is None:
            header=f[1:] if f[0] in('OTU ID','#OTU ID','') else f; continue  # first line = sample names (no ID column)
        if line.startswith('#'): continue
        if header is None or len(f)!=len(header)+1: bad+=1;continue
        if not seqre.match(f[0]): numeric+=1; continue
        ids.append(f[0].upper()); rows.append(np.array(f[1:],dtype=np.float32))
M=np.vstack(rows); print('header samples',len(header),'malformed',bad,'nonseq ids',numeric,'seq rows',len(ids))
depth=M.sum(0); keep=depth>=1000; print('kept samples',keep.sum())
Mk=M[:,keep]; tot=Mk.sum(1); prev=(Mk>0).sum(1)
sel=tot>0; print('sOTUs >0 reads in kept',sel.sum(),'total reads',tot[sel].sum())
df=pd.DataFrame({'query':np.array(ids)[sel],'reads':tot[sel],'n_samples':prev[sel]})
print('lowercase-origin dup after upper:',df['query'].duplicated().sum())
df=df.groupby('query',as_index=False).agg(reads=('reads','sum'),n_samples=('n_samples','max'))
df=df.sort_values('reads',ascending=False).reset_index(drop=True)
df['length']=df['query'].str.len(); print(df.length.value_counts().head())
df['qid']=['sOTU_%d'%i for i in range(len(df))]
df.to_csv('meta_queries.csv',index=False)
o=df.sort_values('reads',ascending=False)
with open('meta_q.fasta','w') as w:
    for r in o.itertuples(): w.write(f'>{r.qid};size={int(r.reads)}\n{r.query}\n')
# bullfrog
t=pd.read_csv(ASV,sep='\t',skiprows=1 if open(ASV).readline().startswith('# Const') else 0,index_col=0)
seqs={};k=None
for l in open(SEQ):
    l=l.strip()
    if l.startswith('>'): k=l[1:].split()[0]; seqs[k]=''
    else: seqs[k]+=l
print('bullfrog table',t.shape,'seqs',len(seqs),'ids match',set(t.index)==set(seqs))
cs=t.sum(0); print('low samples',cs[cs<10].to_dict())
b=pd.DataFrame({'qid':t.index,'reads':t.sum(1).values,'n_samples':(t>0).sum(1).values})
b['query']=b.qid.map(seqs); b['length']=b['query'].str.len(); print(b.length.value_counts().head())
b.to_csv('bull_queries.csv',index=False)
with open('bull_q.fasta','w') as w:
    for r in b.sort_values('reads',ascending=False).itertuples(): w.write(f'>{r.qid};size={max(1,int(r.reads))}\n{r.query}\n')
