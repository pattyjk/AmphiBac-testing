"""Figures for steps 1-3 (300 dpi PNG)."""
import pandas as pd, numpy as np, json, os, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
os.chdir(os.path.dirname(os.path.abspath(__file__)))
plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans','axes.titlesize':9,'axes.titleweight':'bold','legend.frameon':False})
CI,CN,CF,CG='#2166AC','#E08214','#7B3294','#BBBBBB'
S=json.load(open('tophit_summary.json'))
T={k:pd.read_csv(f'{k}_per_query_tophit.csv',low_memory=False) for k in ('meta','bull')}
NAME={'meta':'Meta-analysis 90-bp sOTUs','bull':'Bullfrog 120-bp ASVs'}
def lab(ax,l): ax.set_title(f'{l}   '+ax.get_title(),loc='left',fontsize=ax.title.get_fontsize()); ax.set_title('')
# ================= Figure 1 =================
fig,axs=plt.subplots(2,4,figsize=(15,6.8),constrained_layout=True)
for i,k in enumerate(('meta','bull')):
    t=T[k]; q=t[t.n_qual99>0]
    ax=axs[i,0]; bins=[1,2,3,5,10,20,50,100,200,500,1000]
    h=np.histogram(q.n_qual99.clip(upper=999),bins=bins)[0]; hw=np.array([q.reads[(q.n_qual99>=a)&(q.n_qual99<b)].sum() for a,b in zip(bins[:-1],bins[1:])])
    x=np.arange(len(h)); ax.bar(x-0.2,100*h/h.sum(),0.4,color='#555555',label='features'); ax.bar(x+0.2,100*hw/hw.sum(),0.4,color='#AAAAAA',label='reads')
    ax.set_xticks(x); ax.set_xticklabels(['1','2','3-4','5-9','10-19','20-49','50-99','100-199','200-499','≥500'],rotation=45,ha='right')
    ax.set_ylabel('% of matched queries'); ax.set_xlabel('qualifying Full-db refs\n(≥99% id, full query coverage, exhaustive)')
    ax.set_title(f'{NAME[k]}\nhits per matched query (n={len(q):,})'); ax.legend(); lab(ax,['A','E'][i])
    ax=axs[i,1]; f=q.frac_inhib_qual
    bb=np.linspace(0,1,11); hh=np.histogram(f,bins=bb)[0]
    cols=[CI if c>=0.5 else CN for c in (bb[:-1]+0.05)]
    ax.bar(bb[:-1]+0.05,hh,0.09,color=cols)
    ax.set_xlabel('fraction of qualifying refs with Func = Inhibitory'); ax.set_ylabel('matched queries')
    nm=S[k]['mixed_label_qualifying']
    ax.set_title(f'Label mix among qualifying refs\nmixed: {nm["n"]:,} feat. ({nm["pct_feat"]}%), {nm["pct_reads"]}% reads'); lab(ax,['B','F'][i])
    ax=axs[i,2]; s=S[k]
    items=[('tie at max id\n(≥2 refs)',s['ties_at_max_id_ge2']),('default label ≠\nmajority label',dict(n=int((t.def_vs_majority=='disagree').sum()),of=int(t.Full_hit.notna().sum()),pct_feat=round(100*(t.def_vs_majority=='disagree').sum()/t.Full_hit.notna().sum(),2),pct_reads=round(100*t.reads[t.def_vs_majority=='disagree'].sum()/t.reads[t.Full_hit.notna()].sum(),2))),
           ('default Inhibitory,\n<50% qual. Inhibitory',s['default_inhib_but_majority_not']),('default not Inhib.,\n>50% qual. Inhibitory',s['default_not_inhib_but_majority_inhib']),
           ('full-cov. ref missed\nby default (maxrejects 32)',s['missed_by_maxrejects32']),('default hit covers\n<100% of query',s['default_partial_qcov_lt100'])]
    y=np.arange(len(items))
    ax.barh(y+0.2,[v['pct_feat'] for _,v in items],0.4,color='#555555',label='% features'); ax.barh(y-0.2,[v['pct_reads'] for _,v in items],0.4,color='#AAAAAA',label='% reads')
    for yy,(_,v) in zip(y,items): ax.text(max(v['pct_feat'],v['pct_reads'])+0.5,yy,f"{v['n']:,}/{v['of']:,}",va='center',fontsize=7)
    ax.set_yticks(y); ax.set_yticklabels([a for a,_ in items]); ax.invert_yaxis(); ax.set_xlabel('% of denominator (features / reads)')
    ax.set_xlim(0,110)
    ax.set_title('Default top hit vs exhaustive search\n(default never picks a lower-id ref)'); ax.legend(loc='lower right'); lab(ax,['C','G'][i])
    ax=axs[i,3]; r=t[t.n_qual99_raw>0]; best=np.where(r.n_qual99>0,r.query_seq.str.len(),r.best_partial_alnlen)
    full=r.n_qual99>0; bb=np.arange(10,int(r.query_seq.str.len().max())+11,5)
    ax.hist([best[~full],best[full]],bins=bb,stacked=True,color=[CN,'#555555'],label=[f'partial overlap only (n={int((~full).sum()):,})',f'full query coverage (n={int(full.sum()):,})'])
    ax.set_yscale('log'); ax.set_xlabel('best ≥99% alignment length (bp)'); ax.set_ylabel('queries (log)')
    ax.set_title(f"Exhaustive ≥99% hits: best alignment\n(maxrejects 0 → partial top hit: n={s['mr0_partial_hit']['n']:,})",fontsize=8); ax.legend(fontsize=6,loc='upper left'); lab(ax,['D','H'][i])
fig.suptitle('Step 1. q2-vsearch closed-ref (0.99, maxaccepts 1) vs exhaustive search of FullDatabase 2025.1',fontweight='bold')
fig.savefig('fig_step1_tophit_vs_all.png',dpi=300); plt.close(fig)
# ================= Figure 2 =================
fig,axs=plt.subplots(2,3,figsize=(11,6.6),constrained_layout=True)
for i,k in enumerate(('meta','bull')):
    t=T[k]; s=S[k]
    ax=axs[i,0]
    items=[('assigned ref changed\n(10 ref-order shuffles)',s['shuffle_ref_changed']),('Func label changed\n(shuffles)',s['shuffle_Func_changed']),('Inhibitory call changed\n(shuffles)',s['shuffle_inhib_call_changed']),
           ('assigned ref changed\n(threads 1 vs 12, ×3)',s['threads_ref_changed']),('Func label changed\n(threads)',s['threads_Func_changed'])]
    y=np.arange(len(items))
    ax.barh(y+0.2,[v['pct_feat'] for _,v in items],0.4,color='#555555',label='% features'); ax.barh(y-0.2,[v['pct_reads'] for _,v in items],0.4,color='#AAAAAA',label='% reads')
    for yy,(_,v) in zip(y,items): ax.text(max(v['pct_feat'],v['pct_reads'])+0.3,yy,f"n={v['n']:,}",va='center',fontsize=7)
    ax.set_yticks(y); ax.set_yticklabels([a for a,_ in items]); ax.invert_yaxis(); ax.set_xlabel(f"% of matched queries (n={s['shuffle_ref_changed']['of']:,})"); ax.legend(loc='lower right')
    ax.set_title(f'{NAME[k]}\norder / thread sensitivity'); lab(ax,['A','D'][i])
    ax=axs[i,1]
    bins=['<0.5','=0.5','(0.5,1)','1','no_full_qual']; colors=[CN,'#F4C27A','#92C5DE',CI,CG]
    for j,(lab_,mode) in enumerate((('Inhibitory','Inh'),('InhibitoryStrict','InhStrict'))):
        d=s[f'{mode}_by_fracinhib']; left=0;
        for b,c in zip(bins,colors):
            v=d[b]['pct_feat']; ax.barh(j*2+0.3,v,0.55,left=left,color=c,label=f'f_inhib {b}' if j==0 else None); left+=v
        left=0
        for b,c in zip(bins,colors):
            v=d[b]['pct_reads']; ax.barh(j*2-0.3,v,0.55,left=left,color=c); left+=v
    ax.set_yticks([2.3,1.7,0.3,-0.3]); ax.set_yticklabels([f"InhStrict features (n={s['InhStrict_mode_hit']['n']:,})",'InhStrict reads',f"Inhibitory features (n={s['Inh_mode_hit']['n']:,})",'Inhibitory reads'])
    ax.set_xlabel('% of features/reads counted "inhibitory"'); ax.legend(fontsize=6,loc='upper center',bbox_to_anchor=(0.5,-0.18),ncol=3)
    ax.set_title('Inhibitory share of qualifying\nFull-db refs, subset-mode hits'); lab(ax,['B','E'][i])
    ax=axs[i,2]
    m=t.Inh_hit.notna(); lo=m&(t.frac_inhib_qual<0.5); hi=m&(t.frac_inhib_qual>=0.5)
    data=[t.loc[hi,'median_score_qual'].dropna(),t.loc[lo,'median_score_qual'].dropna()]
    if all(len(d_) for d_ in data):
        bp=ax.boxplot(data,widths=0.5,patch_artist=True,showfliers=False)
        for p,c in zip(bp['boxes'],[CI,CN]): p.set_facecolor(c); p.set_alpha(0.7)
    ax.set_xticks([1,2]); ax.set_xticklabels([f'≥50% inhib.\n(n={len(data[0]):,})',f'<50% inhib.\n(n={len(data[1]):,})'])
    ax.axhline(80,ls='--',c=CI,lw=0.8); ax.axhline(-20,ls='--',c=CF,lw=0.8); ax.set_ylabel('median score of qualifying refs\n(1−prop. growth)×100')
    b2=S[k]
    ax.set_title(f"Inhibitory-mode hits\nalso hit Facilitating: {b2['Inh_and_Fac_both']['n']:,}\nInhStrict + NoEffect ref: {b2['InhStrict_with_NoEffect_qualifying']['n']:,}/{b2['InhStrict_with_NoEffect_qualifying']['of']:,}",fontsize=8); lab(ax,['C','F'][i])
fig.suptitle('Step 2. Reference-order, thread and subset sensitivity',fontweight='bold')
fig.savefig('fig_step2_order_subset.png',dpi=300); plt.close(fig)
# ================= Figure 3 =================
fig,axs=plt.subplots(1,4,figsize=(13,3.6),constrained_layout=True)
tg=pd.read_csv('edge/terminal_gap_controlled.csv'); ax=axs[0]
for (kind,L),c,ls in zip([('exact',90),('exact',120),('exact',253),('1mm',90),('1mm',120),('1mm',253)],['#1b9e77','#d95f02','#7570b3']*2,['-']*3+[':']*3):
    d=tg[(tg.kind==kind)&(tg.frag_len==L)]; g=d.groupby('ref_cov').hit.mean().reindex(['cov20','cov40','cov60','cov90','covfull']).dropna()
    ax.plot(range(len(g)),100*g.values,marker='o',ms=3,c=c,ls=ls,label=f'{L} bp, {"identical" if kind=="exact" else "1 mismatch"}')
ax.set_xticks(range(5)); ax.set_xticklabels(['20','40','60','90','full']); ax.set_xlabel('bp of fragment covered by truncated ref'); ax.set_ylabel('% passing 0.99 (n=25 refs each)')
ax.set_title('Terminal-gap exclusion\n(identical overlap reports id=100%)'); ax.legend(fontsize=6,loc='center right'); lab(ax,'A')
iu=pd.read_csv('edge/iupac_controlled.csv'); ax=axs[1]
codes=['N','compatible','incompatible','mismatch_base']; x=np.arange(3)
for j,(cd,c) in enumerate(zip(codes,['#444444','#1b9e77','#d95f02','#7570b3'])):
    d=iu[(iu['where']=='ref')&(iu['code']==cd)].sort_values('n_codes'); ax.plot(d.n_codes,d.id_median,marker='o',c=c,label=cd.replace('_',' '))
    d=iu[(iu['where']=='query')&(iu['code']==cd)].sort_values('n_codes'); ax.plot(d.n_codes,d.id_median,marker='x',ls=':',c=c)
ax.axhline(99,ls='--',c='k',lw=0.7); ax.set_xticks([1,2,3]); ax.set_xlabel('ambiguity codes in 90-bp aligned region'); ax.set_ylabel('vsearch id (%)')
ax.set_title('IUPAC handling (n=30 pairs)\nsolid = in ref, dotted = in query'); ax.legend(fontsize=6); lab(ax,'B')
sh=pd.read_csv('edge/short_refs.csv'); ax=axs[2]
d=sh[(sh['db']=='Full')&(sh['mode']=='exhaustive')]
ax.scatter(d.ref_len,d.self_found.astype(int)+np.random.default_rng(0).uniform(-0.05,0.05,len(d)),s=10,c=np.where(d.self_found,CI,CN))
ax.set_yticks([0,1]); ax.set_yticklabels(['never hit','self-hit found']); ax.set_xscale('symlog',linthresh=1); ax.set_xlim(0.8,150); ax.set_xlabel('reference length (bp)')
ax.set_title(f'k-mer prefilter: refs <100 bp (n={len(d)})\n{int((~d.self_found).sum())} cannot be selected (no 8-mer)'); lab(ax,'C')
ax=axs[3]; xs=np.arange(2)
for j,(k,c) in enumerate((('meta','#555555'),('bull','#AAAAAA'))):
    s=S[k]; ax.bar(xs+(j-0.5)*0.38,[s['both_hit']['pct_feat'] if False else 100*s['both_hit']['n']/s['n_queries'],100*s['plus_hit']['n']/s['n_queries']],0.38,color=c,label=NAME[k])
    for xx,v in zip(xs,[s['both_hit']['n'],s['plus_hit']['n']]): ax.text(xx+(j-0.5)*0.38,100*v/s['n_queries']+0.5,f'{v:,}',ha='center',fontsize=7)
ax.set_xticks(xs); ax.set_xticklabels(['--strand both','--strand plus']); ax.set_ylabel('% of queries matched at 0.99 (Full db)')
ax.set_ylim(0,9); ax.set_title('Strand: 5,451 refs stored RC'); ax.legend(fontsize=6,loc='upper right'); lab(ax,'D')
fig.suptitle('Step 3. Identity definition and edge cases (vsearch 2.32.0, q2 closed-ref parameters)',fontweight='bold')
fig.savefig('fig_step3_edge_cases.png',dpi=300); plt.close(fig)
print('figs done')
