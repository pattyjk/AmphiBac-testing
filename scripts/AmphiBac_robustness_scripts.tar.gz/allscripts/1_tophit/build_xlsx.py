"""Flatten tophit_summary.json + edge-case tables into one xlsx."""
import json, pandas as pd, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
S=json.load(open('tophit_summary.json')); rows=[]
for qs,d in S.items():
    for k,v in d.items():
        if isinstance(v,dict) and 'pct_feat' in v: rows.append(dict(query_set=qs,metric=k,sub='',**v))
        elif isinstance(v,dict) and all(isinstance(x,dict) and 'pct_feat' in x for x in v.values()):
            for s2,x in v.items(): rows.append(dict(query_set=qs,metric=k,sub=s2,**x))
        else: rows.append(dict(query_set=qs,metric=k,sub='',value=json.dumps(v)))
with pd.ExcelWriter('tophit_summary.xlsx') as w:
    pd.DataFrame(rows).to_excel(w,sheet_name='summary',index=False)
    pd.DataFrame([dict(sheet='summary',note='n = count meeting criterion; of = denominator; pct_reads weights by total reads (meta: 2,411 samples >=1000 reads). Qualifying = exhaustive vsearch (maxaccepts 0, maxrejects 0) hits with exact iddef-2 identity >=99% AND alignment spanning the whole query; raw_* metrics include partial-overlap hits.')]).to_excel(w,sheet_name='README',index=False)
    tg=pd.read_csv('edge/terminal_gap_controlled.csv')
    tg.groupby(['kind','frag_len','ref_cov']).agg(n=('hit','size'),pass099_frac=('hit','mean'),id_median=('id','median'),alnlen_median=('alnlen','median')).reset_index().to_excel(w,sheet_name='terminal_gap_summary',index=False)
    tg.drop(columns='stderr_warn').to_excel(w,sheet_name='terminal_gap_raw',index=False)
    pd.read_csv('edge/terminal_gap_realshortrefs.csv').drop(columns='stderr_warn').to_excel(w,sheet_name='real_short_V4_refs',index=False)
    pd.read_csv('edge/iupac_controlled.csv').to_excel(w,sheet_name='iupac',index=False)
    sh=pd.read_csv('edge/short_refs.csv'); sh.to_excel(w,sheet_name='short_refs_kmer',index=False)
print(len(rows))
