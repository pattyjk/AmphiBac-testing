#!/bin/bash
# Exhaustive leave-self-out search (all hits >=97%, iddef 2 default) for R4, study-exclusion R2-R4, Spearman.
F="query+target+id+mism+gaps+alnlen+ids+ql+tl+qilo+qihi"
for fr in 90 100 120 150 V4full V3V4; do
  vsearch --usearch_global frag/q_${fr}_all.fasta --id 0.97 --db db/FullDatabase_2025.1.fasta \
    --userout exh/exh_${fr}.tsv --userfields $F --strand both --qmask none --threads 12 \
    --minseqlength 1 --self --maxaccepts 0 --maxrejects 0 2> exh/exh_${fr}.log
done
