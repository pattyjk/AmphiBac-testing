"""Step 1: in-silico amplicons from AmphiBac 2025.1 isolates.
Fragments start immediately after the 515F site (GTGYCAGCMGCCGCGGTAA) on whichever strand carries it.
Lengths 90/100/120/150 bp; full V4 = after 515F up to (excluding) the 806R site (rc ATTAGAWACCCBNGTAGTCC);
V3V4 = after 341F (CCTACGGGNGGYGCARCAG) up to the 806R site. Primers removed.
All 8,739 FullDatabase seqs are fragmented (needed as refs for nothing; queries = Func in 3 classes)."""
import re, pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
F515 = re.compile('GTG[CT]CAGC[AC]GCCGCGGTAA')
R806 = re.compile('ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC')
# task-supplied 341F regex CCTACGGG[ACGT]GG[CT]GCA[AG]CAG matched 0 seqs; use Klindworth 341F CCTACGGGNGGCWGCAG
F341 = re.compile('CCTACGGG[ACGT]GGC[AT]GCAG')
LENS = [90, 100, 120, 150]
a = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
recs = {r.id: str(r.seq).upper() for r in SeqIO.parse('db/FullDatabase_2025.1.fasta', 'fasta')}
rows = []
for fid, s in recs.items():
    for strand, seq in (('+', s), ('-', str(Seq(s).reverse_complement()))):
        m = F515.search(seq)
        if not m: continue
        st = m.end()
        r = R806.search(seq, st)
        out = {}
        for L in LENS:
            if len(seq) - st >= L: out[str(L)] = seq[st:st+L]
        if r: out['V4full'] = seq[st:r.start()]
        m3 = F341.search(seq)
        if m3 and r and m3.end() < st: out['V3V4'] = seq[m3.end():r.start()]
        for k, v in out.items():
            rows.append(dict(FastaID=fid, frag=k, strand=strand, seq=v, flen=len(v),
                             iupac=bool(re.search('[^ACGT]', v))))
        break   # first strand carrying 515F
fr = pd.DataFrame(rows).merge(a[['Func', 'Bd_label', 'score', 'Reference']], left_on='FastaID', right_index=True)
fr.to_csv('frag/fragments.csv', index=False)
q = fr[fr.Func.isin(['Inhibitory', 'NoEffect', 'Facilitating'])]
for k, g in q.groupby('frag'):
    with open(f'frag/q_{k}_all.fasta', 'w') as fh:   # all, incl. IUPAC; flag kept in csv
        for _, r in g.iterrows(): fh.write(f'>{r.FastaID}\n{r.seq}\n')
summ = q.groupby('frag').agg(n_all=('FastaID', 'size'), n_iupac=('iupac', 'sum'),
        len_med=('flen', 'median'), len_min=('flen', 'min'), len_max=('flen', 'max'))
summ['n_clean'] = summ.n_all - summ.n_iupac
print(summ)
print(q[~q.iupac].groupby(['frag', 'Func']).size().unstack())
