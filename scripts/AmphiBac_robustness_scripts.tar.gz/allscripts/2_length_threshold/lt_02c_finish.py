"""Re-run missing/incomplete default runs from lt_02b_default.py sequentially (6 threads, CPU cap)."""
import os, subprocess, itertools, glob
TH=[0.97,0.98,0.985,0.99,0.995,1.0]; FR=['90','100','120','150','V4full','V3V4']
DBS={'Full':'db/FullDatabase_2025.1.fasta','Inhibitory':'db/Inhibitory_2025.1.fasta','InhibitoryStrict':'db/InhibitoryStrict_2025.1.fasta'}
def nq(f): return sum(1 for l in open(f) if l.startswith('>'))
def nrec(uc): return sum(1 for l in open(uc) if l[0] in 'HN') if os.path.exists(uc) else -1
jobs=[]
for fr,(dn,dp),t in itertools.product(FR,DBS.items(),TH):
    jobs.append((f'frag/q_{fr}_all.fasta',dp,t,f'dflt/self_{fr}_{dn}_{t}.uc',('--self',)))
for q in glob.glob('studydb/q_*.fasta'):
    i=q.split('_')[-1].split('.')[0]
    for dn in DBS:
        for t in TH: jobs.append((q,f'studydb/{dn}_minus{i}.fasta',t,f'dflt/study{i}_{dn}_{t}.uc',()))
todo=[j for j in jobs if nrec(j[3])!=nq(j[0])]
print(len(jobs),'expected;',len(todo),'to run')
for q,db,t,uc,ex in todo:
    subprocess.run(['vsearch','--usearch_global',q,'--id',str(t),'--db',db,'--uc',uc,'--strand','both','--qmask','none',
      '--notmatched',uc.replace('.uc','.unmatched.fasta'),'--threads','6','--minseqlength','1','--fasta_width','0',*ex],
      check=True,stderr=subprocess.DEVNULL)
print('remaining bad:',sum(nrec(j[3])!=nq(j[0]) for j in jobs))
