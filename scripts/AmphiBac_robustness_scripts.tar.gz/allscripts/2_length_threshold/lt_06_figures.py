"""Step 3b: figures. Run inside the analysis kernel after apply_figure_style() (figure-style skill); falls back to defaults."""
import pandas as pd, numpy as np, matplotlib.pyplot as plt, matplotlib as mpl
R=pd.read_csv('lt_metrics_long.csv')
FO=['90','100','120','150','V4full','V3V4']; FL=['90','100','120','150','V4\n(~253)','V3–V4\n(~429)']
TH=[0.97,0.98,0.985,0.99,0.995,1.0]
RULES=[('R1_tophit','R1 Func of default top hit'),('R2_Inhibitory','R2 match to Inhibitory subset'),
       ('R3_InhibitoryStrict','R3 match to InhibitoryStrict'),('R4_majority','R4 majority vote, all hits')]
RC={'R1_tophit':'#000000','R2_Inhibitory':'#009E73','R3_InhibitoryStrict':'#56B4E9','R4_majority':'#CC79A7'}
base=R[(R.iupac=='clean')&(R.truth=='Func')&(R.classes=='binary')&(R.basis=='all')]
nq=base.drop_duplicates('fragment').set_index('fragment').n_queries
def heat(excl,fn):
    mets=[('match_rate','Match rate',(0,1),'viridis'),('balanced_accuracy','Balanced accuracy',(0.5,0.7),'magma'),('kappa',"Cohen's κ",(0,0.35),'magma')]
    fig,axs=plt.subplots(4,3,figsize=(7.2,9.6),constrained_layout=True)
    for i,(r,rl) in enumerate(RULES):
        for j,(m,ml,vl,cm) in enumerate(mets):
            ax=axs[i,j]; x=base[(base.rule==r)&(base.metric==m)&(base.exclusion==excl)]
            M=x.pivot(index='threshold',columns='fragment',values='value').loc[TH,FO].values
            im=ax.imshow(M,cmap=cm,vmin=vl[0],vmax=vl[1],aspect='auto')
            for a_ in range(6):
                for b_ in range(6):
                    v=M[a_,b_]; c=(v-vl[0])/(vl[1]-vl[0])
                    ax.text(b_,a_,f'{v:.2f}',ha='center',va='center',fontsize=6,color='white' if c<0.55 else 'black')
            ax.set_xticks(range(6)); ax.set_xticklabels(FL if i==3 else []); ax.set_yticks(range(6))
            ax.set_yticklabels([f'{t*100:g}%' for t in TH] if j==0 else [])
            if i==0: ax.set_title(ml,loc='left')
            if j==0: ax.set_ylabel(f'{rl}\nidentity threshold')
            if i==3: ax.set_xlabel('Fragment after 515F (bp)')
            if i==3: fig.colorbar(im,ax=axs[:,j],orientation='horizontal',fraction=0.025,pad=0.01,label=ml)
    lab='leave-self-out' if excl=='self' else 'leave-study-out'
    fig.suptitle(f'Bd-inhibition prediction ({lab}) is weak at every length and threshold\n'
                 f'binary Inhibitory vs not; unmatched = non-inhibitory; n = {nq.min()}–{nq.max()} isolates, 28 studies',fontsize=8)
    fig.savefig(fn,dpi=300); return fig
f1=heat('self','lt_fig1_heatmaps_leave_self_out.png'); f2=heat('study','lt_fig2_heatmaps_leave_study_out.png')
# Fig 3: kappa and balanced accuracy curves with cluster-bootstrap CI
fig,axs=plt.subplots(2,6,figsize=(7.2,4.2),sharey='row',constrained_layout=True)
for j,f in enumerate(FO):
    for i,excl in enumerate(['self','study']):
        ax=axs[i,j]
        for r,rl in RULES:
            x=base[(base.rule==r)&(base.metric=='kappa')&(base.exclusion==excl)&(base.fragment==f)].sort_values('threshold')
            xs=np.arange(6)
            ax.plot(xs,x.value,'-o',color=RC[r],ms=2.5,lw=1,label=rl)
            ax.fill_between(xs,x.ci_lo,x.ci_hi,color=RC[r],alpha=0.15,lw=0)
        ax.axhline(0,color='0.5',lw=0.8,ls=':',label='R5 sequence-free baselines (κ = 0)')
        ax.set_xticks(range(6)); ax.set_xticklabels(['97','98','98.5','99','99.5','100'],rotation=90)
        if i==0: ax.set_title(FL[j].replace('\n',' ')+(' bp' if j<4 else ''),loc='left')
        if i==1: ax.set_xlabel('Identity (%)')
        if j==0: ax.set_ylabel(("Leave-self-out" if excl=='self' else "Leave-study-out")+"\nCohen's κ")
        ax.set_ylim(-0.12,0.5); ax.margins(x=0.06)
h,l=axs[0,0].get_legend_handles_labels()
fig.legend(h,l,loc='outside lower center',ncol=3,frameon=False,fontsize=6)
fig.suptitle(f"Agreement with held-out isolate label stays κ ≤ 0.34; study hold-out halves it for R1 and R4 (95% study-cluster bootstrap, n = {nq.min()}–{nq.max()})",fontsize=8)
fig.savefig('lt_fig3_kappa_curves.png',dpi=300)
# Fig 4: sensitivity / specificity / PPV for R2 (pipeline Inhibitory mode) and R1 at 99%, all lengths
fig,axs=plt.subplots(1,3,figsize=(7.2,3.3),sharey=True,constrained_layout=True)
for k,(m,ml) in enumerate([('sensitivity','Sensitivity'),('specificity','Specificity'),('PPV','Positive predictive value')]):
    ax=axs[k]
    for r,rl in RULES:
        for excl,ls,mk in [('self','-','o'),('study','--','s')]:
            x=base[(base.rule==r)&(base.metric==m)&(base.exclusion==excl)&(base.threshold==0.99)].set_index('fragment').loc[FO]
            ax.errorbar(np.arange(6)+(0.08 if excl=='study' else -0.08),x.value,yerr=[x.value-x.ci_lo,x.ci_hi-x.value],
                        color=RC[r],ls=ls,marker=mk,ms=2.5,lw=0.9,capsize=0,elinewidth=0.6,label=f'{rl.split(" ")[0]} {excl}-out')
    if m=='PPV':
        prev=base[(base.rule=='R5_prevalence_random')&(base.metric=='PPV')&(base.exclusion=='self')&(base.threshold==0.99)].set_index('fragment').loc[FO]
        ax.plot(range(6),prev.value,color='0.5',ls=':',lw=1,label='inhibitory prevalence')
    ax.set_xticks(range(6)); ax.set_xticklabels([s.replace('\n',' ') for s in FL],rotation=45,ha='right'); ax.set_title(ml,loc='left')
    ax.set_ylim(0,1.02)
axs[0].set_ylabel('Value at 99% identity')
h,l=axs[2].get_legend_handles_labels(); fig.legend(h,l,loc='outside lower center',ncol=5,frameon=False,fontsize=6)
fig.suptitle('At 99% identity, subset matching (R2/R3) calls most isolates inhibitory: specificity ≤ 0.41, PPV near prevalence',fontsize=8)
fig.savefig('lt_fig4_sens_spec_ppv_99.png',dpi=300)
