"""Step 2a: exact q2-vsearch closed-reference call (maxaccepts 1 / maxrejects 32 defaults) per fragment x db x threshold.
(i) leave-self-out: q2 command + --self (query label == FastaID == target label).
(ii) leave-study-out: exact default search against each db with all isolates of that study removed (per-study dbs;
     exact emulation rather than the 'first-ranked remaining hit' approximation)."""
import os, subprocess, pandas as pd, itertools
from concurrent.futures import ThreadPoolExecutor
from Bio import SeqIO
TH = [0.97, 0.98, 0.985, 0.99, 0.995, 1.00]
FR = ['90', '100', '120', '150', 'V4full', 'V3V4']
DBS = {'Full': 'db/FullDatabase_2025.1.fasta', 'Inhibitory': 'db/Inhibitory_2025.1.fasta',
       'InhibitoryStrict': 'db/InhibitoryStrict_2025.1.fasta'}
os.makedirs('dflt', exist_ok=True); os.makedirs('studydb', exist_ok=True)
a = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
studies = sorted(a.Reference.dropna().unique()); sid = {s: i for i, s in enumerate(studies)}
pd.Series(studies).to_csv('studydb/study_index.csv', header=['Reference'])
def q2(query, db, t, uc, extra=()):
    cmd = ['vsearch', '--usearch_global', query, '--id', str(t), '--db', db, '--uc', uc, '--strand', 'both',
           '--qmask', 'none', '--notmatched', uc.replace('.uc', '.unmatched.fasta'), '--threads', '4',
           '--minseqlength', '1', '--fasta_width', '0', *extra]
    subprocess.run(cmd, check=True, stderr=subprocess.DEVNULL)
jobs = []
for fr, (dn, dp), t in itertools.product(FR, DBS.items(), TH):
    jobs.append((f'frag/q_{fr}_all.fasta', dp, t, f'dflt/self_{fr}_{dn}_{t}.uc', ('--self',)))
# per-study dbs and per-study query files (all fragments, label FastaID|frag)
fr_all = pd.read_csv('frag/fragments.csv'); fr_all = fr_all[fr_all.Func.isin(['Inhibitory', 'NoEffect', 'Facilitating'])]
dbseq = {dn: list(SeqIO.parse(dp, 'fasta')) for dn, dp in DBS.items()}
for s, i in sid.items():
    g = fr_all[fr_all.Reference == s]
    if g.empty: continue
    excl = set(a.index[a.Reference == s])
    with open(f'studydb/q_{i}.fasta', 'w') as fh:
        for _, r in g.iterrows(): fh.write(f'>{r.FastaID}|{r.frag}\n{r.seq}\n')
    for dn, recs in dbseq.items():
        p = f'studydb/{dn}_minus{i}.fasta'
        with open(p, 'w') as fh:
            for r in recs:
                if r.id not in excl: fh.write(f'>{r.id}\n{r.seq}\n')
        for t in TH: jobs.append((f'studydb/q_{i}.fasta', p, t, f'dflt/study{i}_{dn}_{t}.uc', ()))
print(len(jobs), 'runs')
with ThreadPoolExecutor(3) as ex: list(ex.map(lambda j: q2(*j), jobs))
print('done')
