"""Step 2c: metrics with study-cluster bootstrap (B=1000, resample studies with replacement).
basis 'all': every held-out isolate scored; no call -> non-inhibitory / NoEffect (what the pipeline effectively does).
basis 'matched': only isolates with a call (R1: any top hit; R4: >=1 labelled qualifying ref). Untested top hits
(NotTested/PossibleContamination) are a separate, always-wrong 3-class category and non-inhibitory in binary.
truth 'Func' (primary) or 'Bd_label' (sensitivity; binary only; isolates with Bd_label)."""
import pandas as pd, numpy as np
from scipy.stats import spearmanr
B=1000; CL=['Inhibitory','NoEffect','Facilitating']; PC=CL+['Untested']
P=pd.read_csv('pred_per_query.csv.gz',low_memory=False)
for c in ['R2','R3','R2x','R3x','R4_has','R4_bin','iupac']: P[c]=P[c].astype(bool)
P['R1_has']=P.R1_hit.notna()
P['R1_3']=np.where(P.R1_has, np.where(P.R1_3.isin(CL),P.R1_3,'Untested'), None)
P['R1_bin']=P.R1_3=='Inhibitory'
def bin_stats(TP,FP,TN,FN,M,N):
    n=TP+FP+TN+FN
    with np.errstate(all='ignore'):
        se=TP/(TP+FN); sp=TN/(TN+FP); pe=((TP+FP)*(TP+FN)+(FN+TN)*(FP+TN))/n**2; acc=(TP+TN)/n
        return dict(match_rate=M/N, n_scored=n, accuracy=acc, sensitivity=se, specificity=sp, PPV=TP/(TP+FP),
                    NPV=TN/(TN+FN), balanced_accuracy=(se+sp)/2, kappa=(acc-pe)/(1-pe))
def tri_stats(cm,M,N):   # cm (...,3,4)
    n=cm.sum((-1,-2)); po=np.trace(cm[...,:3],axis1=-2,axis2=-1)/n
    r=cm.sum(-1); c=cm.sum(-2)[...,:3]; pe=(r*c).sum(-1)/n**2
    with np.errstate(all='ignore'):
        rec=np.diagonal(cm[...,:3],axis1=-2,axis2=-1)/r
        return dict(match_rate=M/N, n_scored=n, accuracy=po, balanced_accuracy=np.nanmean(rec,-1) if rec.ndim>1 else np.nanmean(rec), kappa=(po-pe)/(1-pe))
rows=[]; rng=np.random.default_rng(1)
Wcache={}
for (f,excl,t,kv),D in P.groupby(['frag','excl','t',P.iupac]) if False else []: pass
for iup in ['clean','with_IUPAC']:
    for (f,excl,t),D in P.groupby(['frag','excl','t']):
        if iup=='clean': D=D[~D.iupac]
        studies=np.array(sorted(D.Reference.unique())); S=len(studies)
        key=(iup,f)
        if key not in Wcache: Wcache[key]=rng.multinomial(S,np.ones(S)/S,size=B)
        W=Wcache[key]; si=pd.Categorical(D.Reference,categories=studies).codes
        for truth in ['Func','Bd_label']:
            DD=D if truth=='Func' else D[D.Bd_label.notna()]
            ssi=si if truth=='Func' else pd.Categorical(DD.Reference,categories=studies).codes
            y=(DD.Func if truth=='Func' else DD.Bd_label).eq('Inhibitory').values
            for rule,pred,has in [('R1_tophit',DD.R1_bin.values,DD.R1_has.values),('R2_Inhibitory',DD.R2.values,DD.R2.values),
                                  ('R3_InhibitoryStrict',DD.R3.values,DD.R3.values),('R2x_Inhibitory_exhaustive',DD.R2x.values,DD.R2x.values),
                                  ('R3x_Strict_exhaustive',DD.R3x.values,DD.R3x.values),('R4_majority',DD.R4_bin.values,DD.R4_has.values)]:
                for basis in (['all','matched'] if rule.startswith(('R1','R4')) else ['all']):
                    keep=np.ones(len(y),bool) if basis=='all' else has
                    yy,pp,ss=y[keep],pred[keep],ssi[keep]
                    cnt=np.zeros((S,6))
                    for j,v in enumerate([yy&pp,~yy&pp,~yy&~pp,yy&~pp]): np.add.at(cnt[:,j],ss,v)
                    np.add.at(cnt[:,4],ssi,has); np.add.at(cnt[:,5],ssi,1)
                    pt=bin_stats(*cnt.sum(0)); bs=bin_stats(*(W@cnt).T)
                    for m,v in pt.items():
                        lo,hi=np.nanpercentile(bs[m],[2.5,97.5]) if m!='n_scored' else (np.nan,np.nan)
                        rows.append(dict(fragment=f,exclusion=excl,threshold=t,iupac=iup,truth=truth,classes='binary',rule=rule,basis=basis,metric=m,value=v,ci_lo=lo,ci_hi=hi,n_queries=len(y),n_studies=S))
            # baselines (sequence-free): prevalence-random and always-non-inhibitory, expected values
            cntb=np.zeros((S,2)); np.add.at(cntb[:,0],ssi,y); np.add.at(cntb[:,1],ssi,1)
            for c_,p in [('pt',cntb.sum(0)[None,:]),('bs',W@cntb)]:
                pass
            def base(cn):
                p=cn[:,0]/cn[:,1]
                return {'R5_prevalence_random':dict(match_rate=np.ones_like(p),accuracy=p**2+(1-p)**2,sensitivity=p,specificity=1-p,PPV=p,NPV=1-p,balanced_accuracy=0.5+0*p,kappa=0*p),
                        'R5_always_noninhibitory':dict(match_rate=np.ones_like(p),accuracy=1-p,sensitivity=0*p,specificity=1+0*p,PPV=np.nan*p,NPV=1-p,balanced_accuracy=0.5+0*p,kappa=0*p)}
            bp=base(cntb.sum(0)[None,:]); bb=base(W@cntb)
            for r_ in bp:
                for m in bp[r_]:
                    lo,hi=np.nanpercentile(bb[r_][m],[2.5,97.5]) if np.isfinite(bb[r_][m]).any() else (np.nan,np.nan)
                    rows.append(dict(fragment=f,exclusion=excl,threshold=t,iupac=iup,truth=truth,classes='binary',rule=r_,basis='all',metric=m,value=float(bp[r_][m][0]),ci_lo=lo,ci_hi=hi,n_queries=len(y),n_studies=S))
        # 3-class (Func truth)
        y3=pd.Categorical(D.Func,categories=CL).codes
        for rule,pc,has in [('R1_tophit','R1_3','R1_has'),('R4_majority','R4_3','R4_has')]:
            for basis in ['all','matched']:
                keep=np.ones(len(D),bool) if basis=='all' else D[has].values
                pr=D[pc].where(D[has],'NoEffect') if basis=='all' else D[pc]
                if basis=='all': pr=pr.replace('Untested','NoEffect')
                p3=pd.Categorical(pr,categories=PC).codes
                cm=np.zeros((S,3,4)); np.add.at(cm,(si[keep],y3[keep],p3[keep]),1)
                M=np.bincount(si,weights=D[has].values,minlength=S); N=np.bincount(si,minlength=S)
                pt=tri_stats(cm.sum(0),M.sum(),N.sum()); bs=tri_stats(np.einsum('bs,sij->bij',W,cm),W@M,W@N)
                for m,v in pt.items():
                    lo,hi=np.nanpercentile(bs[m],[2.5,97.5]) if m!='n_scored' else (np.nan,np.nan)
                    rows.append(dict(fragment=f,exclusion=excl,threshold=t,iupac=iup,truth='Func',classes='3class',rule=rule,basis=basis,metric=m,value=float(v),ci_lo=lo,ci_hi=hi,n_queries=len(D),n_studies=S))
        # Spearman: query score vs mean score of qualifying refs
        Ds=D.dropna(subset=['score','ref_mean_score']); sis=pd.Categorical(Ds.Reference,categories=studies).codes
        if len(Ds)>10:
            rho,pv=spearmanr(Ds.score,Ds.ref_mean_score); idx_by=[np.where(sis==k)[0] for k in range(S)]
            bsr=[]
            for b in range(B):
                ix=np.concatenate([np.repeat(idx_by[k],0) if W[b,k]==0 else np.tile(idx_by[k],W[b,k]) for k in range(S)])
                if len(ix)>10: bsr.append(spearmanr(Ds.score.values[ix],Ds.ref_mean_score.values[ix])[0])
            lo,hi=np.nanpercentile(bsr,[2.5,97.5])
            rows.append(dict(fragment=f,exclusion=excl,threshold=t,iupac=iup,truth='score',classes='continuous',rule='R4_meanscore',basis='matched',metric='spearman_rho',value=rho,ci_lo=lo,ci_hi=hi,n_queries=len(Ds),n_studies=int((np.bincount(sis,minlength=S)>0).sum()),p_value=pv))
    print(iup,'done',flush=True)
R=pd.DataFrame(rows); R.to_csv('lt_metrics_long.csv',index=False); print(R.shape)
