"""Step 3a: threshold -> max mismatches per length (iddef 2: id = matches/aligned cols, terminal gaps excluded),
theoretical (gapless, query fully aligned; vsearch test 100*(L-m)/L >= 100*t in double) vs empirical from exhaustive hits."""
import pandas as pd, numpy as np
TH=[0.97,0.98,0.985,0.99,0.995,1.0]
cols='query target id mism gaps alnlen ids ql tl qilo qihi'.split()
rows=[]
for f,L in [('90',90),('100',100),('120',120),('150',150),('V4full',253),('V3V4',429)]:
    e=pd.read_csv(f'exh/exh_{f}.tsv',sep='\t',names=cols,usecols=['mism','gaps','alnlen','ids','ql'])
    e['idx']=100.0*e.ids/e.alnlen
    full=e[(e.ql==L)&(e.alnlen==L)&(e.gaps==0)]
    for t in TH:
        th=max(m for m in range(L+1) if 100.0*(L-m)/L>=100.0*t)
        q=full[full.idx>=100.0*t]; nq=full[full.idx<100.0*t]
        allq=e[(e.ql==L)&(e.idx>=100.0*t)]
        rows.append(dict(fragment=f,length=L,threshold=t,theoretical_max_mismatches=th,
            empirical_max_mismatches_qualifying=int(q.mism.max()) if len(q) else np.nan,
            empirical_min_mismatches_rejected=int(nq.mism.min()) if len(nq) else np.nan,
            n_fulllength_gapless_hits=len(full),
            verified=(len(q)==0 or q.mism.max()<=th) and (len(nq)==0 or nq.mism.min()==th+1),
            max_mism_plus_gaps_any_qualifying=int((allq.mism+allq.gaps).max()) if len(allq) else np.nan,
            pct_qualifying_hits_partial_query=100*(allq.alnlen<allq.ql).mean(),
            min_aligned_cols_qualifying=int(allq.alnlen.min()) if len(allq) else np.nan))
T=pd.DataFrame(rows); T.to_csv('lt_mismatch_table.csv',index=False)
print(T.pivot(index='threshold',columns='fragment',values='theoretical_max_mismatches')[['90','100','120','150','V4full','V3V4']])
print('all verified:',T.verified.all())
print(T[['fragment','threshold','empirical_max_mismatches_qualifying','empirical_min_mismatches_rejected','pct_qualifying_hits_partial_query','min_aligned_cols_qualifying']].query('threshold in [0.97,0.99,1.0]').to_string(index=False))
