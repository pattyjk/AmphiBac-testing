"""Step 2b: per-query predictions for every fragment x threshold x exclusion mode.
R1  Func of q2-default top hit (uc) vs Full db.     R2/R3 matched Inhibitory / InhibitoryStrict (default call).
R2x/R3x same but exhaustive (any qualifying Inhibitory/Strict ref).  R4 majority vote over all qualifying refs (exhaustive).
Exact iddef-2 identity = 100*ids/alnlen (verified == vsearch 'id'); qualify iff that >= 100*t (vsearch's comparison)."""
import pandas as pd, numpy as np
TH=[0.97,0.98,0.985,0.99,0.995,1.0]; FR=['90','100','120','150','V4full','V3V4']
CL=['Inhibitory','NoEffect','Facilitating']
a=pd.read_csv('db/audit_per_sequence.csv',index_col=0)
a['Reference']=a.Reference.fillna('NA')
sidx=pd.read_csv('studydb/study_index.csv',index_col=0).Reference; sid={s:i for i,s in sidx.items()}
inh=set(a.index[a.in_Inhibitory]); strict=set(a.index[a.in_InhibitoryStrict])
fr=pd.read_csv('frag/fragments.csv'); fr=fr[fr.Func.isin(CL)]
cols='query target id mism gaps alnlen ids ql tl qilo qihi'.split()
def read_uc(p, split=False):
    u=pd.read_csv(p,sep='\t',header=None,usecols=[0,8,9],names=['t','q','h'],dtype=str)
    if split:
        u[['q','frag']]=u.q.str.split('|',expand=True)
    u['h']=u.h.where(u.t=='H'); return u
out=[]; checks=[]
for f in FR:
    q=fr[fr.frag==f].set_index('FastaID')
    e=pd.read_csv(f'exh/exh_{f}.tsv',sep='\t',names=cols,usecols=['query','target','ids','alnlen','mism','gaps','ql'])
    e['idx']=100.0*e.ids/e.alnlen
    e=e.sort_values('idx',ascending=False).drop_duplicates(['query','target'])  # strand duplicates
    e['tFunc']=a.Func.reindex(e.target).values; e['tScore']=a.score.reindex(e.target).values
    e['same']=a.Reference.reindex(e.target).values==a.Reference.reindex(e['query']).values
    e['partial']=e.alnlen<e.ql
    for excl in ['self','study']:
        E=e if excl=='self' else e[~e.same]
        for t in TH:
            Q=E[E.idx>=100.0*t]
            d=pd.DataFrame(index=q.index)
            g=Q.groupby('query')
            d['n_qual']=g.size().reindex(d.index).fillna(0).astype(int)
            vc=Q[Q.tFunc.isin(CL)].groupby(['query','tFunc']).size().unstack(fill_value=0).reindex(columns=CL,fill_value=0)
            vc=vc.reindex(d.index).fillna(0)
            ni,nn,nf=vc.Inhibitory,vc.NoEffect,vc.Facilitating
            d['R4_has']=(ni+nn+nf)>0
            d['R4_bin']=np.where(d.R4_has, ni>(nn+nf), False)          # tie -> non-inhibitory
            plural=np.select([(ni>nn)&(ni>nf),(nf>nn)&(nf>ni)],['Inhibitory','Facilitating'],'NoEffect')  # ties -> NoEffect
            d['R4_3']=np.where(d.R4_has,plural,None)
            d['R2x']=Q[Q.target.isin(inh)].groupby('query').size().reindex(d.index).fillna(0)>0
            d['R3x']=Q[Q.target.isin(strict)].groupby('query').size().reindex(d.index).fillna(0)>0
            sc=Q.dropna(subset=['tScore']).groupby('query').tScore.mean(); d['ref_mean_score']=sc.reindex(d.index)
            d['frac_partial_qual']=g.partial.mean().reindex(d.index)
            # default runs
            if excl=='self':
                U={dn:read_uc(f'dflt/self_{f}_{dn}_{t}.uc').set_index('q').h for dn in ['Full','Inhibitory','InhibitoryStrict']}
            else:
                U={}
                for dn in ['Full','Inhibitory','InhibitoryStrict']:
                    parts=[]
                    for s,gq in q.groupby('Reference'):
                        u=read_uc(f'dflt/study{sid[s]}_{dn}_{t}.uc',split=True); parts.append(u[u.frag==f].set_index('q').h)
                    U[dn]=pd.concat(parts)
            d['R1_hit']=U['Full'].reindex(d.index)
            d['R1_3']=a.Func.reindex(d.R1_hit).values
            d['R2']=U['Inhibitory'].reindex(d.index).notna().values
            d['R3']=U['InhibitoryStrict'].reindex(d.index).notna().values
            # R1 top-hit alignment info from exhaustive table
            key=pd.MultiIndex.from_arrays([d.index,d.R1_hit.fillna('')])
            ee=E.set_index(['query','target'])
            inf=ee.reindex(key)
            d['R1_partial']=inf.partial.values; d['R1_idx']=inf.idx.values
            # consistency checks: default hits must qualify in exhaustive set
            hit=d.R1_hit.notna()
            checks.append(dict(frag=f,excl=excl,t=t,n_default_hits=int(hit.sum()),
                default_hit_not_in_exh=int(inf.idx[hit.values].isna().sum()),
                default_hit_below_t=int((inf.idx[hit.values]<100*t).sum()),
                exh_match_default_miss=int(((d.n_qual>0)&~hit).sum()),
                default_match_exh_miss=int(((d.n_qual==0)&hit).sum()),
                R2_default_vs_exh_disagree=int((d.R2!=d.R2x).sum()),
                self_hits_in_exh=int((Q['query']==Q['target']).sum())))
            d=d.join(q[['Func','Bd_label','score','Reference','iupac','flen']])
            d['frag']=f; d['excl']=excl; d['t']=t
            out.append(d.reset_index())
    print(f, 'done', flush=True)
P=pd.concat(out,ignore_index=True)
P.to_csv('pred_per_query.csv.gz',index=False)
C=pd.DataFrame(checks); C.to_csv('consistency_checks.csv',index=False)
print(C.drop(columns=['excl']).groupby(C.excl).sum(numeric_only=True).drop(columns='t'))
