"""Step 1c: near-full-length (>=1200 bp, <=5 IUPAC; n=1,884) all-pairs identity (vsearch iddef 2, terminal gaps
ignored), restricted to pairs sharing >=1,000 aligned bp. Compares label agreement by full-length identity with
the V4 differences for the same pairs, within vs between study."""
import numpy as np, pandas as pd
d = pd.read_csv('work/isolates_v4.csv', index_col=0)
p = pd.read_csv('work/full_allpairs.tsv', sep='\t', header=None,
                names=['q', 't', 'id', 'mism', 'gaps', 'alnlen', 'ids', 'qilo', 'qihi', 'tilo', 'tihi'])
p['overlap'] = np.minimum(p.qihi - p.qilo + 1, p.tihi - p.tilo + 1)
print('pairs:', len(p), ' with overlap>=1000:', (p.overlap >= 1000).sum())
p = p[p.overlap >= 1000].copy()
# V4 differences for the same pairs
U = pd.read_csv('work/v4_allpairs.tsv', sep='\t', header=None, names=['a', 'b', 'id', 'mism', 'gaps', 'alnlen', 'ids'])
U['diff'] = U.alnlen - U.ids
dm = {**{(r.a, r.b): r.diff for r in U.itertuples()}, **{(r.b, r.a): r.diff for r in U.itertuples()}}
uq, ut = d.uid.reindex(p.q).values, d.uid.reindex(p.t).values
p['v4diff'] = [0 if a == b else dm[(a, b)] for a, b in zip(uq, ut)]
for c in ('Func', 'study', 'score'):
    p[c + '_q'] = d[c].reindex(p.q).values; p[c + '_t'] = d[c].reindex(p.t).values
p['within'] = p.study_q == p.study_t
iq, it = p.Func_q == 'Inhibitory', p.Func_t == 'Inhibitory'
p['sameb'] = iq == it; p['both'] = iq & it; p['one'] = iq ^ it
p['sdiff'] = (p.score_q - p.score_t).abs()
p['full_bin'] = pd.cut(p.id, [0, 97, 98, 99, 99.5, 99.9999, 100.1], right=False,
                       labels=['<97', '97-98', '98-99', '99-99.5', '99.5-<100', '100'])
p['v4_bin'] = np.where(p.v4diff == 0, 'V4 identical', np.where(p.v4diff <= 3, 'V4 1-3', 'V4 >3'))
p.to_csv('work/full_pairs_overlap1000.csv.gz', index=False, compression='gzip')
def agg(g):
    nb, no = g.both.sum(), g.one.sum(); s = g.sdiff.dropna()
    return pd.Series(dict(n_pairs=len(g), P_same_binary=g.sameb.mean(),
        P_partner_inh_given_inh=2 * nb / (2 * nb + no) if (2 * nb + no) else np.nan,
        absdiff_score_median=s.median() if len(s) else np.nan, n_scored=len(s)))
rows = []
for w, nm in ((None, 'all'), (True, 'within-study'), (False, 'between-study')):
    g0 = p if w is None else p[p.within == w]
    r = g0.groupby('full_bin', observed=True).apply(agg).reset_index().rename(columns={'full_bin': 'bin'})
    r.insert(0, 'grouping', 'full-length identity'); r.insert(0, 'stratum', nm); rows.append(r)
    r2 = g0[g0.v4diff == 0].groupby('full_bin', observed=True).apply(agg).reset_index().rename(columns={'full_bin': 'bin'})
    r2.insert(0, 'grouping', 'V4 identical, by full-length identity'); r2.insert(0, 'stratum', nm); rows.append(r2)
    rr = agg(g0); rows.append(pd.DataFrame([dict(stratum=nm, grouping='baseline (all >=1000bp-overlap pairs)', bin='all', **rr)]))
res = pd.concat(rows, ignore_index=True); res.to_csv('out/decay_fulllength_bins.csv', index=False)
pd.set_option('display.width', 250)
print(res.round(3).to_string())
print(pd.crosstab(p.v4_bin, p.full_bin))
