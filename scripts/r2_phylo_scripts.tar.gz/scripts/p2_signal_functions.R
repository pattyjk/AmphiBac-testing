## Shared functions: expand unique-sequence tree to isolate tips; consenTRAIT tauD (Martiny et al. 2013) vectorised
suppressPackageStartupMessages({library(ape); library(phytools); library(Matrix)})
EPS <- 1e-6
expand_tree <- function(tr, map) {      # map: data.frame(FastaID, uid); identical V4 -> star polytomy with EPS branches
  s <- write.tree(tr)
  grp <- split(map$FastaID, map$uid)
  tok <- regmatches(s, gregexpr("[(),:;]|[^(),:;]+", s))[[1]]
  isl <- c(FALSE, tok[-length(tok)] %in% c("(", ","))  & !(tok %in% c("(", ")", ",", ":", ";"))
  for (i in which(isl)) { g <- grp[[tok[i]]]
    tok[i] <- if (length(g) == 1) g else paste0("(", paste0(g, ":", EPS, collapse = ","), ")") }
  read.tree(text = paste(tok, collapse = ""))
}
prep_consentrait <- function(tr) {      # incidence matrices for vectorised clade counts
  n <- Ntip(tr); N <- tr$Nnode; nn <- n + N
  par <- integer(nn); par[tr$edge[, 2]] <- tr$edge[, 1]           # parent of each node (0 = root)
  anc <- vector("list", nn)                                       # all proper ancestors per node
  ord <- c(n + 1, tr$edge[reorder(tr, "cladewise", index.only = TRUE), 2])   # preorder
  anc[[n + 1]] <- integer(0)
  for (k in ord[-1]) anc[[k]] <- c(par[k], anc[[par[k]]])
  # M: internal nodes x tips (1 if tip descends from node)
  ii <- unlist(lapply(1:n, function(t) anc[[t]])); jj <- rep(1:n, sapply(anc[1:n], length))
  M <- sparseMatrix(i = ii - n, j = jj, x = 1, dims = c(N, n))
  # A: internal nodes x internal nodes, A[k, a] = 1 if a is a proper ancestor of k
  ia <- unlist(lapply((n + 1):nn, function(k) rep(k - n, length(anc[[k]])))); ja <- unlist(anc[(n + 1):nn]) - n
  A <- sparseMatrix(i = ia, j = ja, x = 1, dims = c(N, N))
  nd <- node.depth.edgelength(tr)
  ntip <- as.numeric(M %*% rep(1, n))
  meandepth <- as.numeric(M %*% nd[1:n]) / ntip - nd[(n + 1):nn]
  tipedge <- tr$edge.length[match(1:n, tr$edge[, 2])]
  list(M = M, A = A, MT = t(M), ntip = ntip, meandepth = meandepth, tipedge = tipedge, n = n)
}
consentrait <- function(P, L, thr = 0.9) {  # L: tips x reps 0/1 matrix; returns tauD and cluster stats per column
  L <- Matrix(L, sparse = FALSE)
  pos <- as.matrix(P$M %*% L)
  sat <- (pos / P$ntip >= thr) * 1
  ancsat <- as.matrix(P$A %*% sat)
  maxi <- (sat == 1) & (ancsat == 0)
  tipcov <- as.matrix(P$MT %*% sat) > 0
  single <- (as.matrix(L) == 1) & !tipcov
  sapply(seq_len(ncol(L)), function(r) {
    dcl <- P$meandepth[maxi[, r]]; ds <- P$tipedge[single[, r]] / 2
    c(tauD = mean(c(dcl, ds)), tauD_clades_only = mean(dcl), n_clades = length(dcl), n_singletons = length(ds),
      tips_in_clades = sum(P$ntip[maxi[, r]]))
  })
}
perm_within <- function(x, g) { for (k in unique(g)) { i <- which(g == k); if (length(i) > 1) x[i] <- x[sample.int(length(i))] }; x }
