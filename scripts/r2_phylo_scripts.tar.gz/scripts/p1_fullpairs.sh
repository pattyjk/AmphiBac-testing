# all-vs-all global alignment of near-full-length (>=1200 bp, <=5 IUPAC) labelled isolates, oriented to + strand
vsearch --allpairs_global work/full_subset.fasta --acceptall --threads 4 --qmask none \
  --userout work/full_allpairs.tsv --userfields query+target+id+mism+gaps+alnlen+ids+qilo+qihi+tilo+tihi --quiet
