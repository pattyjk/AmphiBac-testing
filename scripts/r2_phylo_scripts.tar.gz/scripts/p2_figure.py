"""Figure: phylogenetic-signal tests vs permutation/simulation nulls."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
try: apply_figure_style(sizes=(8, 7, 6))
except NameError: pass
INH = '#2166AC'; G = '#9a9a9a'; W = '#1b1b1b'
ct = pd.read_csv('out/signal_consentrait.csv'); cu = pd.read_csv('out/signal_consentrait_uniqueV4.csv')
K = pd.read_csv('out/signal_K_lambda_fulllength.csv'); D = pd.read_csv('out/signal_D.csv'); Df = pd.read_csv('out/signal_D_fulllength.csv')
fig, axs = plt.subplots(2, 2, figsize=(7.0, 5.4), constrained_layout=True); axs = axs.ravel()
def tau_panel(ax, fg, fw, obs, title, n):
    for f, c, lab in ((fg, G, 'null: shuffled across all'), (fw, W, 'null: shuffled within study')):
        v = pd.read_csv(f).tauD * 1e3
        if c == G: ax.hist(v, bins=40, color=c, alpha=0.6, label=lab)
        else: ax.hist(v, bins=40, histtype='step', color=c, lw=1.1, label=lab)
    ax.axvline(obs * 1e3, color=INH, lw=2); ax.text(obs * 1e3, ax.get_ylim()[1] * 1.2, 'observed ', color=INH, va='top', ha='right', fontsize=7)
    ax.set_xlabel('τD, consenTRAIT clade depth (×10⁻³ subst./site)'); ax.set_ylabel('Permutations (of 999)')
    ax.set_ylim(0, ax.get_ylim()[1] * 1.6); ax.set_title(title, loc='left'); ax.text(0.98, 0.97, n, transform=ax.transAxes, ha='right', va='top', fontsize=6, color='0.3')
o = ct[(ct.tree.str.startswith('near')) & (ct.null == 'global')].iloc[0]
tau_panel(axs[0], 'work/null_tau_full_Inhibitory_global.csv', 'work/null_tau_full_Inhibitory_within-study.csv', o.tauD_obs,
          'Full-length: deeper than random, not than study mix', f'n = {int(o.n_tips):,} isolates\n{int(o.n_positive)} inhibitory')
axs[0].legend(frameon=False, loc='upper left', fontsize=6)
ou = cu[(cu.rep == 1) & (cu.null == 'global')].iloc[0]
tau_panel(axs[1], 'work/null_tau_uniqueV4_global.csv', 'work/null_tau_uniqueV4_within-study.csv', ou.tauD_obs,
          'V4: inhibitory clades no deeper than random', f'n = {int(ou.n_tips):,} unique V4\n(1 random isolate each; draw 1 of 10)')
ax = axs[2]
kn = pd.read_csv('work/null_K_full_raw.csv').K_null * 1e5; kr = K.iloc[0]
ax.hist(kn, bins=40, color=G, alpha=0.6); ax.axvline(kr.K * 1e5, color=INH, lw=2)
ax.text(kr.K * 1e5, ax.get_ylim()[1] * 0.97, f' observed K = {kr.K:.1e}', color=INH, va='top', ha='right', fontsize=7)
ax.set_xlabel("Blomberg's K on CFS score (×10⁻⁵; Brownian motion = 1)"); ax.set_ylabel('Tip shuffles (of 999)')
ax.set_title('Score signal is detectable but tiny', loc='left')
ax.text(0.40, 0.70, f"n = {int(kr.n_tips):,} scored isolates\n(near-full-length tree)\nPagel's λ = {kr['lambda']:.2f}", transform=ax.transAxes, ha='left', fontsize=6, color='0.3')
ax = axs[3]
ys = [D.D.values, [Df.D.iloc[0]]]
ax.scatter(D.D, np.zeros(len(D)) + 1, color=INH, s=16, zorder=3); ax.scatter(Df.D, [0], color=INH, s=16, marker='s', zorder=3)
ax.axvline(1, color=G, ls='--', lw=1); ax.axvline(0, color=W, ls='--', lw=1); ax.axvline(0.07, color='0.6', ls=':', lw=1)
ax.text(0.98, 1.6, 'random\n(D = 1)', ha='right', fontsize=6, color='0.35'); ax.text(-0.03, 1.6, 'Brownian\n(D = 0)', ha='right', fontsize=6, color='0.2')
ax.text(0.09, -0.55, 'typical microbial\ntrait (D ≈ 0.07)', ha='left', fontsize=6, color='0.4')
ax.set_yticks([0, 1]); ax.set_yticklabels([f'full-length\n(n = {int(Df.n_tips.iloc[0]):,})', f'unique V4\n(n = {int(D.n_tips.iloc[0]):,}; 5 draws)'])
ax.set_ylim(-0.9, 2.0); ax.set_xlim(-0.4, 1.12); ax.set_xlabel('Fritz–Purvis D, inhibitory vs not')
ax.set_title('Inhibition is weakly clumped (D ≫ typical traits)', loc='left')
for a_, L in zip(axs, 'abcd'): a_.text(-0.02, 1.02, L, transform=a_.transAxes, fontweight='bold', fontsize=10, ha='right', va='bottom')
fig.savefig('out/fig_r2_tree_signal_nulls.png', dpi=300)
