"""Step 1b: function-decay curve over exhaustive isolate pairs (no subsampling).
Pair distance = V4 differences = alnlen - identities from vsearch --allpairs_global of unique V4s (terminal gaps
count as differences; identical V4 = 0). Strata: within-study, between-study (study = Reference, unpublished split by
Researchers), and same-Isolate.ID pairs reported separately."""
import numpy as np, pandas as pd
d = pd.read_csv('work/isolates_v4.csv', index_col=0)
m = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', index_col=0, low_memory=False, usecols=['FastaID', 'Isolate.ID'])
d = d.join(m)
U = sorted(d.uid.unique(), key=lambda s: int(s[1:])); ui = {u: i for i, u in enumerate(U)}
D = np.full((len(U), len(U)), 999, dtype=np.int16); np.fill_diagonal(D, 0)
p = pd.read_csv('work/v4_allpairs.tsv', sep='\t', header=None, names=['q', 't', 'id', 'mism', 'gaps', 'alnlen', 'ids'])
qi = p.q.map(ui).values; ti = p.t.map(ui).values; diff = (p.alnlen - p.ids).values.astype(np.int16)
D[qi, ti] = diff; D[ti, qi] = diff
assert (D == 999).sum() == 0
u = d.uid.map(ui).values
lab = d.Func.map({'Inhibitory': 0, 'NoEffect': 1, 'Facilitating': 2}).values
st = pd.factorize(d.study)[0]; iso = pd.factorize(d['Isolate.ID'].fillna('NA_' + d.index.to_series()))[0]
sc = d.score.values
n = len(d); I, J = np.triu_indices(n, 1)
I = I.astype(np.int32); J = J.astype(np.int32)
dd = D[u[I], u[J]]
edges = [(0, 0, '0'), (1, 1, '1'), (2, 2, '2'), (3, 3, '3'), (4, 5, '4-5'), (6, 10, '6-10'), (11, 20, '11-20'), (21, 9999, '>20')]
binlab = np.empty(len(dd), dtype=object)
b = np.full(len(dd), -1, np.int8)
for k, (lo, hi, _) in enumerate(edges): b[(dd >= lo) & (dd <= hi)] = k
within = st[I] == st[J]; sameiso = iso[I] == iso[J]
li, lj = lab[I], lab[J]
inh_i, inh_j = li == 0, lj == 0
same3 = li == lj; sameb = inh_i == inh_j
both = inh_i & inh_j; one = inh_i ^ inh_j
fac_both = (li == 2) & (lj == 2); fac_one = (li == 2) ^ (lj == 2)
sdiff = np.abs(sc[I] - sc[J])
# study-prevalence-adjusted expected binary agreement (labels independent of sequence, given each isolate's study)
pst = pd.Series(lab == 0).groupby(st).mean().values
pi_, pj_ = pst[st[I]], pst[st[J]]
expb = pi_ * pj_ + (1 - pi_) * (1 - pj_)
print('Isolate.ID unique among', n, 'isolates:', len(np.unique(iso)), '; same-Isolate.ID pairs:', int(sameiso.sum()))
def summarise(mask, name):
    rows = []
    for k, (lo, hi, bl) in list(enumerate(edges)) + [(-9, (0, 9999, 'random pair (all)'))]:
        mk = mask if k == -9 else mask & (b == k)
        npair = int(mk.sum())
        if npair == 0: rows.append(dict(stratum=name, bin=bl, n_pairs=0)); continue
        nb, no = both[mk].sum(), one[mk].sum()
        s = sdiff[mk]; s = s[~np.isnan(s)]
        ui_ = np.unique(np.concatenate([u[I][mk], u[J][mk]]))
        rows.append(dict(stratum=name, bin=bl, n_pairs=npair, n_isolates=len(np.unique(np.concatenate([I[mk], J[mk]]))),
            n_unique_V4=len(ui_), P_same_3class=same3[mk].mean(), P_same_binary=sameb[mk].mean(),
            P_same_binary_expected_studyprev=expb[mk].mean(),
            kappa_binary_vs_studyprev=(sameb[mk].mean() - expb[mk].mean()) / (1 - expb[mk].mean()),
            P_partner_inh_given_inh=2 * nb / (2 * nb + no) if (2 * nb + no) else np.nan,
            P_partner_fac_given_fac=(2 * fac_both[mk].sum() / (2 * fac_both[mk].sum() + fac_one[mk].sum())) if (fac_both[mk].sum() + fac_one[mk].sum()) else np.nan,
            n_pairs_with_inh=int(nb + no), n_pairs_scored=len(s),
            absdiff_score_median=np.median(s) if len(s) else np.nan,
            absdiff_score_q25=np.percentile(s, 25) if len(s) else np.nan,
            absdiff_score_q75=np.percentile(s, 75) if len(s) else np.nan))
    return rows
allm = np.ones(len(dd), bool)
res = pd.DataFrame(summarise(allm, 'all pairs') + summarise(within, 'within-study') + summarise(~within, 'between-study')
                  )
res.to_csv('out/decay_v4_bins.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
print(res[['stratum', 'bin', 'n_pairs', 'n_unique_V4', 'P_same_binary', 'P_same_binary_expected_studyprev', 'kappa_binary_vs_studyprev', 'P_partner_inh_given_inh', 'P_same_3class', 'absdiff_score_median']].round(3).to_string())
# Logistic-free summary: odds ratio of agreement at 0 mm vs random, within vs between
np.savez_compressed('work/pairs_v4.npz', I=I, J=J, dd=dd, within=within, sameiso=sameiso)
# per-group check: among identical-V4 groups spanning >=2 studies, label heterogeneity
g = d.groupby('uid').agg(n=('Func', 'size'), nstudy=('study', 'nunique'), frac_inh=('Func', lambda x: (x == 'Inhibitory').mean()))
print('identical-V4 groups with >=2 isolates:', (g.n >= 2).sum(), ' spanning >=2 studies:', ((g.n >= 2) & (g.nstudy >= 2)).sum())

# cluster bootstrap (resample identical-V4 groups) for the 0-mismatch bin, 2000 reps
rng = np.random.default_rng(1)
z = b == 0
cl = pd.DataFrame(dict(c=u[I][z], w=within[z], sb=sameb[z], bo=both[z], on=one[z], ex=expb[z]))
agg = cl.groupby(['c', 'w']).agg(n=('sb', 'size'), sb=('sb', 'sum'), bo=('bo', 'sum'), on=('on', 'sum'), ex=('ex', 'sum')).unstack(fill_value=0)
C = agg.index.values; bs = []
for r in range(2000):
    k = rng.integers(0, len(C), len(C)); a_ = agg.iloc[k].sum()
    row = {}
    for w, nm in ((True, 'within'), (False, 'between')):
        nn = a_[('n', w)]; row[nm + '_Psame'] = a_[('sb', w)] / nn
        row[nm + '_Ppartner'] = 2 * a_[('bo', w)] / (2 * a_[('bo', w)] + a_[('on', w)])
        e = a_[('ex', w)] / nn; row[nm + '_kappa'] = (row[nm + '_Psame'] - e) / (1 - e)
    row['diff_Psame'] = row['within_Psame'] - row['between_Psame']; bs.append(row)
bs = pd.DataFrame(bs)
ci = bs.quantile([0.025, 0.5, 0.975]).T; ci.columns = ['lo95', 'median', 'hi95']
ci['n_clusters'] = len(C); print(ci.round(3)); ci.to_csv('out/decay_v4_zero_mm_bootstrap.csv')
