"""Round-2 phylogenetic-signal track, step 1a: labelled isolates with clean full V4 (515F..806R, primers removed,
no IUPAC), oriented full-length sequences, study ID, dereplicated V4 FASTA for all-pairs alignment."""
import re, pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
F515 = re.compile('GTG[CT]CAGC[AC]GCCGCGGTAA'); R806 = re.compile('ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC')
a = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
m = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', index_col=0, low_memory=False)
a = a[a.Func.isin(['Inhibitory', 'NoEffect', 'Facilitating'])]
recs = {r.id: str(r.seq).upper() for r in SeqIO.parse('db/FullDatabase_2025.1.fasta', 'fasta')}
rows = []
for fid in a.index:
    s = recs[fid]
    for seq in (s, str(Seq(s).reverse_complement())):
        f = F515.search(seq)
        if not f: continue
        r = R806.search(seq, f.end())
        if r:
            v4 = seq[f.end():r.start()]
            rows.append(dict(FastaID=fid, v4=v4, v4len=len(v4), oriented=seq, full_len=len(seq),
                             iupac_v4=bool(re.search('[^ACGT]', v4)), iupac_full=len(re.findall('[^ACGT]', seq))))
        break
d = pd.DataFrame(rows).set_index('FastaID')
d = d.join(a[['Func', 'score', 'Reference']]).join(m[['Researchers', 'Study.Tab', 'Host.Species', 'Country']])
unpub = d.Reference.str.lower().str.contains('publish') | d.Reference.isna()
d['study'] = d.Reference.str.strip().str.lower().str.split(' ').str[0]
d.loc[unpub, 'study'] = 'unpub|' + d.loc[unpub, 'Researchers'].fillna('NA').astype(str)
print('labelled with 515F+806R:', len(d), ' IUPAC in V4:', d.iupac_v4.sum())
d = d[~d.iupac_v4 & d.v4len.between(240, 270)].copy()
print('clean V4 240-270bp:', len(d)); print(d.Func.value_counts()); print('studies:', d.study.nunique())
print(d.study.value_counts().to_string())
# dereplicate V4
u = {s: f'u{i}' for i, s in enumerate(d.v4.unique())}
d['uid'] = d.v4.map(u)
print('unique V4:', len(u))
with open('work/v4_unique.fasta', 'w') as fh:
    for s, i in u.items(): fh.write(f'>{i}\n{s}\n')
d.drop(columns=['oriented']).to_csv('work/isolates_v4.csv')
d[['oriented']].to_csv('work/isolates_oriented.csv')
