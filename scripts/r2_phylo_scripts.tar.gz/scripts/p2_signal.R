## Step 2: phylogenetic signal of Bd-inhibition on the V4 tree (isolate tips) and the near-full-length tree.
## Env: conda 'phylo' (ape, phytools, caper). BLAS threads capped at 4 by caller (OPENBLAS/OMP/VECLIB env vars).
args <- commandArgs(TRUE); part <- if (length(args)) args[1] else "tau"
source("scripts/p2_signal_functions.R"); set.seed(1)
d <- read.csv("work/isolates_v4.csv", stringsAsFactors = FALSE)
tr0 <- midpoint.root(read.tree("work/v4_unique.tre"))
tr <- expand_tree(tr0, d[, c("FastaID", "uid")])
d <- d[match(tr$tip.label, d$FastaID), ]; stopifnot(all(d$FastaID == tr$tip.label))
saveRDS(tr, "work/v4_isolate_tree.rds"); write.tree(tr, "out/v4_isolate_tree.nwk")
cat("isolate tree tips:", Ntip(tr), " internal nodes:", tr$Nnode, "\n")
NP <- 999
if (part == "tau") {
  P <- prep_consentrait(tr)
  out <- list()
  for (trait in c("Inhibitory", "Facilitating", "NoEffect")) {
    x <- as.integer(d$Func == trait)
    obs <- consentrait(P, matrix(x, ncol = 1))[, 1]
    Lg <- sapply(1:NP, function(i) sample(x)); Ls <- sapply(1:NP, function(i) perm_within(x, d$study))
    ng <- consentrait(P, Lg); ns <- consentrait(P, Ls)
    for (nm in c("global", "within-study")) { nul <- if (nm == "global") ng else ns
      out[[length(out) + 1]] <- data.frame(tree = "V4 (isolate tips; identical V4 = 1e-6 polytomy)", trait = trait, null = nm,
        n_tips = length(x), n_positive = sum(x), tauD_obs = obs["tauD"], tauD_null_mean = mean(nul["tauD", ]),
        tauD_null_q025 = quantile(nul["tauD", ], .025), tauD_null_q975 = quantile(nul["tauD", ], .975),
        p_upper = (1 + sum(nul["tauD", ] >= obs["tauD"])) / (NP + 1), SES = (obs["tauD"] - mean(nul["tauD", ])) / sd(nul["tauD", ]),
        tauD_clades_only_obs = obs["tauD_clades_only"], n_clades_obs = obs["n_clades"], n_singletons_obs = obs["n_singletons"],
        frac_pos_tips_in_clades = obs["tips_in_clades"] / sum(x), n_clades_null_mean = mean(nul["n_clades", ]))
      write.csv(data.frame(trait = trait, null = nm, tauD = nul["tauD", ]), sprintf("work/null_tau_v4_%s_%s.csv", trait, nm), row.names = FALSE) }
    cat(trait, "obs tauD", obs["tauD"], "\n")
  }
  # near-full-length tree
  if (file.exists("work/full_subset.tre")) {
    tf <- midpoint.root(read.tree("work/full_subset.tre")); tf$edge.length[tf$edge.length < EPS] <- EPS
    df <- d[match(tf$tip.label, d$FastaID), ]; Pf <- prep_consentrait(tf)
    for (trait in c("Inhibitory")) { x <- as.integer(df$Func == trait)
      obs <- consentrait(Pf, matrix(x, ncol = 1))[, 1]
      ng <- consentrait(Pf, sapply(1:NP, function(i) sample(x))); ns <- consentrait(Pf, sapply(1:NP, function(i) perm_within(x, df$study)))
      for (nm in c("global", "within-study")) { nul <- if (nm == "global") ng else ns
        out[[length(out) + 1]] <- data.frame(tree = "near-full-length (>=1200 bp)", trait = trait, null = nm, n_tips = length(x), n_positive = sum(x),
          tauD_obs = obs["tauD"], tauD_null_mean = mean(nul["tauD", ]), tauD_null_q025 = quantile(nul["tauD", ], .025),
          tauD_null_q975 = quantile(nul["tauD", ], .975), p_upper = (1 + sum(nul["tauD", ] >= obs["tauD"])) / (NP + 1),
          SES = (obs["tauD"] - mean(nul["tauD", ])) / sd(nul["tauD", ]), tauD_clades_only_obs = obs["tauD_clades_only"],
          n_clades_obs = obs["n_clades"], n_singletons_obs = obs["n_singletons"], frac_pos_tips_in_clades = obs["tips_in_clades"] / sum(x),
          n_clades_null_mean = mean(nul["n_clades", ]))
        write.csv(data.frame(trait = trait, null = nm, tauD = nul["tauD", ]), sprintf("work/null_tau_full_%s_%s.csv", trait, nm), row.names = FALSE) } }
  }
  res <- do.call(rbind, out); rownames(res) <- NULL; write.csv(res, "out/signal_consentrait.csv", row.names = FALSE); print(res[, 1:12])
}
if (part == "cont") {   # Blomberg K and Pagel lambda on CFS score
  out <- list()
  run <- function(phy, x, label, nsimK = 999) {
    t0 <- Sys.time()
    K <- phylosig(phy, x, method = "K", test = TRUE, nsim = nsimK)
    lam <- phylosig(phy, x, method = "lambda", test = TRUE)
    cat(label, "K", K$K, "p", K$P, " lambda", lam$lambda, "p", lam$P, format(Sys.time() - t0), "\n")
    write.csv(data.frame(K_null = K$sim.K), sprintf("work/null_K_%s.csv", gsub("[^A-Za-z0-9]", "_", label)), row.names = FALSE)
    data.frame(analysis = label, n_tips = length(x), K = K$K, K_p = K$P, K_null_median = median(K$sim.K), lambda = lam$lambda,
               lambda_logL = lam$logL, lambda_logL0 = lam$logL0, lambda_LRT_p = lam$P)
  }
  sc <- d[!is.na(d$score), ]; sc <- sc[sc$score > -300, ]   # drop extreme outliers (min -1406) that dominate Brownian variance
  ts <- keep.tip(tr, sc$FastaID); x <- setNames(sc$score, sc$FastaID)
  out[[1]] <- run(ts, x, "isolate tips, raw CFS score")
  xc <- x - ave(x, sc$study); out[[2]] <- run(ts, xc, "isolate tips, score centred on study mean")
  # unique-V4 level: mean score per identical-V4 group (no pseudo-replication)
  m <- tapply(sc$score, sc$uid, mean); tu <- keep.tip(tr0, names(m)); tu$edge.length[tu$edge.length < EPS] <- EPS
  out[[3]] <- run(tu, m[tu$tip.label], "unique-V4 tips, mean CFS score")
  res <- do.call(rbind, out); write.csv(res, "out/signal_K_lambda.csv", row.names = FALSE); print(res)
}
if (part == "D") {      # Fritz & Purvis D for binary inhibitory, on unique-V4 tree with one randomly chosen isolate per V4
  suppressPackageStartupMessages(library(caper))
  out <- list()
  for (rep in 1:5) {
    pick <- do.call(rbind, lapply(split(d, d$uid), function(g) g[sample.int(nrow(g), 1), ]))
    tu <- multi2di(tr0, random = FALSE); tu$edge.length[tu$edge.length < EPS] <- EPS; tu$node.label <- NULL
    df <- data.frame(tip = pick$uid, inh = as.integer(pick$Func == "Inhibitory"))
    cd <- comparative.data(tu, df, names.col = "tip")
    r <- phylo.d(cd, binvar = inh, permut = 1000)
    out[[rep]] <- data.frame(rep = rep, n_tips = nrow(df), n_inh = sum(df$inh), D = r$DEstimate, P_D_random = r$Pval1, P_D_brownian = r$Pval0)
    print(out[[rep]])
  }
  res <- do.call(rbind, out); write.csv(res, "out/signal_D.csv", row.names = FALSE)
}
if (part == "tau_u") {  # consenTRAIT on the unique-V4 tree, one random isolate label per identical-V4 group (10 draws x 999 perms)
  tu <- tr0; tu$edge.length[tu$edge.length < EPS] <- EPS; Pu <- prep_consentrait(tu); out <- list()
  for (rep in 1:10) {
    pick <- do.call(rbind, lapply(split(d, d$uid), function(g) g[sample.int(nrow(g), 1), ])); pick <- pick[match(tu$tip.label, pick$uid), ]
    x <- as.integer(pick$Func == "Inhibitory"); obs <- consentrait(Pu, matrix(x, ncol = 1))[, 1]
    ng <- consentrait(Pu, sapply(1:NP, function(i) sample(x))); ns <- consentrait(Pu, sapply(1:NP, function(i) perm_within(x, pick$study)))
    for (nm in c("global", "within-study")) { nul <- if (nm == "global") ng else ns
      out[[length(out) + 1]] <- data.frame(tree = "unique-V4 (1 random isolate per V4)", rep = rep, trait = "Inhibitory", null = nm, n_tips = length(x),
        n_positive = sum(x), tauD_obs = obs["tauD"], tauD_null_mean = mean(nul["tauD", ]), p_upper = (1 + sum(nul["tauD", ] >= obs["tauD"])) / (NP + 1),
        SES = (obs["tauD"] - mean(nul["tauD", ])) / sd(nul["tauD", ]), n_clades_obs = obs["n_clades"], frac_pos_tips_in_clades = obs["tips_in_clades"] / sum(x))
      if (rep == 1) write.csv(data.frame(trait = "Inhibitory", null = nm, tauD = nul["tauD", ]), sprintf("work/null_tau_uniqueV4_%s.csv", nm), row.names = FALSE) }
  }
  res <- do.call(rbind, out); rownames(res) <- NULL; write.csv(res, "out/signal_consentrait_uniqueV4.csv", row.names = FALSE)
  print(aggregate(cbind(tauD_obs, tauD_null_mean, p_upper, SES, frac_pos_tips_in_clades) ~ null, res, median))
}
if (part == "cont_full") {  # K and lambda on the near-full-length tree
  tf <- midpoint.root(read.tree("work/full_subset.tre")); tf$edge.length[tf$edge.length < EPS] <- EPS
  sc <- d[d$FastaID %in% tf$tip.label & !is.na(d$score) & d$score > -300, ]
  t2 <- keep.tip(tf, sc$FastaID); x <- setNames(sc$score, sc$FastaID)
  K <- phylosig(t2, x, method = "K", test = TRUE, nsim = 999); lam <- phylosig(t2, x, method = "lambda", test = TRUE)
  xc <- x - ave(x, sc$study); Kc <- phylosig(t2, xc, method = "K", test = TRUE, nsim = 999); lc <- phylosig(t2, xc, method = "lambda", test = TRUE)
  res <- data.frame(analysis = c("near-full-length tips, raw CFS score", "near-full-length tips, score centred on study mean"), n_tips = length(x),
    K = c(K$K, Kc$K), K_p = c(K$P, Kc$P), K_null_median = c(median(K$sim.K), median(Kc$sim.K)), lambda = c(lam$lambda, lc$lambda),
    lambda_logL = c(lam$logL, lc$logL), lambda_logL0 = c(lam$logL0, lc$logL0), lambda_LRT_p = c(lam$P, lc$P))
  write.csv(data.frame(K_null = K$sim.K), "work/null_K_full_raw.csv", row.names = FALSE)
  write.csv(res, "out/signal_K_lambda_fulllength.csv", row.names = FALSE); print(res)
}
if (part == "D_full") {   # D for binary inhibitory on the near-full-length tree
  suppressPackageStartupMessages(library(caper))
  tf <- multi2di(midpoint.root(read.tree("work/full_subset.tre")), random = FALSE); tf$edge.length[tf$edge.length < EPS] <- EPS; tf$node.label <- NULL
  df <- data.frame(tip = tf$tip.label, inh = as.integer(d$Func[match(tf$tip.label, d$FastaID)] == "Inhibitory"))
  r <- phylo.d(comparative.data(tf, df, names.col = "tip"), binvar = inh, permut = 1000)
  res <- data.frame(tree = "near-full-length", rep = NA, n_tips = nrow(df), n_inh = sum(df$inh), D = r$DEstimate, P_D_random = r$Pval1, P_D_brownian = r$Pval0)
  print(res); write.csv(res, "out/signal_D_fulllength.csv", row.names = FALSE)
}
