"""Collect round-2 phylogenetic-signal tables into one xlsx."""
import pandas as pd
sheets = {'decay_V4_bins': 'out/decay_v4_bins.csv', 'decay_V4_0mm_bootstrap': 'out/decay_v4_zero_mm_bootstrap.csv',
          'decay_fulllength_bins': 'out/decay_fulllength_bins.csv', 'consenTRAIT': 'out/signal_consentrait.csv',
          'consenTRAIT_uniqueV4': 'out/signal_consentrait_uniqueV4.csv', 'K_lambda_V4': 'out/signal_K_lambda.csv',
          'K_lambda_fulllength': 'out/signal_K_lambda_fulllength.csv', 'D_uniqueV4': 'out/signal_D.csv', 'D_fulllength': 'out/signal_D_fulllength.csv'}
with pd.ExcelWriter('out/r2_phylo_signal_summary.xlsx') as w:
    for k, f in sheets.items(): pd.read_csv(f).to_excel(w, sheet_name=k, index=False)
