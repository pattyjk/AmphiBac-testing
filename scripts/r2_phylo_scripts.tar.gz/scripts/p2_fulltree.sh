# near-full-length subset (n=1,884) alignment + tree, 4 threads
set -e
export TMPDIR=$PWD/tmp
mafft --auto --thread 4 --quiet work/full_subset.fasta > work/full_subset.aln.fasta
FastTree -nt -gtr -gamma -quiet work/full_subset.aln.fasta > work/full_subset.tre
