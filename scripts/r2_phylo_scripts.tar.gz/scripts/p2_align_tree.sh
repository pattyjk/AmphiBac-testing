# V4 unique-sequence alignment + tree (4 threads max), full-length subset alignment + tree
set -e
export OMP_NUM_THREADS=4
mafft --auto --thread 4 --quiet work/v4_unique.fasta > work/v4_unique.aln.fasta
FastTree -nt -gtr -gamma -quiet work/v4_unique.aln.fasta > work/v4_unique.tre
