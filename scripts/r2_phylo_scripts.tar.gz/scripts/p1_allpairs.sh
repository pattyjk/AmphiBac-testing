# all-vs-all global alignment of unique clean V4 sequences (4 threads cap)
vsearch --allpairs_global work/v4_unique.fasta --acceptall --threads 4 --qmask none \
  --userout work/v4_allpairs.tsv --userfields query+target+id+mism+gaps+alnlen+ids --quiet
