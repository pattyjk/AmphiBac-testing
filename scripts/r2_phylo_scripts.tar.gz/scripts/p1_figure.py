"""Figure: function-decay curves (V4, within vs between study) and full-length identity curve."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
try: apply_figure_style(sizes=(8, 7, 6))
except NameError: pass
v = pd.read_csv('out/decay_v4_bins.csv'); f = pd.read_csv('out/decay_fulllength_bins.csv')
bins = ['0', '1', '2', '3', '4-5', '6-10', '11-20', '>20']
C = {'within-study': '#1b1b1b', 'between-study': '#9a9a9a'}
fig, axs = plt.subplots(2, 2, figsize=(7.0, 5.6), constrained_layout=True); axs = axs.ravel()
x = np.arange(len(bins))
for ax, col, yl in ((axs[0], 'kappa_binary_vs_studyprev', "κ beyond study prevalence\n(inhibitory vs not)"),
                    (axs[1], 'P_partner_inh_given_inh', 'P(partner inhibitory |\nfocal isolate inhibitory)')):
    for s in ('within-study', 'between-study'):
        g = v[v.stratum == s].set_index('bin').loc[bins]
        ax.plot(x, g[col], '-o', color=C[s], ms=3.5, lw=1.2, label=s.replace('-', ' '))
        base = v[(v.stratum == s) & (v.bin == 'random pair (all)')][col].iloc[0]
        ax.axhline(base, color=C[s], ls=':', lw=0.9)
    ax.set_xticks(x); ax.set_xticklabels(bins, rotation=45); ax.set_xlabel('V4 differences (of ~253 bp)'); ax.set_ylabel(yl)
axs[0].axhline(0, color='0.8', lw=0.6, zorder=0)
axs[0].legend(frameon=False, loc='upper right', bbox_to_anchor=(1.0, 1.0))
axs[0].set_title('Identical-V4 agreement is mostly within-study', loc='left')
axs[1].text(0, 0.36, 'dotted = all random pairs', ha='left', va='center', fontsize=6, color='0.4')
axs[1].set_title('Inhibition co-occurs up to ~10 V4 differences', loc='left')
ax = axs[2]
for k, s in enumerate(('within-study', 'between-study')):
    g = v[v.stratum == s].set_index('bin').loc[bins]
    off = -0.15 if k == 0 else 0.15
    ax.errorbar(x + off, g.absdiff_score_median, yerr=[g.absdiff_score_median - g.absdiff_score_q25, g.absdiff_score_q75 - g.absdiff_score_median],
                fmt='o', ms=3.5, color=C[s], lw=0.9, capsize=1.5)
ax.set_xticks(x); ax.set_xticklabels(bins, rotation=45); ax.set_xlabel('V4 differences (of ~253 bp)'); ax.set_ylabel('|Δ CFS score| (median, IQR)')
ax.set_title('CFS-score gaps stay wide even for identical V4', loc='left')
ax = axs[3]
fb = ['<97', '97-98', '98-99', '99-99.5', '99.5-<100', '100']
for s in ('within-study', 'between-study'):
    g = f[(f.stratum == s) & (f.grouping == 'full-length identity')].set_index('bin').loc[fb]
    ax.plot(np.arange(len(fb)), g.P_partner_inh_given_inh, '-o', color=C[s], ms=3.5, lw=1.2)
    g2 = f[(f.stratum == s) & (f.grouping == 'V4 identical, by full-length identity')].set_index('bin').reindex(fb)
    ax.plot(np.arange(len(fb)), g2.P_partner_inh_given_inh, '--s', color=C[s], ms=3, lw=0.9, mfc='white')
    base = f[(f.stratum == s) & (f.bin == 'all')].P_partner_inh_given_inh.iloc[0]; ax.axhline(base, color=C[s], ls=':', lw=0.9)
ax.plot([], [], '-o', color='0.5', ms=3, label='all pairs'); ax.plot([], [], '--s', color='0.5', ms=3, mfc='white', label='V4-identical pairs')
ax.legend(frameon=False, loc='lower right', bbox_to_anchor=(1.0, 0.02))
ax.set_xticks(range(len(fb))); ax.set_xticklabels(['<97', '97–98', '98–99', '99–99.5', '99.5–<100', '100'], rotation=45)
ax.set_xlabel('Full-length identity (%; ≥1,000 bp shared)'); ax.set_ylabel('P(partner inhibitory |\nfocal inhibitory)')
ax.set_title('Full-length ≥99% identity raises agreement', loc='left')
for a_, L in zip(axs, 'abcd'): a_.text(-0.02, 1.02, L, transform=a_.transAxes, fontweight='bold', fontsize=10, ha='right', va='bottom')
fig.savefig('out/fig_r2_decay_curves.png', dpi=300)
