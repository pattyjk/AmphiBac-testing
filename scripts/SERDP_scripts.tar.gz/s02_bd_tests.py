"""Bd infection/load vs AmphiBac metrics within site x season strata; permutation null on isolate labels."""
import pandas as pd, numpy as np, warnings, scipy.sparse as sp
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.discrete.conditional_models import ConditionalLogit
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings('ignore')
M = pd.read_csv('serdp_meta.csv', index_col=0); S = pd.read_csv('serdp_per_sample_metrics.csv', index_col=0)
D = M.join(S)
METRICS = {'FullDatabase_0.99_Prop':'Cultured share (Full, 99%)','Inhibitory_0.99_Prop':'Pipeline Inhibitory, 99%',
 'InhibitoryStrict_0.99_Prop':'Pipeline InhibitoryStrict, 99%','Facilitating_0.99_Prop':'Pipeline Facilitating, 99%',
 'Inhibitory_0.97_Prop':'Pipeline Inhibitory, 97%','Inhibitory_1.0_Prop':'Pipeline Inhibitory, 100%',
 'Inhibitory_0.99_Richness':'Pipeline Inhibitory richness','FullDatabase_0.99_Richness':'Full richness',
 'Majority_99_Prop':'Majority vote (>50%)','Cons75_99_Prop':'>=75% consensus','ScoreW_99':'Score-weighted mean CFS',
 'MeanFinh_99':'Mean inhibitory share of matched','GenusPrior_97':'Genus prior','Inh_over_Full_99':'Inhibitory / Full ratio'}
def z(x): return (x-x.mean())/x.std()
def clogit(d, col, adj=None):
    d = d.dropna(subset=[col]+([adj] if adj else []))
    ok = d.groupby('stratum').Inf.transform(lambda s: 0<s.sum()<len(s)); d = d[ok]
    Xm = pd.DataFrame({'m': z(d[col])})
    if adj: Xm['c'] = z(d[adj])
    r = ConditionalLogit(d.Inf.values, Xm.values, groups=d.stratum.values).fit(disp=0)
    return r.params[0], r.bse[0], r.pvalues[0], len(d)
def load(d, col, adj=None):
    d = d[d.Inf==1].dropna(subset=[col]).copy(); d['zm']=z(d[col])
    f = 'logBd ~ zm + C(stratum)' + (' + zc' if adj else '')
    if adj: d['zc']=z(d[adj])
    r = smf.ols(f, d).fit(); return r.params['zm'], r.bse['zm'], r.pvalues['zm'], len(d)
rows=[]
for sens, d in [('all', D), ('seqfrac>=0.8', D[D.seq_frac>=0.8])]:
    for col,name in METRICS.items():
        for adj in [None, 'FullDatabase_0.99_Prop']:
            if adj==col: continue
            b,se,p,n = clogit(d,col,adj); rows.append(dict(sample_set=sens,metric=name,col=col,adjusted_for_cultured=adj is not None,outcome='infected (conditional logit, OR per SD)',est=np.exp(b),lo=np.exp(b-1.96*se),hi=np.exp(b+1.96*se),p=p,n=n))
            b,se,p,n = load(d,col,adj); rows.append(dict(sample_set=sens,metric=name,col=col,adjusted_for_cultured=adj is not None,outcome='log10 Bd among infected (beta per SD)',est=b,lo=b-1.96*se,hi=b+1.96*se,p=p,n=n))
R = pd.DataFrame(rows)
R['q_BH'] = R.groupby(['sample_set','outcome','adjusted_for_cultured']).p.transform(lambda p: multipletests(p,method='fdr_bh')[1])
# naive (unstratified) Spearman, what a typical user would report
from scipy.stats import spearmanr, mannwhitneyu
naive=[]
for col,name in METRICS.items():
    rho,p = spearmanr(D[col],D.logBd,nan_policy='omit'); u = mannwhitneyu(D.loc[D.Inf==1,col].dropna(),D.loc[D.Inf==0,col].dropna())
    naive.append(dict(metric=name,col=col,spearman_logBd=rho,p_spearman=p,median_inf=D.loc[D.Inf==1,col].median(),median_uninf=D.loc[D.Inf==0,col].median(),p_MWU=u.pvalue))
N = pd.DataFrame(naive); N['q_spearman']=multipletests(N.p_spearman,method='fdr_bh')[1]; N['q_MWU']=multipletests(N.p_MWU,method='fdr_bh')[1]
# permutation null: shuffle Func among database isolates, recompute any-hit (pipeline approx) and majority metrics, refit clogit
X = pd.read_csv('serdp_table_rare2900.csv', index_col=0)[D.index]
A = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
E = pd.read_csv('uc/exh097.tsv', sep='\t', header=None, names=['q','t','id','alnlen','mism','gaps','ql','qilo','qihi'])
E = E[(E.qilo==1)&(E.qihi==E.ql)&((E.alnlen-E.mism-E.gaps)/E.alnlen>=0.99-1e-9)]
iso = A.index[A.Func.isin(['Inhibitory','NoEffect','Facilitating'])]; E = E[E.t.isin(iso)]
feats = pd.Index(sorted(E.q.unique())); isoi = pd.Index(iso)
B = sp.csr_matrix((np.ones(len(E)),(feats.get_indexer(E.q),isoi.get_indexer(E.t))),shape=(len(feats),len(isoi)))
B.data[:]=1; B=(B>0).astype(float); ntest = np.asarray(B.sum(1)).ravel()
Xf = X.reindex(feats).fillna(0).values  # features x samples
inh0 = (A.loc[iso,'Func']=='Inhibitory').values.astype(float)
def mets(inh):
    k = B.dot(inh); anyi = (k>0).astype(float); maj = (k/ntest>0.5).astype(float)
    return Xf.T.dot(anyi)/2900, Xf.T.dot(maj)/2900
obs_any, obs_maj = mets(inh0)
D2 = D.copy(); D2['any_obs']=obs_any; D2['maj_obs']=obs_maj
print('any-hit approx vs pipeline Inhibitory_0.99 r=', np.corrcoef(obs_any, D['Inhibitory_0.99_Prop'])[0,1].round(4), ' majority check r=', np.corrcoef(obs_maj, D.Majority_99_Prop)[0,1].round(4))
o_any = clogit(D2,'any_obs'); o_maj = clogit(D2,'maj_obs'); o_any_l = load(D2,'any_obs'); o_maj_l=load(D2,'maj_obs')
rng = np.random.default_rng(42); null=[]; nullS=[]
for i in range(1000):
    pa, pm = mets(rng.permutation(inh0)); D2['pa']=pa; D2['pm']=pm
    null.append(dict(perm=i, any_logOR=clogit(D2,'pa')[0], maj_logOR=clogit(D2,'pm')[0], any_beta=load(D2,'pa')[0], maj_beta=load(D2,'pm')[0],
                     r_any_obs=np.corrcoef(pa,obs_any)[0,1], r_maj_obs=np.corrcoef(pm,obs_maj)[0,1]))
    nullS.append(pa)
Nl = pd.DataFrame(null); nullS=np.array(nullS)
pct_above95 = (obs_any > np.percentile(nullS,95,axis=0)).mean()
def pperm(obs, arr): return (1+np.sum(np.abs(arr)>=abs(obs)))/(1+len(arr))
P = pd.DataFrame([
 {'metric':'Pipeline Inhibitory (any-hit approx)','outcome':'infected, log OR per SD','observed':o_any[0],'null_median':Nl.any_logOR.median(),'null_q025':Nl.any_logOR.quantile(.025),'null_q975':Nl.any_logOR.quantile(.975),'p_perm_two_sided_vs0':pperm(o_any[0],Nl.any_logOR),'pct_null_more_extreme_than_obs':100*np.mean(np.abs(Nl.any_logOR)>=abs(o_any[0]))},
 {'metric':'Majority vote','outcome':'infected, log OR per SD','observed':o_maj[0],'null_median':Nl.maj_logOR.median(),'null_q025':Nl.maj_logOR.quantile(.025),'null_q975':Nl.maj_logOR.quantile(.975),'p_perm_two_sided_vs0':pperm(o_maj[0],Nl.maj_logOR),'pct_null_more_extreme_than_obs':100*np.mean(np.abs(Nl.maj_logOR)>=abs(o_maj[0]))},
 {'metric':'Pipeline Inhibitory (any-hit approx)','outcome':'log10 Bd among infected, beta per SD','observed':o_any_l[0],'null_median':Nl.any_beta.median(),'null_q025':Nl.any_beta.quantile(.025),'null_q975':Nl.any_beta.quantile(.975),'p_perm_two_sided_vs0':pperm(o_any_l[0],Nl.any_beta),'pct_null_more_extreme_than_obs':100*np.mean(np.abs(Nl.any_beta)>=abs(o_any_l[0]))},
 {'metric':'Majority vote','outcome':'log10 Bd among infected, beta per SD','observed':o_maj_l[0],'null_median':Nl.maj_beta.median(),'null_q025':Nl.maj_beta.quantile(.025),'null_q975':Nl.maj_beta.quantile(.975),'p_perm_two_sided_vs0':pperm(o_maj_l[0],Nl.maj_beta),'pct_null_more_extreme_than_obs':100*np.mean(np.abs(Nl.maj_beta)>=abs(o_maj_l[0]))}])
D2[['any_obs','maj_obs']].assign(any_null_mean=nullS.mean(0), any_null_p95=np.percentile(nullS,95,axis=0)).to_csv('serdp_null_per_sample.csv')
Nl.to_csv('serdp_null_permutations.csv',index=False)
with pd.ExcelWriter('SERDP_AmphiBac_Bd_tests.xlsx') as w:
    pd.DataFrame({'note':[
     'SERDP leopard frogs: 372 frogs matched to the 16S table (rarefied 2,900 reads, 150-bp deblur V4). 12,105/15,595 features have sequences (rep-set was taxonomy-filtered); unsequenced features count as unmatched (as in the pipeline).',
     'Pipeline outputs emulate q2-vsearch closed-ref (vsearch 2.32.0, strand both, default maxaccepts/maxrejects) against AmphiBac 2025.1 subsets.',
     'Infection: conditional logistic regression grouped by species-site x season (strata with both outcomes only); load: OLS log10(Bd+1) ~ metric + stratum among infected. Metrics z-scored. BH within sample set x outcome x adjustment.',
     'Permutation null: Func labels shuffled among tested isolates 1,000x; Inhibitory mode approximated by any >=99% full-coverage hit being Inhibitory.',
     f'Null per sample: observed any-hit inhibitory proportion exceeds the null 95th percentile in {100*pct_above95:.1f}% of frogs.']}).to_excel(w,sheet_name='README',index=False)
    R.to_excel(w,sheet_name='stratified_tests',index=False); N.to_excel(w,sheet_name='naive_tests',index=False); P.to_excel(w,sheet_name='permutation_null',index=False)
R.to_csv('serdp_stratified_tests.csv',index=False); N.to_csv('serdp_naive_tests.csv',index=False); P.to_csv('serdp_permutation_null.csv',index=False)
pd.set_option('display.width',250)
print(R[(R.sample_set=='all')].sort_values('p')[['metric','outcome','adjusted_for_cultured','est','lo','hi','p','q_BH','n']].head(14).round(4).to_string())
print(N[['metric','spearman_logBd','p_spearman','q_spearman','median_inf','median_uninf','p_MWU']].round(4).to_string())
print(P.round(4).to_string()); print('pct frogs above null95', round(100*pct_above95,1), 'mean r(null,obs) any', Nl.r_any_obs.mean().round(3))
