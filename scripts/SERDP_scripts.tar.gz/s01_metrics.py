"""SERDP leopard frogs: AmphiBac pipeline-equivalent outputs + label-consensus metrics per sample."""
import pandas as pd, numpy as np, sys
GEN = sys.argv[1]   # genus_assignments.csv (round-2 SINTAX RDP v18 isolate genera)
X = pd.read_csv('serdp_table_rare2900.csv', index_col=0); DEPTH = 2900
A = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
lab = A.Func; tested = lab.isin(['Inhibitory','NoEffect','Facilitating'])
def uc(p):
    u = pd.read_csv(p, sep='\t', header=None, usecols=[0,8,9]); u = u[u[0]=='H']
    return dict(zip(u[8], u[9]))
out = pd.DataFrame(index=X.columns)
for s in ['FullDatabase','Inhibitory','InhibitoryStrict','Facilitating']:
    for i in ['0.97','0.98','0.99','1.0']:
        h = uc(f'uc/{s}_{i}.uc'); f = X.index.isin(list(h))
        out[f'{s}_{i}_Prop'] = X[f].sum()/DEPTH
        refs = pd.Series({q:h[q] for q in X.index[f]})
        sub = X[f]; out[f'{s}_{i}_Richness'] = sub.gt(0).T.dot(pd.get_dummies(refs.reindex(sub.index))).gt(0).sum(axis=1)
# exhaustive hits: exact identity, full query coverage
E = pd.read_csv('uc/exh097.tsv', sep='\t', header=None, names=['q','t','id','alnlen','mism','gaps','ql','qilo','qihi'])
E['pid'] = (E.alnlen-E.mism-E.gaps)/E.alnlen
E = E[(E.qilo==1)&(E.qihi==E.ql)]
E['Func'] = E.t.map(lab); E['score'] = E.t.map(A.score)
g = pd.read_csv(GEN).set_index('FastaID'); E['genus'] = E.t.map(g.genus_full)
gprior = g[g.Func.isin(['Inhibitory','NoEffect','Facilitating'])].groupby('genus_full').Func.apply(lambda s:(s=='Inhibitory').mean())
F = {}
for thr in [0.99, 0.97]:
    e = E[(E.pid>=thr-1e-9)&E.Func.isin(['Inhibitory','NoEffect','Facilitating'])]
    agg = e.groupby('q').agg(n=('t','size'), f_inh=('Func', lambda s:(s=='Inhibitory').mean()),
                             f_fac=('Func', lambda s:(s=='Facilitating').mean()), score=('score','mean'),
                             genus=('genus', lambda s: s.dropna().mode().iloc[0] if s.notna().any() else np.nan))
    F[thr] = agg
F99 = F[0.99]; F99.to_csv('serdp_feature_labels_99.csv')
def rw(mask_or_val, feats):
    sub = X.loc[X.index.intersection(feats.index)]
    return sub, feats.reindex(sub.index)
sub, f = rw(None, F99)
out['AnyInh_99_Prop'] = sub[f.f_inh>0].sum()/DEPTH
out['Majority_99_Prop'] = sub[f.f_inh>0.5].sum()/DEPTH
out['Cons75_99_Prop'] = sub[f.f_inh>=0.75].sum()/DEPTH
out['Matched_99_Prop'] = sub.sum()/DEPTH
w = sub.mul(f.score, axis=0); out['ScoreW_99'] = w.sum()/sub[f.score.notna()].sum()
out['MeanFinh_99'] = sub.mul(f.f_inh,axis=0).sum()/sub.sum()          # read-weighted inhibitory share of matched isolates
# genus prior: genus of matched isolates (>=97%) -> database-wide inhibitory share of that genus
f97 = F[0.97]; sub97 = X.loc[X.index.intersection(f97.index)]; gp = f97.genus.map(gprior).reindex(sub97.index)
out['GenusPrior_97'] = sub97[gp.notna()].mul(gp[gp.notna()],axis=0).sum()/sub97[gp.notna()].sum()
out['Inh_over_Full_99'] = out['Inhibitory_0.99_Prop']/out['FullDatabase_0.99_Prop']
out.to_csv('serdp_per_sample_metrics.csv')
print(out.describe().T[['mean','50%']].round(3).to_string())
print('features with >=99% full-cov tested hits', len(F99), 'mixed labels', ((F99.f_inh>0)&(F99.f_inh<1)).sum())
