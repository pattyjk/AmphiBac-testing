# Pipeline-equivalent q2-vsearch closed-ref calls + exhaustive Full-db search (SERDP 150-bp deblur features)
for s in FullDatabase Inhibitory InhibitoryStrict Facilitating; do for id in 0.97 0.98 0.99 1.0; do
 vsearch --usearch_global serdp_repseqs.fasta --id $id --db db/${s}_2025.1.fasta --uc uc/${s}_${id}.uc --strand both --qmask none --notmatched /dev/null --threads 8 --minseqlength 1 --fasta_width 0
done; done
vsearch --usearch_global serdp_repseqs.fasta --id 0.97 --db db/FullDatabase_2025.1.fasta --strand both --qmask none --maxaccepts 0 --maxrejects 0 --threads 8 --minseqlength 1 --userout uc/exh097.tsv --userfields query+target+id+alnlen+mism+gaps+ql+qilo+qihi
