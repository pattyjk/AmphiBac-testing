"""Parse EPA-ng jplace -> per-feature top placement, NSTI, nearest-tip (M1) and LWR-weighted nearest-tip (M1w)."""
import sys, pandas as pd, numpy as np; sys.path.insert(0,'scripts'); import placement_lib as P
T = pd.read_csv('ref/tip_table.csv', index_col=0); T = T[T.in_tree]
inh = (T.Func=='Inhibitory')
def run(jp, out):
    top = P.parse_jplace(jp); al = P.parse_jplace(jp, all_placements=True)
    al['inh'] = inh.reindex(al.nearest_tip).values.astype(float)
    al = al[al.lwr>=0.01]; al['w'] = al.lwr/al.groupby('query').lwr.transform('sum')
    m1w = (al.w*al.inh).groupby(al['query']).sum()
    nsti_w = (al.w*al.nsti).groupby(al['query']).sum()
    top = top.set_index('query')
    top['M1_nearest_Func'] = T.Func.reindex(top.nearest_tip).values
    top['M1_P'] = (top.M1_nearest_Func=='Inhibitory').astype(float)
    top['M1w_P'] = m1w.reindex(top.index).values
    top['nsti_lwr_weighted'] = nsti_w.reindex(top.index).values
    top['nearest_genus'] = T.genus_full.reindex(top.nearest_tip).values
    top['nearest_family'] = T.family_full.reindex(top.nearest_tip).values
    top.to_csv(out); print(out, len(top), top.nsti.describe().round(4).to_dict())
    return top
t = run('epa_comm/epa_result.jplace', 'q/comm_placements.csv')
for k in 'SB': s=t[t.index.str[0]==k]; print(k, 'NSTI<=0.05', (s.nsti<=0.05).mean().round(3), '<=0.1', (s.nsti<=0.1).mean().round(3), 'M1 inh', s.M1_P.mean().round(3), 'M1w', s.M1w_P.mean().round(3))
