"""Meta-analysis 90-bp sOTU table: parse line by line (skip malformed / numeric-ID rows), keep samples >=1000 reads,
rarefy to 1,000 (seed 1), keep sOTUs present in >=5 rarefied samples. Writes meta_rare1000.npz + meta_sotus.fasta."""
import numpy as np, scipy.sparse as sp, re
f = open('meta/amphib_only_otu_table.txt'); hdr = f.readline().rstrip('\n').split('\t'); ns = len(hdr)
ids=[]; rows=[]; cols=[]; vals=[]; bad=0; num=0
for line in f:
    p = line.rstrip('\n').split('\t')
    if len(p) != ns+1: bad+=1; continue
    if re.fullmatch(r'[0-9.]+', p[0]) or not re.fullmatch(r'[ACGTN]+', p[0]): num+=1; continue
    v = np.array(p[1:], dtype=float).astype(np.int64); nz = np.nonzero(v)[0]
    i = len(ids); ids.append(p[0]); rows += [i]*len(nz); cols += nz.tolist(); vals += v[nz].tolist()
X = sp.csc_matrix((vals,(rows,cols)), shape=(len(ids), ns))
dep = np.asarray(X.sum(0)).ravel(); keep = np.where(dep>=1000)[0]
print('rows ok', len(ids), 'malformed', bad, 'bad id', num, 'samples', ns, 'kept >=1000', len(keep))
rng = np.random.default_rng(1); R = sp.lil_matrix((len(ids), len(keep)), dtype=np.int32)
rr=[]; cc=[]; vv=[]
for j, s in enumerate(keep):
    col = X[:, s]; idx = col.indices; c = col.data.astype(np.int64)
    pool = np.repeat(idx, c); pick = rng.choice(pool, 1000, replace=False)
    u, k = np.unique(pick, return_counts=True); rr += u.tolist(); cc += [j]*len(u); vv += k.tolist()
R = sp.csr_matrix((vv,(rr,cc)), shape=(len(ids), len(keep)))
prev = np.asarray((R>0).sum(1)).ravel(); ks = np.where(prev>=5)[0]
print('sOTUs present in >=5 rarefied samples', len(ks), 'read share retained', R[ks].sum()/R.sum())
R = R[ks]; sp.save_npz('meta_rare1000.npz', R)
np.save('meta_samples.npy', np.array([hdr[s] for s in keep]))
with open('meta_sotus.fasta','w') as fh:
    for n,i in enumerate(ks): fh.write(f'>m{n}\n{ids[i]}\n')
import collections; print(collections.Counter(len(ids[i]) for i in ks).most_common(3))
