"""M3 (BM / OU + residual) and M4 (phylogeny + study random effect + residual) Gaussian prediction of CFS score
on the reference tree, evaluated at each query's top EPA-ng placement point (attachment point + pendant edge).
Covariances are built from path distances only, so they are exact for any tree:
  BM: C(x,y) = (h(x)+h(y)-D(x,y))/2 with h = distance to the MIDPOINT root (root is arbitrary in the ML tree);
  OU (stationary): C(x,y) = exp(-alpha*D(x,y)).
Variance components by REML (scipy Nelder-Mead on log-parameters), fitted ONCE on all 5,740 scored isolates.
Prediction for 'average study' (study effect = 0): mean = mu + k_q' K^-1 (y - mu); var_phylo = s_p^2 c_qq - k_q'K^-1 k_q;
predictive var for a new assay = var_phylo + s_e^2 (+ GLS var of mu); P(inhibitory) = P(score > 80).
Outputs gp_fit.json, gp_W_<model>.npy (K^-1 K_rq for permutation reuse) and per-query predictions."""
import sys, json, time, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.csgraph import dijkstra
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.stats import norm
sys.path.insert(0,'scripts'); import placement_lib as P
J = json.load(open('epa_comm/epa_result.jplace'))
parent, blen, enum, label, children, is_leaf = P._parse_jplace_tree(J['tree'])
N = len(parent); e2node = {e:k for k,e in enumerate(enum) if e>=0}
lab2node = {l:k for k,l in enumerate(label) if l is not None}
nz = np.where(parent>=0)[0]
G = sp.csr_matrix((blen[nz]+1e-12, (nz, parent[nz])), shape=(N,N)); G = G + G.T
T = pd.read_csv('ref/tip_table.csv', index_col=0); T = T[T.in_tree]
S = T[T.score.notna()].copy(); y = S.score.values; n = len(S)
snode = np.array([lab2node[i] for i in S.index])
# diameter endpoints for midpoint rooting
leaves = np.where(is_leaf)[0]
d0 = dijkstra(G, indices=leaves[0]); t1 = leaves[np.argmax(d0[leaves])]
d1 = dijkstra(G, indices=t1); t2 = leaves[np.argmax(d1[leaves])]; L = d1[t2]
d2 = dijkstra(G, indices=t2)
def hmid(a, b):  # distances to t1, t2 -> distance to midpoint
    s = (a - b + L)/2; e = (a + b - L)/2; return e + np.abs(s - L/2)
t0=time.time(); Dn = dijkstra(G, indices=snode)  # n x N
print('dijkstra', round(time.time()-t0,1), 's; diameter', round(L,3))
Drr = Dn[:, snode]; hr = hmid(d1[snode], d2[snode])
Cbm = (hr[:,None] + hr[None,:] - Drr)/2
studies = S.Reference.astype('category').cat.codes.values
Zs = (studies[:,None]==studies[None,:]).astype(float)
X1 = np.ones((n,1))
def reml(K):
    try: cf = cho_factor(K, lower=True, check_finite=False)
    except np.linalg.LinAlgError: return 1e15, None
    Ki1 = cho_solve(cf, X1, check_finite=False); A = (X1.T@Ki1)[0,0]
    Kiy = cho_solve(cf, y, check_finite=False); mu = (Ki1[:,0]@y)/A
    r = y - mu; Kir = Kiy - mu*Ki1[:,0]
    ll = 2*np.log(np.diag(cf[0])).sum() + np.log(A) + r@Kir
    return 0.5*ll, (cf, mu, Kir, A)
def build(model, th):
    th = np.exp(th)
    if model=='BM':      return th[0]*Cbm + th[1]*np.eye(n)
    if model=='OU':      return th[0]*np.exp(-th[1]*Drr) + th[2]*np.eye(n)
    if model=='BM_study':return th[0]*Cbm + th[1]*Zs + th[2]*np.eye(n)
    if model=='OU_study':return th[0]*np.exp(-th[1]*Drr) + th[2]*Zs + th[3]*np.eye(n)
v = y.var()
start = {'BM':[np.log(v/2/np.median(hr)), np.log(v/2)], 'OU':[np.log(v/2), np.log(1.0), np.log(v/2)],
         'BM_study':[np.log(v/3/np.median(hr)), np.log(v/3), np.log(v/3)], 'OU_study':[np.log(v/3), 0.0, np.log(v/3), np.log(v/3)]}
models = sys.argv[1].split(',') if len(sys.argv)>1 else list(start)
fits = {}
for m in models:
    t0=time.time(); f = lambda th: reml(build(m, th))[0]
    res = minimize(f, start[m], method='Nelder-Mead', options=dict(xatol=1e-3, fatol=1e-3, maxiter=400))
    k = len(start[m]); fits[m] = dict(theta=np.exp(res.x).tolist(), negREML=res.fun, AIC=2*res.fun+2*k, nfev=res.nfev, sec=time.time()-t0)
    print(m, fits[m], flush=True)
json.dump(fits, open('gp_fit.json','w'), indent=1)
