"""Label permutations on the reference tree: 200 global + 200 within-study (Reference).
Func is shuffled among all 7,279 in-tree isolates; CFS score is shuffled separately among the 5,740 scored isolates
(positions of scored isolates fixed so the GP design is unchanged). Seed 2026."""
import numpy as np, pandas as pd
T = pd.read_csv('ref/tip_table.csv', index_col=0); T = T[T.in_tree]
S = T[T.score.notna()]
rng = np.random.default_rng(2026); NP = 200
def within(vals, groups):
    out = vals.copy()
    for g in np.unique(groups):
        i = np.where(groups==g)[0]; out[i] = vals[rng.permutation(i)]
    return out
F = T.Func.values; ref = T.Reference.fillna('NA').values; y = S.score.values; refS = S.Reference.fillna('NA').values
fun = {}; sco = {}
for scheme in ['global','within_study']:
    for k in range(NP):
        fun[(scheme,k)] = rng.permutation(F) if scheme=='global' else within(F, ref)
        sco[(scheme,k)] = rng.permutation(y) if scheme=='global' else within(y, refS)
Fi = pd.DataFrame({f'{s}_{k}': (v=='Inhibitory').astype(int) for (s,k),v in fun.items()}, index=T.index); Fi.index.name='FastaID'
Fi.to_csv('null/perm_inh.csv'); pd.DataFrame({f'{s}_{k}': v for (s,k),v in sco.items()}, index=S.index).to_csv('null/perm_score.csv')
print(Fi.shape, Fi.mean().mean().round(3))
