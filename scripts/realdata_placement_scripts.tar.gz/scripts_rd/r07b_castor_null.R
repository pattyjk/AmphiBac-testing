# emp_prob (castor hsp_empirical_probabilities; identical to subtree_average for a 0/1 trait here) for each permutation
.libPaths(c("Rlib", .libPaths())); suppressMessages({library(castor); library(ape)})
a <- commandArgs(TRUE); tr <- read.tree(a[1]); tr$node.label <- NULL; tr$edge.length[is.na(tr$edge.length)] <- 0
P <- read.csv("null/perm_inh.csv", row.names=1, check.names=FALSE)
isref <- tr$tip.label %in% rownames(P); q <- which(!isref)
out <- matrix(NA_real_, length(q), ncol(P), dimnames=list(tr$tip.label[q], colnames(P)))
t0 <- Sys.time()
for (j in seq_len(ncol(P))) {
  st <- rep(NA_integer_, length(tr$tip.label)); st[isref] <- P[tr$tip.label[isref], j] + 1L
  out[, j] <- hsp_empirical_probabilities(tr, st, Nstates=2)$likelihoods[q, 2]
}
cat("sec", as.numeric(difftime(Sys.time(), t0, units="secs")), "\n")
write.csv(signif(out, 5), a[2])
