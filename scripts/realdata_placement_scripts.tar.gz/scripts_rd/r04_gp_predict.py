"""Apply fitted GP models (gp_fit.json) to query placements (top EPA-ng placement). See r02_gp.py for definitions.
Writes q/<set>_gp.csv with mean / sd / P(score>80) per model, and gp_W_<set>_<model>.npy (float32, K^-1 K_rq)
for the label-permutation null (fixed variance components)."""
import sys, json, numpy as np, pandas as pd
from scipy.linalg import cho_solve
from scipy.stats import norm
src = open('scripts_rd/r02_gp.py').read().split('models = ')[0]; exec(src)
fits = json.load(open('gp_fit.json'))
SAVE_W = ['BM', 'BM_study']
def qdist(jp):
    import placement_lib as P
    top = P.parse_jplace(jp).set_index('query')
    J2 = json.load(open(jp)); p2, b2, e2, l2, *_ = P._parse_jplace_tree(J2['tree'])
    assert (np.array(l2, dtype=object)==np.array(label, dtype=object)).all() and (e2==enum).all()
    v = top.edge_num.map(e2node).values; p = parent[v]; d = top.distal_length.values; Lv = blen[v]; pl = top.pendant_length.values
    Dq = pl[None,:] + np.minimum(d[None,:] + Dn[:, v], (Lv-d)[None,:] + Dn[:, p])          # n x nq
    a = pl + np.minimum(d + d1[v], Lv-d + d1[p]); b = pl + np.minimum(d + d2[v], Lv-d + d2[p])
    return top.index, Dq, hmid(a, b)
for qset, jp in [('comm','epa_comm/epa_result.jplace'), ('meta','epa_meta/epa_result.jplace')]:
    ids, Dq, hq = qdist(jp); out = pd.DataFrame(index=ids)
    for m, f in fits.items():
        th = np.array(f['theta']); K = build(m, np.log(th)); _, (cf, mu, Kir, A) = reml(K)
        if m.startswith('BM'): Kq = th[0]*(hr[:,None] + hq[None,:] - Dq)/2; prior = th[0]*hq
        else: Kq = th[0]*np.exp(-th[1]*Dq); prior = np.full(len(hq), th[0])
        se2 = th[-1]
        W = cho_solve(cf, Kq, check_finite=False)
        Ki1 = cho_solve(cf, np.ones(n), check_finite=False)
        mean = mu + Kq.T @ Kir
        vphy = np.maximum(prior - np.einsum('ij,ij->j', Kq, W), 0)
        vmu = (1 - Ki1 @ Kq)**2 / A
        sd = np.sqrt(vphy + vmu + se2)
        out[f'{m}_mean'] = mean; out[f'{m}_sd_phylo'] = np.sqrt(vphy); out[f'{m}_sd_pred'] = sd
        out[f'{m}_P'] = norm.sf((80 - mean)/sd)
        if m in SAVE_W: np.save(f'gp_W_{qset}_{m}.npy', W.astype(np.float32)); json.dump(dict(mu=mu, A=A, ids=list(ids), ref_ids=list(S.index)), open(f'gp_W_{qset}_{m}.json','w')); np.save(f'gp_Ki1_{m}.npy', Ki1)
        print(qset, m, 'mean', out[f'{m}_mean'].describe().round(2).to_dict(), 'P', out[f'{m}_P'].mean().round(3), flush=True)
    out.to_csv(f'q/{qset}_gp.csv')
# reference-isolate in-sample check: posterior mean at the tips (fitted values) vs observed
np.save('gp_ref_meta.npy', np.array([mu]))
