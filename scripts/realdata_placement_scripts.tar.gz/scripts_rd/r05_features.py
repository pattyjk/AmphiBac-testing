"""Merge per-feature placement, castor (M2, SCP) and GP (M3/M4) predictions -> feature tables."""
import pandas as pd, numpy as np
ren = {'BM_mean':'M3_BM_score','BM_sd_pred':'M3_BM_sd','BM_P':'M3_BM_P','OU_mean':'M3_OU_score','OU_sd_pred':'M3_OU_sd','OU_P':'M3_OU_P',
       'BM_study_mean':'M4_BM_score','BM_study_sd_pred':'M4_BM_sd','BM_study_P':'M4_BM_P','OU_study_mean':'M4_OU_score','OU_study_sd_pred':'M4_OU_sd','OU_study_P':'M4_OU_P',
       'emp_prob':'M2_emp_prob','mk':'M2_mk','mk_ER':'M2_mk_ER','mk_ARD':'M2_mk_ARD','mp':'M2_mp','subtree_average':'M2_subtree_avg','scp_score':'M3_SCP_score'}
keep_pl = ['nsti','nsti_lwr_weighted','lwr','n_placements','pendant_length','edge_num','nearest_tip','M1_nearest_Func','M1_P','M1w_P','nearest_genus','nearest_family']
for qs in ['comm','meta']:
    pl = pd.read_csv(f'q/{qs}_placements.csv', index_col=0)[keep_pl]
    ca = pd.read_csv(f'q/{qs}_castor.csv', index_col=0); gp = pd.read_csv(f'q/{qs}_gp.csv', index_col=0)
    gp = gp[[c for c in gp.columns if c in ren]]
    sc = pd.read_csv(f'q/{qs}_cm_scores.csv').set_index('id')[['bits_per_nt']].rename(columns={'bits_per_nt':'cm_bits_per_nt'})
    # M1w undefined when every retained placement has LWR<0.01 (LWR spread over many equivalent edges): fall back to top placement
    pl['M1w_P'] = pl.M1w_P.fillna(pl.M1_P); pl['nsti_lwr_weighted'] = pl.nsti_lwr_weighted.fillna(pl.nsti)
    F = pl.join(ca).join(gp).join(sc).rename(columns=ren)
    assert F.M2_emp_prob.notna().all() and F.M4_BM_P.notna().all()
    if qs=='comm':
        for k, name in [('S','serdp'),('B','bullfrog')]:
            f = F[F.index.str[0]==k].copy(); f.index = f.index.str[2:]; f.index.name='feature'
            f.to_csv(f'{name}_feature_predictions.csv'); print(name, f.shape)
    else:
        F.index.name='sOTU'; F.to_csv('meta_feature_predictions.csv'); print('meta', F.shape)
f = pd.read_csv('serdp_feature_predictions.csv', index_col=0)
P = [c for c in f.columns if c.endswith('_P') or c.startswith('M2_')]
print(f[P].corr(method='spearman').round(2).to_string()); print(f[P].mean().round(3).to_dict())
