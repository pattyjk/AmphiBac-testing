"""Label-permutation null on the tree (fixed placements, fixed GP variance components): recompute per-feature predictions
for M1 (nearest tip), M2 emp_prob (castor, r07b), M3 BM and M4 BM+study (P(score>80) and score) under 200 global and
200 within-study shuffles; per-sample read-weighted means; SERDP clogit/OLS refits; r(observed, shuffled) per sample."""
import json, sys, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.stats import norm
sys.argv=['x']; exec(open('scripts_rd/r06_metrics_tests.py').read().split("if __name__")[0])
PI = pd.read_csv('null/perm_inh.csv', index_col=0); PS = pd.read_csv('null/perm_score.csv', index_col=0); perms = list(PI.columns)
def feature_null(qset, F, prefix):
    """returns dict method -> (nfeat x nperm) array, aligned to F.index (feature IDs without prefix)."""
    qid = [prefix+i for i in F.index]; out = {}
    out['M1_P'] = PI.reindex(F.nearest_tip).values.astype(float)
    E = pd.read_csv(f'null/{qset}_emp_null.csv', index_col=0); out['M2_emp_prob'] = E.reindex(qid)[perms].values
    gp = pd.read_csv(f'q/{qset}_gp.csv', index_col=0).reindex(qid)
    for m, tag in [('BM','M3_BM'), ('BM_study','M4_BM')]:
        W = np.load(f'gp_W_{qset}_{m}.npy', mmap_mode='r'); info = json.load(open(f'gp_W_{qset}_{m}.json'))
        Ki1 = np.load(f'gp_Ki1_{m}.npy'); col = pd.Index(info['ids']).get_indexer(qid); assert (col>=0).all()
        Y = PS.loc[info['ref_ids'], perms].values; mu = (Ki1 @ Y)/info['A']
        mean = mu[None,:] + np.asarray(W[:, col], dtype=np.float64).T @ (Y - mu[None,:])
        out[f'{tag}_score'] = mean; out[f'{tag}_P'] = norm.sf((80-mean)/gp[f'{m}_sd_pred'].values[:,None])
    return out
METH = ['M1_P','M2_emp_prob','M3_BM_P','M4_BM_P','M3_BM_score','M4_BM_score']
def per_sample(Xf, arr, ws): return (arr.T @ Xf) / ws   # nperm x nsamples
# ---------- SERDP ----------
M = pd.read_csv('serdp_meta.csv', index_col=0); X = pd.read_csv('serdp_table_rare2900.csv', index_col=0)[M.index]
F = pd.read_csv('serdp_feature_predictions.csv', index_col=0); Xf = X.reindex(F.index).fillna(0).values; ws = Xf.sum(0)
obs = pd.read_csv('serdp_tree_per_sample_metrics.csv', index_col=0).loc[M.index]
fn = feature_null('comm', F, 'S_'); D = M[['stratum','Inf','logBd']].copy()
rows=[]; ps_rows = {}
for m in METH:
    # sanity: unpermuted recomputation equals observed (GP check: run identity through same code path)
    S_null = per_sample(Xf, fn[m], ws); o = obs[m].values
    for j, pname in enumerate(perms):
        D['x'] = S_null[j]; b, se, p, n = clogit(D, 'x'); bl, sel, pl, nl = load(D, 'x')
        rows.append(dict(method=m, scheme=pname.rsplit('_',1)[0], perm=int(pname.rsplit('_',1)[1]), logOR=b, beta_load=bl, r_obs=np.corrcoef(S_null[j], o)[0,1]))
    for sch in ['global','within_study']:
        jj = [j for j,pn in enumerate(perms) if pn.startswith(sch)]
        ps_rows[(m,sch,'null_mean')] = S_null[jj].mean(0); ps_rows[(m,sch,'null_p95')] = np.percentile(S_null[jj],95,axis=0); ps_rows[(m,sch,'null_p05')] = np.percentile(S_null[jj],5,axis=0)
Nl = pd.DataFrame(rows); Nl.to_csv('null/serdp_tree_null_permutations.csv', index=False)
PSN = pd.DataFrame({f'{m}|{s}|{k}': v for (m,s,k), v in ps_rows.items()}, index=M.index)
for m in METH: PSN[f'{m}|observed'] = obs[m].values
PSN.to_csv('null/serdp_tree_null_per_sample.csv')
summ=[]
for m in METH:
    b,se,p,n = clogit(obs.join(M[['stratum','Inf','logBd']]), m); bl,sel,pl,nl = load(obs.join(M[['stratum','Inf','logBd']]), m)
    for sch in ['global','within_study']:
        g = Nl[(Nl.method==m)&(Nl.scheme==sch)]
        nm = PSN[f'{m}|{sch}|null_mean']; o = obs[m]
        summ.append(dict(method=m, scheme=sch, n_perm=len(g), obs_OR=np.exp(b), obs_OR_lo=np.exp(b-1.96*se), obs_OR_hi=np.exp(b+1.96*se),
            null_OR_median=np.exp(g.logOR.median()), null_OR_q025=np.exp(g.logOR.quantile(.025)), null_OR_q975=np.exp(g.logOR.quantile(.975)),
            pct_null_logOR_more_extreme=100*np.mean(np.abs(g.logOR)>=abs(b)), obs_beta_load=bl, null_beta_q025=g.beta_load.quantile(.025), null_beta_q975=g.beta_load.quantile(.975),
            pct_null_beta_more_extreme=100*np.mean(np.abs(g.beta_load)>=abs(bl)),
            r_obs_vs_null_mean=np.corrcoef(o, nm)[0,1], mean_r_obs_vs_single_perm=g.r_obs.mean(),
            pct_frogs_obs_above_null95=100*np.mean(o.values > PSN[f'{m}|{sch}|null_p95'].values),
            pct_frogs_obs_below_null05=100*np.mean(o.values < PSN[f'{m}|{sch}|null_p05'].values)))
Sm = pd.DataFrame(summ)
# ---------- bullfrog + meta: r(observed per-sample metric, shuffled mean) ----------
def corr_only(qset, F, prefix, Xdf, name):
    Xf = Xdf.reindex(F.index).fillna(0).values; ws = Xf.sum(0); keep = ws>0; Xf=Xf[:,keep]; ws=ws[keep]
    fn = feature_null(qset, F, prefix); res=[]
    for m in METH:
        o = F[m].values @ Xf / ws; S_null = per_sample(Xf, fn[m], ws)
        for sch in ['global','within_study']:
            jj = [j for j,pn in enumerate(perms) if pn.startswith(sch)]
            res.append(dict(dataset=name, method=m, scheme=sch, n_samples=int(keep.sum()), r_obs_vs_null_mean=np.corrcoef(o, S_null[jj].mean(0))[0,1],
                            mean_r_obs_vs_single_perm=np.mean([np.corrcoef(o, S_null[j])[0,1] for j in jj]),
                            pct_obs_above_null95=100*np.mean(o > np.percentile(S_null[jj],95,axis=0)), pct_obs_below_null05=100*np.mean(o < np.percentile(S_null[jj],5,axis=0))))
    return res
Fb = pd.read_csv('bullfrog_feature_predictions.csv', index_col=0); Xb = pd.read_csv('bf_table_rare1883.csv', index_col=0)
Xb = Xb[pd.read_csv('bullfrog_tree_per_sample_metrics.csv', index_col=0).index]
Fm = pd.read_csv('meta_feature_predictions.csv', index_col=0)
R = sp.load_npz('meta_rare1000.npz').toarray(); Xm = pd.DataFrame(R, index=[f'm{i}' for i in range(R.shape[0])], columns=np.load('meta_samples.npy'))
Fm.index = Fm.index.astype(str); Fm2 = Fm.copy(); Fm2.index = [i[2:] if i.startswith('m') and False else i for i in Fm.index]
C = pd.DataFrame(corr_only('comm', Fb, 'B_', Xb, 'bullfrog') + corr_only('meta', Fm2, '', Xm, 'meta-analysis (90 bp, sOTUs in >=5 samples)'))
S0 = Sm[['method','scheme','r_obs_vs_null_mean','mean_r_obs_vs_single_perm']].assign(dataset='SERDP')
C = pd.concat([S0, C]); C.to_csv('null/null_correlation_all_datasets.csv', index=False)
Sm.to_csv('null/serdp_tree_null_summary.csv', index=False)
pd.set_option('display.width', 250)
print(Sm.round(3).to_string()); print(C.pivot_table(index=['method'], columns=['dataset','scheme'], values='r_obs_vs_null_mean').round(3).to_string())
