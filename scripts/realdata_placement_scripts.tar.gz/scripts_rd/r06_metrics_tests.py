"""Per-sample tree-based metrics and Bd tests (SERDP: conditional logit within site x season strata + OLS load among infected,
reusing s02_bd_tests.py code; bullfrog: within-treatment Spearman + pond-mean OLS with Type)."""
import os, warnings, numpy as np, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.discrete.conditional_models import ConditionalLogit
from statsmodels.stats.multitest import multipletests
from scipy.stats import spearmanr, mannwhitneyu
warnings.filterwarnings('ignore')
PCOLS = ['M1_P','M1w_P','M2_emp_prob','M2_subtree_avg','M2_mk','M2_mk_ER','M2_mp','M3_BM_P','M3_OU_P','M4_BM_P','M4_OU_P']
SCOLS = ['M3_BM_score','M3_OU_score','M4_BM_score','M4_OU_score','M3_SCP_score']
NAMES = {'M1_P':'M1 nearest-tip','M1w_P':'M1 LWR-weighted nearest-tip','M2_emp_prob':'M2 castor emp_prob','M2_subtree_avg':'M2 castor subtree_average',
 'M2_mk':'M2 castor Mk (ARD, AIC)','M2_mk_ER':'M2 castor Mk ER','M2_mp':'M2 castor max parsimony','M3_BM_P':'M3 BM P(score>80)','M3_OU_P':'M3 OU P(score>80)',
 'M4_BM_P':'M4 BM+study P(score>80)','M4_OU_P':'M4 OU+study P(score>80)','M3_BM_score':'M3 BM score','M3_OU_score':'M3 OU score',
 'M4_BM_score':'M4 BM+study score','M4_OU_score':'M4 OU+study score','M3_SCP_score':'M3 castor SCP score'}
def sample_metrics(X, F, total):
    """X: features x samples counts (features with predictions only); total: total reads per sample (incl. unsequenced)."""
    out = {}; w = X.values; ws = w.sum(0)
    for c in PCOLS + SCOLS:
        v = F[c].values; out[c] = v @ w / ws
        for thr, tag in [(0.05,'n05'),(0.1,'n10')]:
            m = (F.nsti.values <= thr); ww = w[m]; s = ww.sum(0)
            out[f'{c}_{tag}'] = np.where(s>0, v[m] @ ww / np.where(s>0, s, 1), np.nan)
    out['wellplaced_share_n05'] = w[(F.nsti.values<=0.05)].sum(0)/total
    out['wellplaced_share_n10'] = w[(F.nsti.values<=0.1)].sum(0)/total
    out['placed_share'] = ws/total
    out['mean_nsti'] = F.nsti.values @ w / ws
    return pd.DataFrame(out, index=X.columns)
def metric_name(c):
    if c in NAMES: return NAMES[c]
    for suf, t in [('_n05',' [NSTI<=0.05]'),('_n10',' [NSTI<=0.1]')]:
        if c.endswith(suf): return NAMES[c[:-4]] + t
    return NAMES.get(c, c)
def z(x): return (x-x.mean())/x.std()
def clogit(d, col, adj=None):
    d = d.dropna(subset=[col]+([adj] if adj else []))
    g = d.groupby("stratum").Inf; ok = ((g.transform("sum")>0) & (g.transform("sum")<g.transform("size"))).values; d = d.loc[ok]
    Xm = pd.DataFrame({'m': z(d[col])})
    if adj: Xm['c'] = z(d[adj])
    r = ConditionalLogit(d.Inf.values, Xm.values, groups=d.stratum.values).fit(disp=0)
    return r.params[0], r.bse[0], r.pvalues[0], len(d)
def load(d, col, adj=None):
    d = d[d.Inf==1].dropna(subset=[col]+([adj] if adj else [])).copy(); d['zm']=z(d[col])
    f = 'logBd ~ zm + C(stratum)' + (' + zc' if adj else '')
    if adj: d['zc']=z(d[adj])
    r = smf.ols(f, d).fit(); return r.params['zm'], r.bse['zm'], r.pvalues['zm'], len(d)
if __name__ == '__main__':
    # ---------------- SERDP ----------------
    M = pd.read_csv('serdp_meta.csv', index_col=0); Sprev = pd.read_csv('serdp_per_sample_metrics.csv', index_col=0)
    X = pd.read_csv('serdp_table_rare2900.csv', index_col=0)[M.index]; total = X.sum(0).values
    F = pd.read_csv('serdp_feature_predictions.csv', index_col=0); Xs = X.reindex(F.index).fillna(0)
    print('SERDP: features in table with predictions', X.index.isin(F.index).sum(), 'of', len(X), '; read share', round(Xs.values.sum()/total.sum(),3))
    SM = sample_metrics(Xs, F, total); SM.index.name='SampleID'; SM.to_csv('serdp_tree_per_sample_metrics.csv')
    D = M[['stratum','Inf','logBd','seq_frac']].join(SM).join(Sprev[['FullDatabase_0.99_Prop','Inhibitory_0.99_Prop','Majority_99_Prop']])
    # Mk (ER/ARD) predictions are constant across features (fitted rates ~1e5 -> stationary frequencies; degenerate) and
    # subtree_average == emp_prob for a 0/1 trait: both excluded from tests (kept in the per-sample table)
    EXCL = ('M2_mk','M2_subtree_avg')
    cols = [c for c in SM.columns if c not in ('placed_share','mean_nsti') and not c.startswith(EXCL)] + ['mean_nsti','FullDatabase_0.99_Prop','Inhibitory_0.99_Prop','Majority_99_Prop']
    NAMES.update({'wellplaced_share_n05':'Well-placed share (NSTI<=0.05)','wellplaced_share_n10':'Well-placed share (NSTI<=0.1)','mean_nsti':'Mean NSTI',
                  'FullDatabase_0.99_Prop':'PIPELINE cultured share (Full, 99%)','Inhibitory_0.99_Prop':'PIPELINE Inhibitory, 99%','Majority_99_Prop':'PIPELINE majority vote, 99%'})
    rows=[]
    for col in cols:
        for adj in [None, 'wellplaced_share_n05', 'FullDatabase_0.99_Prop']:
            if adj==col or (adj and col.startswith('wellplaced')): continue
            if D[col].dropna().std()==0: continue
            b,se,p,n = clogit(D,col,adj); rows.append(dict(metric=metric_name(col),col=col,adjusted_for=adj or 'none',outcome='infected (conditional logit, OR per SD)',est=np.exp(b),lo=np.exp(b-1.96*se),hi=np.exp(b+1.96*se),p=p,n=n))
            b,se,p,n = load(D,col,adj); rows.append(dict(metric=metric_name(col),col=col,adjusted_for=adj or 'none',outcome='log10 Bd among infected (beta per SD)',est=b,lo=b-1.96*se,hi=b+1.96*se,p=p,n=n))
    R = pd.DataFrame(rows); R['q_BH'] = R.groupby(['outcome','adjusted_for']).p.transform(lambda p: multipletests(p,method='fdr_bh')[1])
    naive=[]
    for col in cols:
        a = D.loc[D.Inf==1,col].dropna(); b = D.loc[D.Inf==0,col].dropna()
        rho,p = spearmanr(D[col],D.logBd,nan_policy='omit')
        naive.append(dict(metric=metric_name(col),col=col,median_inf=a.median(),median_uninf=b.median(),p_MWU=mannwhitneyu(a,b).pvalue,spearman_logBd=rho,p_spearman=p))
    Nv = pd.DataFrame(naive); Nv['q_MWU']=multipletests(Nv.p_MWU,method='fdr_bh')[1]; Nv['q_spearman']=multipletests(Nv.p_spearman,method='fdr_bh')[1]
    R.to_csv('serdp_tree_stratified_tests.csv',index=False); Nv.to_csv('serdp_tree_naive_tests.csv',index=False)
    pd.set_option('display.width',250)
    r0 = R[(R.adjusted_for=='none')]
    print(r0[r0.outcome.str.startswith('inf')][['metric','est','lo','hi','p','q_BH','n']].round(3).to_string())
    print(r0[r0.outcome.str.startswith('log')][['metric','est','lo','hi','p','q_BH','n']].round(3).to_string())
    print(R[(R.adjusted_for!='none')&(R.p<0.05)][['metric','adjusted_for','outcome','est','p','q_BH']].round(3).to_string())
    print(Nv[Nv.p_MWU<0.05][['metric','median_inf','median_uninf','p_MWU','q_MWU']].round(4).to_string())
    print('corr tree metrics with pipeline Inhibitory_0.99:', D[PCOLS+SCOLS].corrwith(D['Inhibitory_0.99_Prop']).round(2).to_dict())
    print('corr with cultured share:', D[['wellplaced_share_n05','M4_BM_P','M2_emp_prob','M1_P']].corrwith(D['FullDatabase_0.99_Prop']).round(2).to_dict())
    # ---------------- Bullfrog ----------------
    m = pd.read_csv('bf_map.txt', sep='\t').set_index('SampleID')
    A = pd.read_csv('bf_asv_table.txt', sep='\t', index_col=0)
    rng = np.random.default_rng(1); keep = [s for s in A.columns if A[s].sum()>=1883]
    R2 = {}
    for s in keep:
        c = A[s].values.astype(int); pool = np.repeat(np.arange(len(c)), c); pick = rng.choice(pool, 1883, replace=False)
        R2[s] = np.bincount(pick, minlength=len(c))
    Xb = pd.DataFrame(R2, index=A.index); Xb.to_csv('bf_table_rare1883.csv')
    Fb = pd.read_csv('bullfrog_feature_predictions.csv', index_col=0); Xbb = Xb.reindex(Fb.index).fillna(0)
    BM_ = sample_metrics(Xbb, Fb, Xb.sum(0).values); BM_.index.name='SampleID'
    prev = pd.read_csv('bf_prev_metrics.csv').set_index('SampleID')
    d = BM_.join(m[['Type','Pond','LogBd']], how='inner').join(prev[['Full_Proportion','Inhibitory_Proportion','Majority_Proportion']])
    d = d[d.index.isin(prev.index)]; d['HighN']=(d.Type=='High N').astype(int)
    d.to_csv('bullfrog_tree_per_sample_metrics.csv'); print('bullfrog frogs', len(d), 'kept after rarefaction', len(keep))
    NAMES.update({'Full_Proportion':'PIPELINE cultured share (Full, 99%)','Inhibitory_Proportion':'PIPELINE Inhibitory, 99%','Majority_Proportion':'PIPELINE majority vote, 99%'})
    bcols = [c for c in cols if c in d.columns] + ['Full_Proportion','Inhibitory_Proportion','Majority_Proportion']
    br=[]
    for k in bcols:
        if d[k].dropna().std()==0: continue
        r = dict(metric=metric_name(k), col=k)
        dd = d.dropna(subset=[k]); r['n']=len(dd)
        r['naive_rho'], r['naive_p'] = spearmanr(dd[k], dd.LogBd)
        for t, tag in [('Low N','lowN'),('High N','highN')]:
            s = dd[dd.Type==t]; r[f'{tag}_rho'], r[f'{tag}_p'] = spearmanr(s[k], s.LogBd); r[f'{tag}_n']=len(s)
        pp = dd.groupby('Pond').agg(x=(k,'mean'), LogBd=('LogBd','mean'), HighN=('HighN','first'), wp=('wellplaced_share_n05','mean')).reset_index()
        pp['x'] = z(pp.x); o = smf.ols('LogBd ~ x + HighN', pp).fit(); ci = o.conf_int().loc['x']
        r.update(pond_beta_perSD=o.params['x'], pond_lo=ci[0], pond_hi=ci[1], pond_p=o.pvalues['x'], pond_n=len(pp))
        if not k.startswith('wellplaced'):
            o2 = smf.ols('LogBd ~ x + wp + HighN', pp).fit(); r.update(pondWP_beta_perSD=o2.params['x'], pondWP_p=o2.pvalues['x'])
        br.append(r)
    B = pd.DataFrame(br)
    for c in ['lowN_p','highN_p','pond_p','naive_p']: B[c.replace('_p','_q_BH')] = multipletests(B[c].fillna(1),method='fdr_bh')[1]
    B.to_csv('bullfrog_tree_tests.csv', index=False)
    print(B[['metric','n','lowN_rho','lowN_p','highN_rho','highN_p','pond_beta_perSD','pond_p','pond_q_BH']].round(3).to_string())
    with pd.ExcelWriter('tree_metrics_Bd_tests.xlsx') as w:
        pd.DataFrame({'note':[
         'Tree-based per-sample metrics: read-weighted mean of per-feature P(inhibitory) or predicted CFS score over features with sequences (SERDP 150-bp deblur V4; unsequenced features excluded from denominators), and the same restricted to features with top-placement NSTI <=0.05 / <=0.1.',
         'Well-placed share = reads with NSTI<=0.05 / all reads (analogue of the cultured share). Placement: EPA-ng 0.3.8 into the full 7,279-isolate AmphiBac reference tree (top placement).',
         'SERDP: conditional logit grouped by species-site x season strata (strata with both outcomes), OR per SD; OLS log10(Bd+1) ~ metric + stratum among infected; adjustments: well-placed share or pipeline cultured share. BH within outcome x adjustment.',
         'Bullfrog: rarefied 1,883 (seed 1), 40 frogs with Bd data; within-treatment Spearman; pond-mean OLS LogBd ~ z(metric) + Type (n=10 ponds), +well-placed share.']}).to_excel(w, sheet_name='README', index=False)
        R.to_excel(w, sheet_name='SERDP_stratified', index=False); Nv.to_excel(w, sheet_name='SERDP_naive', index=False); B.to_excel(w, sheet_name='bullfrog', index=False)
