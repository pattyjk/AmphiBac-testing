# M2 castor hidden-state prediction on the reference tree with every query grafted as a new tip at its top
# EPA-ng placement (gappa examine graft; pendant length kept). Query tips have NA state -> exact attachment.
# Binary trait: Inhibitory (state 2) vs not (state 1). Methods: mp, emp_prob, mk ER/ARD (AIC), subtree_average;
# continuous score: squared-change parsimony (M3 castor point estimate, scored tips only).
# usage: Rscript r03_castor_hsp.R graft.newick out.csv [perm_file.csv] ; perm mode reruns emp_prob + mk(ER) + subtree_avg
.libPaths(c("Rlib", .libPaths())); suppressMessages({library(castor); library(ape)})
a <- commandArgs(TRUE); tr <- read.tree(a[1]); tr$node.label <- NULL
tr$edge.length[is.na(tr$edge.length)] <- 0
tt <- read.csv("ref/tip_table.csv", row.names=1); tt <- tt[tt$in_tree=="True" | tt$in_tree==TRUE, ]
isref <- tr$tip.label %in% rownames(tt); q <- which(!isref)
pred <- function(inh, score, full=TRUE) {
  st <- rep(NA_integer_, length(tr$tip.label)); st[isref] <- ifelse(inh[tr$tip.label[isref]], 2L, 1L)
  out <- data.frame(query=tr$tip.label[q])
  t0 <- Sys.time()
  out$emp_prob <- hsp_empirical_probabilities(tr, st, Nstates=2)$likelihoods[q, 2]
  x <- rep(NA_real_, length(st)); x[isref] <- st[isref] - 1
  out$subtree_average <- hsp_subtree_averaging(tr, x)$states[q]
  er <- hsp_mk_model(tr, st, Nstates=2, rate_model="ER", root_prior="empirical", Ntrials=1, Nthreads=1, check_input=FALSE)
  out$mk_ER <- er$likelihoods[q, 2]; info <- list(ER_rate=er$transition_matrix[1,2], ER_logLik=er$loglikelihood)
  if (full) {
    ard <- hsp_mk_model(tr, st, Nstates=2, rate_model="ARD", root_prior="empirical", Ntrials=2, Nthreads=1, check_input=FALSE)
    out$mk_ARD <- ard$likelihoods[q, 2]
    info$ARD_q12 <- ard$transition_matrix[1,2]; info$ARD_q21 <- ard$transition_matrix[2,1]; info$ARD_logLik <- ard$loglikelihood
    info$AIC_ER <- -2*er$loglikelihood + 2; info$AIC_ARD <- -2*ard$loglikelihood + 4
    out$mk <- if (info$AIC_ARD < info$AIC_ER) out$mk_ARD else out$mk_ER
    mp <- hsp_max_parsimony(tr, st, Nstates=2, transition_costs="all_equal", weight_by_scenarios=TRUE)
    out$mp <- mp$likelihoods[q, 2]
    # continuous score at grafted query tips: squared-change parsimony needs all-known tips -> prune unscored refs
    sc <- score[tr$tip.label]; keep <- !isref | !is.na(sc)
    tr2 <- keep.tip(tr, tr$tip.label[keep]); y <- unname(score[tr2$tip.label])
    s2 <- hsp_squared_change_parsimony(tr2, y, weighted=TRUE)
    names(s2$states) <- NULL; v <- s2$states[seq_along(tr2$tip.label)]; names(v) <- tr2$tip.label
    out$scp_score <- v[out$query]
  }
  info$sec <- as.numeric(difftime(Sys.time(), t0, units="secs")); list(out=out, info=info)
}
inh <- setNames(tt$Func=="Inhibitory", rownames(tt)); score <- setNames(tt$score, rownames(tt))
if (length(a) < 3) {
  r <- pred(inh, score, TRUE); write.csv(r$out, a[2], row.names=FALSE); print(unlist(r$info))
} else {  # permutation mode: file with columns perm, FastaID, Func  (shuffled labels)
  P <- read.csv(a[3]); res <- list()
  for (k in sort(unique(P$perm))) {
    pk <- P[P$perm==k, ]; ik <- setNames(pk$Func=="Inhibitory", pk$FastaID)
    r <- pred(ik, score, FALSE); r$out$perm <- k; res[[length(res)+1]] <- r$out
    if (k %% 20 == 0) cat("perm", k, r$info$sec, "\n")
  }
  write.csv(do.call(rbind, res), a[2], row.names=FALSE)
}
