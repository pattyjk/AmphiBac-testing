"""Host-matched track step 3a: Bd tests with restricted (host/location-matched) metrics.
SERDP: conditional logit of infection within site x season strata (strata with both outcomes) and OLS log10 Bd ~ metric + stratum among infected;
pooled over the sites where each restricted set applies, and per site. Same frogs scored with the unrestricted DB for comparison.
Bullfrog: within-treatment Spearman (metric vs LogBd) and pond-mean OLS LogBd ~ metric + Type."""
import pandas as pd, numpy as np, warnings
import statsmodels.formula.api as smf
from statsmodels.discrete.conditional_models import ConditionalLogit
from statsmodels.stats.multitest import multipletests
from scipy.stats import spearmanr
warnings.filterwarnings('ignore')
z = lambda x: (x-x.mean())/x.std()
def clogit(d, col):
    d = d.dropna(subset=[col]); d = d[d.groupby('stratum').Inf.transform(lambda s: 0<s.sum()<len(s))]
    if len(d)<10 or d[col].std()==0 or d[col].nunique()<3: return [np.nan]*4+[len(d)]
    try: r = ConditionalLogit(d.Inf.values, z(d[col]).values[:,None], groups=d.stratum.values).fit(disp=0)
    except Exception: return [np.nan]*4+[len(d)]
    b, se = r.params[0], r.bse[0]; return [np.exp(b), np.exp(b-1.96*se), np.exp(b+1.96*se), r.pvalues[0], len(d)]
def load(d, col):
    d = d[d.Inf==1].dropna(subset=[col]).copy()
    if len(d)<8 or d[col].std()==0 or d[col].nunique()<3: return [np.nan]*4+[len(d)]
    d['zm'] = z(d[col]); f = 'logBd ~ zm' + (' + C(stratum)' if d.stratum.nunique()>1 else '')
    r = smf.ols(f, d).fit(); b, se = r.params['zm'], r.bse['zm']; return [b, b-1.96*se, b+1.96*se, r.pvalues['zm'], len(d)]
M = pd.read_csv('serdp_meta.csv', index_col=0); D = pd.read_csv('out/serdp_per_sample_restricted.csv', index_col=0)
D = M[['Inf','logBd','stratum','Specis_Site','seq_frac']].join(D.drop(columns=['site']))
APPL = {'serdp_LISP_species':['LISP_LA','LISP_TN'], 'serdp_genus':['LIPI_PA','LIPI_VT','LIBL_NM','LIPI_Panama','LISP_LA','LISP_TN'],
        'serdp_TN':['LISP_TN'], 'serdp_Panama':['LIPI_Panama'], 'serdp_TN_species':['LISP_TN'],
        'HM_species':['LIPI_PA','LIPI_VT','LIBL_NM','LIPI_Panama','LISP_LA','LISP_TN'], 'HM_location':['LISP_TN','LIPI_Panama'], 'HM_species_location':['LISP_TN']}
MET = {'Inhibitory_Prop':'Inhibitory proportion','InhibitoryStrict_Prop':'InhibitoryStrict proportion','Facilitating_Prop':'Facilitating proportion',
       'FullDatabase_Prop':'Cultured share (Full)','Inhibitory_Richness':'Inhibitory richness','Inh_over_Full':'Inhibitory / Full ratio','anyhit_Inh_Prop':'Inhibitory any-hit, full query coverage (exhaustive)','partial_overlap_share':'Share of matched reads on partial-overlap hits'}
rows=[]
for tag, sites in APPL.items():
    scopes = [('pooled: '+'+'.join(sites), sites)] + ([(s, [s]) for s in sites] if len(sites)>1 else [])
    for scope, ss in scopes:
        d = D[D.Specis_Site.isin(ss)]
        for m, nm in MET.items():
            for db, col in [('restricted', f'{tag}__{m}'), ('full DB (same frogs)', f'ALL__{m}')]:
                if col not in d.columns: continue
                rows.append(dict(dataset='SERDP', reference_set=tag, scope=scope, metric=nm, db=db, outcome='infected: conditional logit OR per SD', **dict(zip(['est','lo','hi','p','n'], clogit(d, col)))))
                rows.append(dict(dataset='SERDP', reference_set=tag, scope=scope, metric=nm, db=db, outcome='log10 Bd among infected: beta per SD', **dict(zip(['est','lo','hi','p','n'], load(d, col)))))
# bullfrog
B = pd.read_csv('bf_map.txt', sep='\t', index_col=0)[['Type','Pond','LogBd']].join(pd.read_csv('out/bullfrog_per_sample_restricted.csv', index_col=0), how='inner')
for tag in ['ALL','bf_species','bf_MA','bf_genus','bf_NE']:
    for m, nm in MET.items():
        col = f'{tag}__{m}'
        if col not in B.columns: continue
        for t, d in B.groupby('Type'):
            rho, p = spearmanr(d[col], d.LogBd) if d[col].nunique()>1 else (np.nan, np.nan)
            rows.append(dict(dataset='bullfrog', reference_set=tag, scope=f'within {t}', metric=nm, db='restricted' if tag!='ALL' else 'full DB', outcome='Spearman rho vs LogBd', est=rho, p=p, n=len(d)))
        pm = B.groupby('Pond').agg(LogBd=('LogBd','mean'), x=(col,'mean'), Type=('Type','first'))
        if pm.x.std()>0:
            pm['zx'] = z(pm.x); r = smf.ols('LogBd ~ zx + C(Type)', pm).fit()
            rows.append(dict(dataset='bullfrog', reference_set=tag, scope='pond means (+Type)', metric=nm, db='restricted' if tag!='ALL' else 'full DB', outcome='pond-mean OLS beta per SD',
                             est=r.params['zx'], lo=r.conf_int().loc['zx',0], hi=r.conf_int().loc['zx',1], p=r.pvalues['zx'], n=len(pm)))
R = pd.DataFrame(rows)
R['q_BH'] = np.nan; k = R.p.notna()
R.loc[k,'q_BH'] = R[k].groupby(['dataset','db','outcome']).p.transform(lambda p: multipletests(p, method='fdr_bh')[1])
R.to_csv('out/bd_tests_restricted.csv', index=False)
with pd.ExcelWriter('out/bd_tests_restricted.xlsx') as w:
    pd.DataFrame({'note':[__doc__, 'BH-FDR within dataset x db x outcome. LIPI_Panama: all 13 frogs infected, so only load tests apply. NaN = metric constant / too few frogs.']}).to_excel(w, sheet_name='README', index=False)
    R[R.dataset=='SERDP'].to_excel(w, sheet_name='SERDP', index=False); R[R.dataset=='bullfrog'].to_excel(w, sheet_name='bullfrog', index=False)
pd.set_option('display.width',250)
x = R[(R.metric=='Inhibitory proportion')]
print(x[['dataset','reference_set','scope','db','outcome','est','lo','hi','p','n']].round(3).to_string())
print('min q restricted', R[R.db=='restricted'].q_BH.min(), R.loc[R[R.db=='restricted'].p.idxmin()][['dataset','reference_set','scope','metric','outcome','est','p','q_BH']].to_dict())
