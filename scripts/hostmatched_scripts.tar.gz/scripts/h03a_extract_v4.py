"""Extract V4 (between 515F GTG[CT]CAGC[AC]GCCGCGGTAA and the reverse complement of 806R, i.e. ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC; primers excluded)
from tested AmphiBac isolates on either strand."""
import re, pandas as pd
F = re.compile('GTG[CT]CAGC[AC]GCCGCGGTAA'); R = re.compile('ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC')
rc = lambda s: s[::-1].translate(str.maketrans('ACGTRYKMSWBDHVN','TGCAYRMKSWVHDBN'))
I = pd.read_csv('work/isolates_norm.csv', index_col=0)
seq={}; k=None
for l in open('db/FullDatabase_2025.1.fasta'):
    l=l.strip()
    if l.startswith('>'): k=l[1:].split()[0]; seq[k]=[]
    else: seq[k].append(l.upper())
out={}
for i in I.index[I.tested]:
    s=''.join(seq[i])
    for t in (s, rc(s)):
        f=F.search(t)
        if not f: continue
        r=R.search(t, f.end())
        if r: out[i]=t[f.end():r.start()]; break
L=pd.Series({k:len(v) for k,v in out.items()})
print('tested', I.tested.sum(), 'with V4', len(out), 'len', L.describe().round(1).to_dict())
with open('work/v4_tested.fasta','w') as o:
    for k,v in out.items(): o.write(f'>{k}\n{v}\n')
