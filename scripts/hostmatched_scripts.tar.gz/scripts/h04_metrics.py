"""Host-matched track step 2: per-sample pipeline metrics against restricted subsets (exact q2-vsearch runs, uc/),
comparison with full-database metrics, exhaustive-derived any-hit metrics and label-permutation intervals."""
import pandas as pd, numpy as np, scipy.sparse as sp, os, re, glob
from scipy.stats import spearmanr
rng = np.random.default_rng(1); NPERM = 200
I = pd.read_csv('work/isolates_norm.csv', index_col=0)
MODES = ['FullDatabase','Inhibitory','InhibitoryStrict','Facilitating']
def uc(p):
    if not os.path.exists(p): return {}
    u = pd.read_csv(p, sep='\t', header=None, usecols=[0,8,9], dtype=str); u = u[u[0]=='H']; return dict(zip(u[8], u[9]))
PART = {}
def exh(p):
    E = pd.read_csv(p, sep='\t', header=None, names=['q','t','id','alnlen','mism','gaps','ql','qilo','qihi'])
    E['partial'] = (E.qilo>1)|(E.qihi<E.ql)            # iddef 2 ignores terminal gaps: a 20-bp overlap scores 100%
    PART.update(dict(zip(zip(E.q,E.t), E.partial)))
    return E.loc[~E.partial, ['q','t']]                 # any-hit derivation uses full-query-coverage hits only
def metrics(X, depth, hits):
    """X: DataFrame features x samples (counts); hits: dict query->ref. Returns Prop, Richness, matched-mask."""
    f = X.index.isin(list(hits)); sub = X[f]
    prop = sub.sum(0)/depth
    if f.sum()==0: return prop, pd.Series(0, index=X.columns)
    refs = pd.Series([hits[q] for q in sub.index], index=sub.index)
    rich = sub.gt(0).T.dot(pd.get_dummies(refs).astype(int)).gt(0).sum(1)
    return prop, rich
def setmetrics(X, depth, prefix, tag):
    o = {}; H = {m: uc(f'uc/{prefix}__{tag}__{m}.uc') for m in MODES}
    for m in MODES:
        p, r = metrics(X, depth, H[m]); o[f'{m}_Prop'] = p; o[f'{m}_Richness'] = r
    o = pd.DataFrame(o)
    pf = pd.Series({q: PART.get((q,t), np.nan) for q,t in H['FullDatabase'].items()}, dtype=float)
    sub = X[X.index.isin(pf.index)]
    o['partial_overlap_share'] = sub[pf.reindex(sub.index).fillna(0).astype(bool).values].sum(0)/sub.sum(0).replace(0,np.nan)
    o['Inh_over_Full'] = o.Inhibitory_Prop/o.FullDatabase_Prop.replace(0,np.nan)
    # coverage lost: reads matched (Full) against the unrestricted DB but unmatched in this subset
    return o, H['FullDatabase']
def anyhit_perm(X, depth, E, iso_set):
    """Exhaustive-derived any-hit Inhibitory proportion restricted to iso_set, plus label-permutation intervals
    (Func shuffled among the tested isolates of the restricted set)."""
    e = E[E.t.isin(iso_set)]; e = e[e.q.isin(X.index)]
    fe = pd.Index(sorted(e.q.unique())); tl = I.loc[iso_set]; tested = tl.index[tl.tested]
    full_any = X.reindex(fe).fillna(0).sum(0)/depth
    et = e[e.t.isin(tested)]; ti = pd.Index(tested)
    if len(et)==0: z = pd.Series(0.0, index=X.columns); return full_any, z, z, z, z
    B = sp.csr_matrix((np.ones(len(et)), (fe.get_indexer(et.q), ti.get_indexer(et.t))), shape=(len(fe), len(ti)))
    Xf = X.reindex(fe).fillna(0).values.T
    inh = (I.loc[ti,'Func']=='Inhibitory').values.astype(float)
    obs = Xf.dot((B.dot(inh)>0).astype(float))/depth
    null = np.array([Xf.dot((B.dot(rng.permutation(inh))>0).astype(float))/depth for _ in range(NPERM)])
    S = lambda a: pd.Series(a, index=X.columns)
    return full_any, S(obs), S(null.mean(0)), S(np.percentile(null,2.5,0)), S(np.percentile(null,97.5,0))
def cov_lost(X, Hall, Hres):
    lost = X.index.isin(list(Hall)) & ~X.index.isin(list(Hres)); den = X[X.index.isin(list(Hall))].sum(0)
    return X[lost].sum(0)/den.replace(0,np.nan)
def wide(base, sets, X, depth, prefix, E):
    out = base.add_prefix('ALL__')
    for tag, members in sets.items():
        o, Hf = setmetrics(X, depth, prefix, tag); o['coverage_lost'] = cov_lost(X, HALL, Hf)
        fa, ob, nm, lo, hi = anyhit_perm(X, depth, E, members)
        o['anyhit_Full_Prop'] = fa; o['anyhit_Inh_Prop'] = ob; o['perm_Inh_mean'] = nm; o['perm_Inh_lo95'] = lo; o['perm_Inh_hi95'] = hi
        o['Inh_above_perm95'] = o.anyhit_Inh_Prop > o.perm_Inh_hi95
        out = out.join(o.add_prefix(f'{tag}__'))
    return out
def compare(D, sets, dsname, sample_mask=None):
    rows=[]
    for tag in sets:
        for m in ['FullDatabase_Prop','Inhibitory_Prop','InhibitoryStrict_Prop','Facilitating_Prop','Inhibitory_Richness','Inh_over_Full']:
            a, b = D[f'ALL__{m}'], D[f'{tag}__{m}']; k = a.notna()&b.notna()
            if sample_mask is not None: k &= sample_mask.get(tag, k)
            rho = spearmanr(a[k], b[k])[0] if k.sum()>2 and b[k].nunique()>1 else np.nan
            rows.append(dict(dataset=dsname, set=tag, metric=m, n=int(k.sum()), spearman_vs_full=rho, mean_full=a[k].mean(), mean_restricted=b[k].mean(),
                 median_cov_lost=D.loc[k, f'{tag}__coverage_lost'].median(), median_partial_overlap_share=D.loc[k, f'{tag}__partial_overlap_share'].median(), mean_partial_overlap_share=D.loc[k, f'{tag}__partial_overlap_share'].mean(), mean_partial_overlap_share_ALL=D.loc[k, 'ALL__partial_overlap_share'].mean(), mean_cov_lost=D.loc[k, f'{tag}__coverage_lost'].mean(),
                 r_anyhit_vs_pipeline=np.corrcoef(D.loc[k, f'{tag}__anyhit_Inh_Prop'], D.loc[k, f'{tag}__Inhibitory_Prop'])[0,1] if m=='Inhibitory_Prop' else np.nan,
                 max_abs_diff_anyhit=(D.loc[k, f'{tag}__anyhit_Inh_Prop']-D.loc[k, f'{tag}__Inhibitory_Prop']).abs().max() if m=='Inhibitory_Prop' else np.nan,
                 pct_above_perm95=100*D.loc[k, f'{tag}__Inh_above_perm95'].mean() if m=='Inhibitory_Prop' else np.nan))
    return rows
CMP = []
# ---------------- bullfrog
bf = pd.read_csv('work/bf_raw.csv', index_col=0).drop(columns=['P10F3','P4F1'])
def rarefy_df(X, depth, seed=1):
    r = np.random.default_rng(seed); out = {}
    for c in X.columns:
        v = X[c].values.astype(np.int64); out[c] = r.multivariate_hypergeometric(v, depth)
    return pd.DataFrame(out, index=X.index)
Xb = rarefy_df(bf, 1883); Eb = exh('uc/bf_exh099.tsv')
HALL = uc('uc/bf__ALL__FullDatabase.uc'); base,_ = setmetrics(Xb, 1883, 'bf', 'ALL')
BFS = {t: I.index[m] for t,m in {'bf_species': I.host=='lithobates catesbeianus', 'bf_MA': I.state=='MA', 'bf_genus': I.genus.isin(['lithobates','rana']),
       'bf_NE': I.state.isin(['MA','New Jersey'])}.items()}
fa, ob, nm, lo, hi = anyhit_perm(Xb, 1883, Eb, I.index); base['anyhit_Inh_Prop']=ob; base['perm_Inh_lo95']=lo; base['perm_Inh_hi95']=hi
Db = wide(base, BFS, Xb, 1883, 'bf', Eb); Db.index.name='SampleID'; Db.to_csv('out/bullfrog_per_sample_restricted.csv'); CMP += compare(Db, BFS, 'bullfrog')
# ---------------- SERDP
Xs = pd.read_csv('serdp_table_rare2900.csv', index_col=0); Ms = pd.read_csv('serdp_meta.csv', index_col=0); Xs = Xs[Ms.index]
Es = exh('uc/serdp_exh099.tsv'); HALL = uc('uc/serdp__ALL__FullDatabase.uc'); base,_ = setmetrics(Xs, 2900, 'serdp', 'ALL')
fa, ob, nm, lo, hi = anyhit_perm(Xs, 2900, Es, I.index); base['anyhit_Inh_Prop']=ob; base['perm_Inh_lo95']=lo; base['perm_Inh_hi95']=hi
SS = {t: I.index[m] for t,m in {'serdp_LISP_species': I.host=='lithobates sphenocephalus', 'serdp_genus': I.genus.isin(['lithobates','rana']),
      'serdp_TN': I.state=='Tennessee', 'serdp_Panama': I.country=='panama', 'serdp_TN_species': (I.host=='lithobates sphenocephalus')&(I.state=='Tennessee')}.items()}
Ds = wide(base, SS, Xs, 2900, 'serdp', Es)
site = Ms.Specis_Site
APPL = {'serdp_LISP_species':['LISP_LA','LISP_TN'], 'serdp_genus':['LIPI_PA','LIPI_VT','LIBL_NM','LIPI_Panama','LISP_LA','LISP_TN'], 'serdp_TN':['LISP_TN'],
        'serdp_Panama':['LIPI_Panama'], 'serdp_TN_species':['LISP_TN']}
# per-site 'host-matched' composite: best available matching for each site (species if available else genus; location if available)
Ds['site'] = site
for kind, rule in {'HM_species': {'LISP_LA':'serdp_LISP_species','LISP_TN':'serdp_LISP_species','LIPI_PA':'serdp_genus','LIPI_VT':'serdp_genus','LIBL_NM':'serdp_genus','LIPI_Panama':'serdp_genus'},
                   'HM_location': {'LISP_TN':'serdp_TN','LIPI_Panama':'serdp_Panama'},
                   'HM_species_location': {'LISP_TN':'serdp_TN_species'}}.items():
    for m in ['FullDatabase_Prop','Inhibitory_Prop','InhibitoryStrict_Prop','Facilitating_Prop','Inhibitory_Richness','Inh_over_Full','coverage_lost']:
        Ds[f'{kind}__{m}'] = [Ds.at[s, f'{rule[st]}__{m}'] if st in rule else np.nan for s, st in zip(Ds.index, Ds.site)]
    Ds[f'{kind}__source_set'] = Ds.site.map(rule)
Ds.index.name='SampleID'; Ds.to_csv('out/serdp_per_sample_restricted.csv')
CMP += compare(Ds, SS, 'serdp', {t: Ds.site.isin(v) for t,v in APPL.items()})
# ---------------- meta
R = sp.load_npz('work/meta_rare_s1.npz').tocsc(); F = pd.read_csv('work/meta_features.csv'); S = pd.read_csv('work/meta_sample_sets.csv', index_col=0)
Xm_all = pd.DataFrame.sparse.from_spmatrix(R, index=F.fid, columns=S.index)
keep = np.asarray(R.sum(1)).ravel()>0; Xm_all = Xm_all[keep].sparse.to_dense()
Em = exh('uc/meta_exh099.tsv'); HALL = uc('uc/meta__ALL__FullDatabase.uc')
base,_ = setmetrics(Xm_all, 1000, 'meta', 'ALL'); fa, ob, nm, lo, hi = anyhit_perm(Xm_all, 1000, Em, I.index)
base['anyhit_Full_Prop']=fa; base['anyhit_Inh_Prop']=ob; base['perm_Inh_lo95']=lo; base['perm_Inh_hi95']=hi
Dm = base.add_prefix('ALL__'); Dm = S[['host','country','study','set_host','set_hostcountry','set_country']].join(Dm)
cols = ['partial_overlap_share','FullDatabase_Prop','Inhibitory_Prop','InhibitoryStrict_Prop','Facilitating_Prop','Inhibitory_Richness','FullDatabase_Richness','Inh_over_Full','coverage_lost',
        'anyhit_Full_Prop','anyhit_Inh_Prop','perm_Inh_mean','perm_Inh_lo95','perm_Inh_hi95','Inh_above_perm95']
for level, col in [('host','set_host'),('hostcountry','set_hostcountry'),('country','set_country')]:
    parts=[]
    for name, g in S.groupby(col):
        safe = re.sub(r'[^A-Za-z0-9]+','_',name)
        if level=='host': mem = I.index[I.host==name[2:]]
        elif level=='hostcountry': h,c = name[3:].split('|'); mem = I.index[(I.host==h)&(I.country==c)]
        else: mem = I.index[I.country==name[2:]]
        X = Xm_all[g.index]; X = X[X.sum(1)>0]
        o, Hf = setmetrics(X, 1000, 'meta', safe); o['coverage_lost'] = cov_lost(X, HALL, Hf)
        fa, ob, nm, lo, hi = anyhit_perm(X, 1000, Em, mem)
        o['anyhit_Full_Prop']=fa; o['anyhit_Inh_Prop']=ob; o['perm_Inh_mean']=nm; o['perm_Inh_lo95']=lo; o['perm_Inh_hi95']=hi; o['Inh_above_perm95']=o.anyhit_Inh_Prop>o.perm_Inh_hi95
        parts.append(o[cols])
    Dm = Dm.join(pd.concat(parts).add_prefix(f'{level}__'))
Dm.index.name='SampleID'; Dm.to_csv('out/meta_per_sample_restricted.csv')
for level in ['host','hostcountry','country']:
    CMP += compare(Dm.rename(columns=lambda c: c), [level], 'meta', {level: Dm[f'set_{level}'].notna()})
C = pd.DataFrame(CMP); C.to_csv('out/restricted_vs_full_comparison.csv', index=False)
pd.set_option('display.width',250)
print(C[C.metric.isin(['FullDatabase_Prop','Inhibitory_Prop','Inh_over_Full'])].round(3).to_string())
