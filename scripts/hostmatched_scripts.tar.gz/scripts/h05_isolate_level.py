"""Host-matched track step 3b: isolate-level leave-study-out prediction of Func (Inhibitory vs not) from
(i) all other-study isolates, (ii) same host species, (iii) same host genus, (iv) same country.
Predictors: majority vote of >=99% V4 matches (vsearch iddef 1, terminal gaps counted -> full-coverage) and
bacterial-genus majority (SINTAX RDP genus of full-length isolate; inhibitory share of same-genus isolates in the reference set).
Kappa/AUC with study-cluster bootstrap (1,000) on common isolate panels."""
import pandas as pd, numpy as np
from sklearn.metrics import cohen_kappa_score, roc_auc_score
I = pd.read_csv('work/isolates_norm.csv', index_col=0); G = pd.read_csv('work/genus_assignments.csv', index_col=0)
I['bgenus'] = G.genus_full; T = I[I.tested].copy(); T['y'] = (T.Func=='Inhibitory').astype(int)
v4 = [l[1:].strip() for l in open('work/v4_tested.fasta') if l.startswith('>')]
E = pd.read_csv('uc/v4_allvall.tsv', sep='\t', header=None, names=['q','t','id1','qcov','tcov','ql','tl'])
E = E[(E.q!=E.t)&(E.id1>=99.0)]
for c in ['study','host','genus','country']: E['q_'+c]=E.q.map(T[c]); E['t_'+c]=E.t.map(T[c])
E['ty'] = E.t.map(T.y); E = E[E.q_study!=E.t_study]
SETS = {'all':None, 'same_host_species':'host', 'same_host_genus':'genus', 'same_country':'country'}
Q = pd.DataFrame(index=pd.Index(v4, name='FastaID')); Q['study']=T.study; Q['host']=T.host; Q['country']=T.country; Q['y']=T.y; Q['bgenus']=T.bgenus
for s, c in SETS.items():
    e = E if c is None else E[(E['q_'+c]==E['t_'+c])&E['q_'+c].notna()]
    a = e.groupby('q').agg(n=('ty','size'), f=('ty','mean'))
    Q[f'{s}__n_match'] = a.n.reindex(Q.index).fillna(0).astype(int); Q[f'{s}__match_score'] = a.f
    Q[f'{s}__match_pred'] = (a.f>0.5).astype(float).reindex(Q.index)
    # genus majority among other-study (restricted) tested isolates of the same bacterial genus (all tested isolates, not only V4)
    gs = []
    for i, r in Q.iterrows():
        if pd.isna(r.bgenus): gs.append(np.nan); continue
        m = (T.study!=r.study)&(T.bgenus==r.bgenus)
        if c is not None: m &= (T[c]==T.at[i,c]) if pd.notna(T.at[i,c]) else False
        gs.append(T.y[m].mean() if m.sum() else np.nan)
    Q[f'{s}__genus_score'] = gs; Q[f'{s}__genus_pred'] = (Q[f'{s}__genus_score']>0.5).astype(float).where(Q[f'{s}__genus_score'].notna())
Q.to_csv('out/isolate_level_predictions.csv')
rng = np.random.default_rng(7); studies = Q.study.unique()
def stats(d, col):
    k = d[col+'_pred'].notna(); d = d[k]
    if len(d)<5 or d.y.nunique()<2: return np.nan, np.nan, len(d)
    kap = cohen_kappa_score(d.y, d[col+'_pred']) if d[col+'_pred'].nunique()>1 else 0.0
    return kap, roc_auc_score(d.y, d[col+'_score']), len(d)
def boot(d, cols, B=1000):
    st = d.study.unique(); grp = {s: d.index[d.study==s] for s in st}; out=[]
    for _ in range(B):
        idx = np.concatenate([grp[s] for s in rng.choice(st, len(st))]); dd = d.loc[idx]
        out.append({c: stats(dd, c)[:2] for c in cols})
    return out
rows=[]
panels = {'A_same_host_match': Q[Q['same_host_species__n_match']>0],
          'B_match_in_all_four': Q[(Q[[f'{s}__n_match' for s in SETS]]>0).all(1)],
          'C_any_other_study_match': Q[Q['all__n_match']>0]}
for pn, d in panels.items():
    cols = [f'{s}__{m}' for s in SETS for m in ['match','genus']]
    bs = boot(d, cols)
    for c in cols:
        kap, auc, n = stats(d, c); kb = np.array([b[c][0] for b in bs], float); ab = np.array([b[c][1] for b in bs], float)
        base = c.split('__')[1]; kd = kb - np.array([b[f'all__{base}'][0] for b in bs], float)
        ad = ab - np.array([b[f'all__{base}'][1] for b in bs], float)
        rows.append(dict(panel=pn, n_panel=len(d), n_studies=d.study.nunique(), reference_set=c.split('__')[0], predictor=base, n_defined=n,
            prevalence=d.y[d[c+'_pred'].notna()].mean(), kappa=kap, kappa_lo=np.nanpercentile(kb,2.5), kappa_hi=np.nanpercentile(kb,97.5),
            auc=auc, auc_lo=np.nanpercentile(ab,2.5), auc_hi=np.nanpercentile(ab,97.5),
            dkappa_vs_all=kap-stats(d, f'all__{base}')[0], dkappa_lo=np.nanpercentile(kd,2.5), dkappa_hi=np.nanpercentile(kd,97.5),
            dauc_lo=np.nanpercentile(ad,2.5), dauc_hi=np.nanpercentile(ad,97.5)))
K = pd.DataFrame(rows); K.to_csv('out/isolate_level_kappa_auc.csv', index=False)
P = pd.DataFrame([dict(reference_set=s, n_tested=len(T), n_tested_with_V4=len(Q), n_predictable_match=int((Q[f'{s}__n_match']>0).sum()),
     pct_of_V4=100*(Q[f'{s}__n_match']>0).mean(), n_predictable_genus=int(Q[f'{s}__genus_pred'].notna().sum()),
     n_studies_predictable=Q.study[Q[f'{s}__n_match']>0].nunique(), n_hosts_predictable=Q.host[Q[f'{s}__n_match']>0].nunique()) for s in SETS])
P.to_csv('out/isolate_level_predictability.csv', index=False)
pd.set_option('display.width',250); print(P.round(1).to_string()); print(K.round(3).to_string())
