#!/bin/bash
# Exhaustive Full-db hits (id >= 0.99, iddef 2) for bullfrog and SERDP features; all-vs-all V4 isolate search (iddef 1 = terminal gaps count, id >= 0.99)
T=${T:-2}
for ds in bf serdp; do
vsearch --usearch_global q/$ds.fasta --id 0.99 --db db/FullDatabase_2025.1.fasta --strand both --qmask none --maxaccepts 0 --maxrejects 0 \
  --threads $T --minseqlength 1 --userout uc/${ds}_exh099.tsv --userfields query+target+id+alnlen+mism+gaps+ql+qilo+qihi --quiet; done
vsearch --usearch_global work/v4_tested.fasta --db work/v4_tested.fasta --id 0.99 --iddef 1 --strand plus --qmask none --maxaccepts 0 --maxrejects 0 \
  --threads $T --minseqlength 1 --userout uc/v4_allvall.tsv --userfields query+target+id1+qcov+tcov+ql+tl --quiet
echo DONE
