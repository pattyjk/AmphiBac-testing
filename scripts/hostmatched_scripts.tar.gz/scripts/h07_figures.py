"""Figures for the host-matched track (run in the kernel after apply_figure_style())."""
import pandas as pd, numpy as np, matplotlib.pyplot as plt
INH, NOE, FAC = '#2166AC', '#E08214', '#7B3294'
Db = pd.read_csv('out/bullfrog_per_sample_restricted.csv', index_col=0)
Ds = pd.read_csv('out/serdp_per_sample_restricted.csv', index_col=0)
Dm = pd.read_csv('out/meta_per_sample_restricted.csv', index_col=0)
APPL = {'serdp_LISP_species':['LISP_LA','LISP_TN'], 'serdp_genus':None, 'serdp_TN':['LISP_TN'], 'serdp_Panama':['LIPI_Panama']}
panels = [  # label, dataframe, prefix, sample mask
 ('Bullfrog: L. catesbeianus', Db, 'bf_species', None), ('Bullfrog: Lithobates+Rana', Db, 'bf_genus', None),
 ('Bullfrog: Massachusetts', Db, 'bf_MA', None), ('Bullfrog: US Northeast', Db, 'bf_NE', None),
 ('SERDP: L. sphenocephalus (LA, TN)', Ds, 'serdp_LISP_species', Ds.site.isin(APPL['serdp_LISP_species'])),
 ('SERDP: Lithobates+Rana (all sites)', Ds, 'serdp_genus', None),
 ('SERDP: Tennessee (TN)', Ds, 'serdp_TN', Ds.site.isin(['LISP_TN'])), ('SERDP: Panama (Panama)', Ds, 'serdp_Panama', Ds.site.isin(['LIPI_Panama'])),
 ('Meta: same host species', Dm, 'host', Dm.set_host.notna()), ('Meta: same host + country', Dm, 'hostcountry', Dm.set_hostcountry.notna()),
 ('Meta: same country', Dm, 'country', Dm.set_country.notna())]
# --- Figure 1: coverage lost and partial-overlap share
fig, ax = plt.subplots(figsize=(7.2, 4.2))
pos = np.arange(len(panels)); lab=[]
for i,(l,D,p,m) in enumerate(panels):
    d = D if m is None else D[m]; v = d[f'{p}__coverage_lost'].dropna()
    ax.boxplot([v], positions=[i-0.18], widths=0.3, showfliers=False, patch_artist=True, boxprops=dict(facecolor='#BBBBBB', edgecolor='k', lw=0.6), medianprops=dict(color='k'), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
    w = d[f'{p}__partial_overlap_share'].dropna()
    ax.boxplot([w], positions=[i+0.18], widths=0.3, showfliers=False, patch_artist=True, boxprops=dict(facecolor='white', edgecolor=FAC, lw=0.8), medianprops=dict(color=FAC), whiskerprops=dict(lw=0.6, color=FAC), capprops=dict(lw=0.6, color=FAC))
    lab.append(f'{l}\n(n={len(v)})')
ax.set_xticks(pos); ax.set_xticklabels(lab, rotation=55, ha='right')
ax.set_ylabel('Share of reads'); ax.set_ylim(-0.03, 1.05)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor='#BBBBBB', edgecolor='k', label='matched with full DB, unmatched with restricted DB'),
                   Patch(facecolor='white', edgecolor=FAC, label='restricted matches that are partial overlaps (terminal gaps ignored)')],
          loc='upper left', bbox_to_anchor=(0, 1.16), frameon=False, ncol=1)
ax.set_title('Restriction leaves most previously matched reads unmatched in 9 of 11 sets', loc='left', pad=34)
fig.tight_layout(); fig.savefig('fig/fig_hm_coverage_lost.png', dpi=300)
# --- Figure 2: restricted vs full Inhibitory proportion
fig, axs = plt.subplots(3, 4, figsize=(7.2, 6.0), sharex=True, sharey=True)
for a,(l,D,p,m) in zip(axs.flat, panels):
    d = D if m is None else D[m]; x, y = d['ALL__Inhibitory_Prop'], d[f'{p}__Inhibitory_Prop']
    a.scatter(x, y, s=4 if len(d)>200 else 9, alpha=0.35 if len(d)>200 else 0.7, color=INH, lw=0)
    a.plot([0,1],[0,1], color='grey', lw=0.6, ls='--')
    from scipy.stats import spearmanr
    rho = spearmanr(x, y)[0]
    a.text(0.03, 0.97, f'{l}\nn={len(d)}, rho={rho:.2f}', transform=a.transAxes, va='top', fontsize=6)
axs.flat[-1].axis('off')
for a in axs[-1]: a.set_xlabel('Full-DB Inhibitory prop.')
axs[-2][-1].tick_params(labelbottom=True); axs[-2][-1].set_xlabel('Full-DB Inhibitory prop.')
for a in axs[:,0]: a.set_ylabel('Restricted Inhibitory prop.')
for a in axs.flat: a.set_xlim(-0.03,1.03); a.set_ylim(-0.03,1.03)
fig.suptitle('Restricted-database Inhibitory proportion falls well below the full-DB value (dashed: y = x)', x=0.01, ha='left', fontsize=8)
fig.tight_layout(); fig.savefig('fig/fig_hm_restricted_vs_full.png', dpi=300)
# --- Figure 3: isolate-level kappa by reference set
K = pd.read_csv('out/isolate_level_kappa_auc.csv'); P = pd.read_csv('out/isolate_level_predictability.csv').set_index('reference_set')
k = K[K.panel=='A_same_host_match']; order = ['all','same_host_genus','same_host_species','same_country']
names = {'all':'All other-study\nisolates','same_host_species':'Same host\nspecies','same_host_genus':'Same host\ngenus','same_country':'Same\ncountry'}
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw=dict(width_ratios=[1.5,1]))
for j,(pred,col,mk) in enumerate([('match',INH,'o'),('genus',NOE,'s')]):
    kk = k[k.predictor==pred].set_index('reference_set').loc[order]; xs = np.arange(4)+(-0.12 if j==0 else 0.12)
    a1.errorbar(xs, kk.kappa, yerr=[kk.kappa-kk.kappa_lo, kk.kappa_hi-kk.kappa], fmt=mk, color=col, ms=5, capsize=2, lw=0.8,
                label='majority of >=99% V4 matches' if pred=='match' else 'bacterial-genus majority')
a1.axhline(0, color='grey', lw=0.6); a1.set_xticks(range(4)); a1.set_xticklabels([names[o] for o in order])
a1.set_ylabel("Cohen's kappa (Inhibitory vs not)"); a1.legend(frameon=False, loc='upper right')
a1.set_title(f'Same isolates (n={int(k.n_panel.iloc[0])}, {int(k.n_studies.iloc[0])} studies): restriction lowers agreement', loc='left')
a1.margins(x=0.08)
v = P.loc[order,'n_predictable_match']; a2.bar(range(4), v, color=INH)
for i,x in enumerate(v): a2.text(i, x+60, f'{int(x):,}', ha='center', fontsize=6)
a2.set_xticks(range(4)); a2.set_xticklabels([names[o] for o in order]); a2.set_ylabel('Isolates with >=1 other-study match')
a2.set_title(f'Predictable isolates (of {int(P.n_tested_with_V4.iloc[0]):,} with V4)', loc='left'); a2.set_ylim(0, v.max()*1.12)
fig.tight_layout(); fig.savefig('fig/fig_hm_isolate_kappa.png', dpi=300)
print('figs done')
