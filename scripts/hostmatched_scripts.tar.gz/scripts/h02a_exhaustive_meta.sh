#!/bin/bash
# Exhaustive (maxaccepts 0 / maxrejects 0) search of all meta sOTUs vs FullDatabase at id >= 0.99 (iddef 2, as the pipeline)
vsearch --usearch_global q/meta_ALL.fasta --id 0.99 --db db/FullDatabase_2025.1.fasta --strand both --qmask none --maxaccepts 0 --maxrejects 0 \
  --threads 3 --minseqlength 1 --userout uc/meta_exh099.tsv --userfields query+target+id+alnlen+mism+gaps+ql+qilo+qihi --quiet
echo EXH_DONE
