"""Host-matched track step 1: build host- and location-restricted AmphiBac 2025.1 subsets.
Full subset keeps tested + untested isolates (as FullDatabase does); Inhibitory/InhibitoryStrict/Facilitating
membership taken from the released FASTAs (identical to Func labels; checked). Writes db_sub/<set>__<mode>.fasta,
meta sample->set assignment, query FASTAs for meta sets, and out/subset_inventory.csv."""
import pandas as pd, numpy as np, re, os, scipy.sparse as sp
os.makedirs('db_sub', exist_ok=True); os.makedirs('q', exist_ok=True)
Md = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', dtype=str, encoding='latin-1'); Md.columns=[c.strip() for c in Md.columns]
A = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
I = Md.set_index('FastaID')[['Host.Species','Country','State','Location.Name','Reference','Researchers','Study.Tab']].copy()
I['Func'] = A.Func
GFIX = {'Gephryomantis':'Gephyromantis','Ischconemia':'Ischnocnema','Hypsiboas':'Boana',   # used before
        'Paradoxohyla':'Paradoxophyla','Anodontohyla':'Anodonthyla','Plethodonthyla':'Plethodontohyla','Scaphiophyrne':'Scaphiophryne'}  # DB spelling fixes (new here)
SFIX = {'dendrosophus ebraccatus':'dendropsophus ebraccatus','centrolene prosoblepon':'espadarana prosoblepon','hylomantis lemur':'agalychnis lemur'}
def nh(h):
    if pd.isna(h): return np.nan
    p = [x for x in re.split(r'[.\s_]+', h.strip()) if x]
    g = GFIX.get(p[0].capitalize(), p[0].capitalize()).lower()
    s = ' '.join([g]+p[1:2]).lower(); return SFIX.get(s, s)
I['host'] = I['Host.Species'].map(nh); I['genus'] = I.host.str.split().str[0]
I['country'] = I.Country.str.replace('.',' ',regex=False).str.strip().str.lower()
I['state'] = I.State.replace({'VA':'Virginia','Sao paulo':'Sao Paulo'})
unp = I.Reference.str.lower().str.contains('unpub', na=False)
I['study'] = np.where(unp, 'unpub|'+I.Researchers.fillna('NA')+'|'+I['Study.Tab'].fillna('NA'), I.Reference)
for s in ['Inhibitory','InhibitoryStrict','Facilitating']: I['in_'+s] = A['in_'+s]
assert (I.in_Inhibitory == (I.Func=='Inhibitory')).all() and (I.in_Facilitating == (I.Func=='Facilitating')).all()
I['tested'] = I.Func.isin(['Inhibitory','NoEffect','Facilitating'])
I.to_csv('work/isolates_norm.csv')
seq = {}; k=None
for l in open('db/FullDatabase_2025.1.fasta'):
    l=l.rstrip('\n')
    if l.startswith('>'): k=l[1:].split()[0]; seq[k]=[]
    else: seq[k].append(l)
seq = {k:''.join(v) for k,v in seq.items()}; assert set(seq)==set(I.index)
MODES = {'FullDatabase':lambda d:d, 'Inhibitory':lambda d:d[d.in_Inhibitory], 'InhibitoryStrict':lambda d:d[d.in_InhibitoryStrict], 'Facilitating':lambda d:d[d.in_Facilitating]}
def write(name, d):
    for m,f in MODES.items():
        with open(f'db_sub/{name}__{m}.fasta','w') as o:
            for i in f(d).index: o.write(f'>{i}\n{seq[i]}\n')
def inv(name, d, dataset, kind, note=''):
    t = d[d.tested]
    return dict(dataset=dataset, set=name, kind=kind, n_full=len(d), n_tested=len(t), n_inhibitory=int((d.Func=='Inhibitory').sum()),
        n_inhibitory_strict=int(d.in_InhibitoryStrict.sum()), n_noeffect=int((d.Func=='NoEffect').sum()), n_facilitating=int((d.Func=='Facilitating').sum()),
        n_nottested=int((d.Func=='NotTested').sum()), n_possible_contam=int((d.Func=='PossibleContamination').sum()),
        frac_inhibitory_of_tested=(t.Func=='Inhibitory').mean() if len(t) else np.nan, n_studies_full=d.study.nunique(), n_studies_tested=t.study.nunique(),
        hosts=';'.join(f'{h} ({n})' for h,n in d.host.value_counts().head(6).items()), locations=';'.join(f'{c}/{s} ({n})' for (c,s),n in d.groupby(['country','state'],dropna=False).size().sort_values(ascending=False).head(6).items()), note=note)
rows=[]
NE = ['MA','New York','Vermont','New Hampshire','Maine','Connecticut','Rhode Island','New Jersey','Pennsylvania']
LR = I.genus.isin(['lithobates','rana'])
named = {  # name: (dataset, kind, mask, note)
 'ALL':('all','unrestricted', I.host.notna()|I.host.isna(), 'released FullDatabase'),
 'bf_species':('bullfrog','host species', I.host=='lithobates catesbeianus', 'L. catesbeianus, any location (Virginia, Colorado)'),
 'bf_MA':('bullfrog','location (state)', I.state=='MA', "State 'MA' (Massachusetts), any host"),
 'bf_speciesMA':('bullfrog','species+location', (I.host=='lithobates catesbeianus')&(I.state=='MA'), 'empty: no Massachusetts bullfrog isolates'),
 'bf_genus':('bullfrog','genus fallback', LR, 'Lithobates + Rana, any location'),
 'bf_NE':('bullfrog','region fallback', I.state.isin(NE)&(I.country=='usa'), 'US Northeast states; present: '+', '.join(sorted(set(I.state[I.state.isin(NE)])))),
 'serdp_LISP_species':('serdp','host species', I.host=='lithobates sphenocephalus', 'R. sphenocephala = L. sphenocephalus (LISP_LA, LISP_TN)'),
 'serdp_genus':('serdp','genus fallback', LR, 'Lithobates + Rana (LIPI_PA, LIPI_VT, LIBL_NM, LIPI_Panama; also run for all sites)'),
 'serdp_TN':('serdp','location (state)', I.state=='Tennessee', 'Tennessee (LISP_TN)'),
 'serdp_Panama':('serdp','location (country)', I.country=='panama', 'Panama (LIPI_Panama)'),
 'serdp_TN_species':('serdp','species+location', (I.host=='lithobates sphenocephalus')&(I.state=='Tennessee'), 'L. sphenocephalus from Tennessee (LISP_TN)'),
 'serdp_PA':('serdp','location (state)', I.state=='Pennsylvania', 'empty'), 'serdp_VT':('serdp','location (state)', I.state=='Vermont', 'empty'),
 'serdp_NM':('serdp','location (state)', I.state=='New Mexico', 'empty'), 'serdp_LA':('serdp','location (state)', I.state=='Louisiana', 'empty'),
 'serdp_pipiens_species':('serdp','host species', I.host.isin(['lithobates pipiens','rana pipiens','lithobates blairi','rana blairi']), 'empty: no R./L. pipiens or blairi isolates'),
}
for n,(ds,kind,m,note) in named.items():
    d = I[m]; rows.append(inv(n,d,ds,kind,note))
    if len(d) and n!='ALL': write(n,d)
# ---- meta: per-sample host / host+country / country sets
mm = pd.read_csv('meta_map.txt', sep='\t', dtype=str).set_index('#SampleID')
samp = pd.read_csv('work/meta_samples.csv', header=None)[0]
S = pd.DataFrame(index=samp); S['host'] = mm.reindex(samp).host_scientific_name.str.strip().map(nh); S['country']=mm.reindex(samp).country.str.strip().str.lower()
S['study'] = mm.reindex(samp).doi
S.loc[S.host.str.endswith(' sp', na=False),'host'] = np.nan   # genus-only hosts are not species matches
S['set_host'] = np.where(S.host.isin(set(I.host.dropna())), 'H:'+S.host.fillna(''), None)
hc = set(zip(I.host, I.country))
S['set_hostcountry'] = [f'HC:{h}|{c}' if (h,c) in hc else None for h,c in zip(S.host,S.country)]
S['set_country'] = np.where(S.country.isin(set(I.country.dropna())), 'C:'+S.country.fillna(''), None)
S.to_csv('work/meta_sample_sets.csv')
R = sp.load_npz('work/meta_rare_s1.npz').tocsc(); F = pd.read_csv('work/meta_features.csv')
for col in ['set_host','set_hostcountry','set_country']:
    for name, g in S.groupby(col):
        if col=='set_host': d = I[I.host==name[2:]]
        elif col=='set_hostcountry': h,c = name[3:].split('|'); d = I[(I.host==h)&(I.country==c)]
        else: d = I[I.country==name[2:]]
        safe = re.sub(r'[^A-Za-z0-9]+','_',name); r = inv(name,d,'meta',col.replace('set_',''),f'{len(g)} samples'); r['n_samples']=len(g); r['file']=safe; rows.append(r)
        write('meta_'+safe, d)
        j = S.index.get_indexer(g.index); present = np.asarray(R[:, j].sum(1)).ravel() > 0
        with open(f'q/meta_{safe}.fasta','w') as o:
            for fid, s in zip(F.fid[present], F.seq[present]): o.write(f'>{fid}\n{s}\n')
V = pd.DataFrame(rows); V.to_csv('out/subset_inventory.csv', index=False)
print(V[V.dataset!='meta'][['set','n_full','n_tested','n_inhibitory','n_inhibitory_strict','n_facilitating','n_studies_tested']].to_string())
for c in ['set_host','set_hostcountry','set_country']: print(c, 'samples covered', S[c].notna().sum(), 'of', len(S), 'sets', S[c].nunique())
