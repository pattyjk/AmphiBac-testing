#!/bin/bash
# Exact q2-vsearch closed-reference call (cluster_features_closed_reference, id 0.99, strand both) for every restricted subset.
T=2
run () { # query db out
  vsearch --usearch_global $1 --id 0.99 --db $2 --uc $3.uc --strand both --qmask none --notmatched /dev/null --threads $T --minseqlength 1 --fasta_width 0 --quiet; }
M="FullDatabase Inhibitory InhibitoryStrict Facilitating"
for m in $M; do run q/bf.fasta db/${m}_2025.1.fasta uc/bf__ALL__$m; run q/serdp.fasta db/${m}_2025.1.fasta uc/serdp__ALL__$m; done
for s in bf_species bf_MA bf_genus bf_NE; do for m in $M; do run q/bf.fasta db_sub/${s}__$m.fasta uc/bf__${s}__$m; done; done
for s in serdp_LISP_species serdp_genus serdp_TN serdp_Panama serdp_TN_species; do for m in $M; do run q/serdp.fasta db_sub/${s}__$m.fasta uc/serdp__${s}__$m; done; done
echo BF_SERDP_DONE
for m in $M; do run q/meta_ALL.fasta db/${m}_2025.1.fasta uc/meta__ALL__$m; done
for f in q/meta_*.fasta; do b=$(basename $f .fasta); [ "$b" = meta_ALL ] && continue
  for m in $M; do [ -s db_sub/${b}__$m.fasta ] || continue; run $f db_sub/${b}__$m.fasta uc/meta__${b#meta_}__$m; done; done
echo ALL_DONE
