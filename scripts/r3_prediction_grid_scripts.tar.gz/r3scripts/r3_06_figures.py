"""Round 3 figures. Run inside the python kernel after figure-style apply_figure_style(sizes=(8,7,6)) (exec(open(...).read())).
Fig A: kappa vs window, leave-study-out, 99%, panels all-isolates / fixed 1,397 panel, rules R1-R4 + genus.
Fig B: mechanics per window (99%, self exclusion unless stated)."""
import pandas as pd, numpy as np, matplotlib.pyplot as plt
ORDER=['V2V3_410','V1V4_700','V2V4_600','V2V8_1100','V3V4_500','V3V4_429','V4_254','V4V5_374','V5V6_281','V6V8_431']
COORD={'V4_254':(533,786),'V3V4_429':(357,785),'V3V4_500':(296,795),'V2V3_410':(101,510),'V2V4_600':(201,800),
       'V1V4_700':(121,820),'V4V5_374':(533,906),'V5V6_281':(780,1060),'V6V8_431':(960,1390),'V2V8_1100':(236,1335)}
def xlab(w):
    r,L=w.split('_'); r=r.replace('V3V4','V3–V4').replace('V2V3','V2–V3').replace('V2V4','V2–V4').replace('V1V4','V1–V4').replace('V2V8','V2–V8').replace('V4V5','V4–V5').replace('V5V6','V5–V6').replace('V6V8','V6–V8')
    return f'{r}\n{L} bp\n{COORD[w][0]}–{COORD[w][1]}'
RU=[('R1_tophit','R1 default top hit','#222222','o','-'),('R2_Inhibitory','R2 any hit, Inhibitory db','#56B4E9','s','-'),
    ('R3_InhibitoryStrict','R3 any hit, InhibitoryStrict db','#0072B2','D','-'),('R4_majority_fullcov','R4 majority, full-coverage hits','#CC79A7','^','-'),
    ('G_genus_majority','Genus-majority baseline','#8C8C8C','v','--')]
S=pd.read_csv('out/r3_summary_tidy.csv')
def sel(rule,panel,excl='study',t=0.99):
    d=S[(S.rule==rule)&(S.panel==panel)&(S.exclusion==excl)]
    d=d[d.threshold.isna()] if rule.startswith('G_') else d[np.isclose(d.threshold,t)]
    return d.set_index('window').reindex(ORDER)
fig,axs=plt.subplots(2,1,figsize=(7.2,6.4),sharex=True)
for ax,panel,title in zip(axs,['all','panel10'],['All isolates with each window (n differs by window)','Fixed panel of 1,397 isolates present in all ten windows (17 studies)']):
    x=np.arange(len(ORDER)); off=np.linspace(-0.28,0.28,len(RU))
    for (r,lab,c,m,ls),o in zip(RU,off):
        d=sel(r,panel)
        ax.errorbar(x+o,d.kappa,yerr=[d.kappa-d.kappa_ci_lo,d.kappa_ci_hi-d.kappa],fmt=m,color=c,ms=4,lw=0.8,capsize=0,label=lab,mfc=c if ls=='-' else 'white')
    ax.axhline(0,color='0.6',lw=0.6)
    ax.set_title(title,loc='left'); ax.set_ylabel("Cohen's kappa (higher = better)")
    if panel=='all':
        n=sel('R1_tophit','all').n_isolates.astype(int)
        for xi,ni in zip(x,n): ax.text(xi,-0.17,f'n={ni:,}',ha='center',va='bottom',fontsize=6,color='0.35')
    ax.set_ylim(-0.18,0.72)
axs[1].set_xticks(x); axs[1].set_xticklabels([xlab(w) for w in ORDER])
axs[0].legend(ncol=3,frameon=False,loc='upper left',fontsize=7,handletextpad=0.3,columnspacing=1.0)
fig.text(0.01,0.005,'Leave-study-out, 99% identity, binary Inhibitory vs not, no call = non-inhibitory; bars = study-cluster bootstrap 95% CI (B=500). x labels: region, length, E. coli coordinates.',fontsize=6,color='0.3')
fig.tight_layout(rect=(0,0.02,1,1)); fig.savefig('out/r3_fig_kappa_by_window.png',dpi=300)
# ---------------- mechanics
cov=pd.read_csv('out/r3_mech_partial_coverage.csv'); tie=pd.read_csv('out/r3_mech_ties.csv'); sh=pd.read_csv('out/r3_mech_shuffles.csv')
PC={'all':('#333333','All isolates'),'panel10':('#B2182B','Fixed 1,397 panel')}
fig2,ax=plt.subplots(2,2,figsize=(7.2,6.0),sharex=True); ax=ax.ravel(); x=np.arange(len(ORDER))
def line(a,df,col,panel,**kw):
    d=df[df.panel==panel].set_index('window').reindex(ORDER); c,l=PC[panel]
    a.plot(x,d[col],marker='o',ms=3.5,color=c,lw=1,label=l,**kw)
c99=cov[np.isclose(cov.threshold,0.99)&(cov.exclusion=='self')]
for p in PC: line(ax[0],c99,'pct_R1_tophit_partial',p)
for p in PC: line(ax[0],c99,'pct_default_miss_with_fullcov_exh_hit',p,ls=':')
ax[0].set_title('R1 top hits to refs not spanning the fragment (solid);\nfull-coverage hit present but default call missed (dotted)',loc='left'); ax[0].set_ylabel('% of queries / hits')
from matplotlib.lines import Line2D
ax[0].legend(handles=[Line2D([],[],color=PC[p][0],marker='o',ms=3.5,lw=1,label=PC[p][1]) for p in PC],frameon=False,fontsize=7,loc='upper left')
# kappa change with full coverage (study, 99%, both panels)
for p,mk in [('all','o'),('panel10','s')]:
    for r,c in [('R1_tophit','#222222'),('R2_Inhibitory','#56B4E9')]:
        a_=sel(r,p).kappa; b_=sel(r+'_fullcov',p).kappa
        ax[1].plot(x,b_-a_,marker=mk,ms=3.5,color=c,lw=1,ls='-' if p=='all' else '--',label=f"{r.split('_')[0]}, {PC[p][1].lower()}")
ax[1].axhline(0,color='0.6',lw=0.6); ax[1].set_title('Requiring full coverage helps R2 most at V2–V8, V4–V5;\nR1 barely changes (leave-study-out)',loc='left'); ax[1].set_ylabel('Δ kappa (full-coverage − default)')
ax[1].legend(frameon=False,fontsize=6,ncol=1,loc='upper left')
t99=tie[np.isclose(tie.threshold,0.99)&(tie.exclusion=='self')]
for p in PC: line(ax[2],t99,'pct_ties_at_max_identity',p)
for p in PC: line(ax[2],t99,'pct_tied_top_discordant_inhibitory',p,ls=':')
ax[2].set_title('Ties at max identity (solid); tied refs disagree\non Inhibitory (dotted)',loc='left'); ax[2].set_ylabel('% of matched queries')
for p in PC: line(ax[3],sh,'pct_inhibitory_call_changes_any_shuffle',p)
for p in PC: line(ax[3],sh,'pct_tophit_changes_any_shuffle',p,ls=':')
ax[3].set_title('Reference-order shuffles (5): inhibitory call\nchanged (solid); top hit changed (dotted)',loc='left'); ax[3].set_ylabel('% of queries')
for a in ax[2:]: a.set_xticks(x); a.set_xticklabels([xlab(w).split('\n')[0]+' '+xlab(w).split('\n')[1].replace(' bp','') for w in ORDER],rotation=45,ha='right',rotation_mode='anchor')
for a,l in zip(ax,'abcd'): a.text(-0.14,1.13,l,transform=a.transAxes,fontweight='bold',fontsize=10); a.margins(y=0.08)
fig2.text(0.01,0.005,'x: region and fragment length (bp). 99% identity, FullDatabase, leave-self-out q2 default call (maxaccepts 1, maxrejects 32) unless stated; ties/coverage from exhaustive search.',fontsize=6,color='0.3')
fig2.tight_layout(rect=(0,0.02,1,1)); fig2.savefig('out/r3_fig_mechanics.png',dpi=300)
