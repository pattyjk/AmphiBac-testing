"""Round 3 step 2: mechanics per window.
(a) threshold -> max mismatches: theoretical (gapless, query fully aligned, vsearch test 100*(L-m)/L >= 100*t in
    double precision) at the window's modal fragment length and across its length range; verified against every
    full-coverage gapless exhaustive hit (qualifies iff mism <= theoretical(ql)).
(b) partial-coverage default top hits (R1, FullDatabase): % of default hits whose alignment does not span the
    whole fragment (self and study exclusion, each threshold).
(c) ties at max identity: % of matched queries (exhaustive, >= t) with >1 reference at the max identity, and % whose
    tied top references disagree on Inhibitory vs not.
(d) reference-order shuffles: FullDatabase record order permuted (seeds 1-5), q2 call + --self at 99%; % of queries
    whose R1 inhibitory call (and top-hit identity) differs from the original order in >=1 of 5 shuffles."""
import pandas as pd, numpy as np, glob
TH=[0.97,0.98,0.99,0.995,1.0]
WIN=['V4_254','V3V4_429','V3V4_500','V2V3_410','V2V4_600','V1V4_700','V4V5_374','V5V6_281','V6V8_431','V2V8_1100']
a=pd.read_csv('db/audit_per_sequence.csv',index_col=0)
idx=pd.read_csv('frags/fragment_index.csv')
cols='query target id mism gaps alnlen ids ql tl qilo qihi tilo tihi qstrand'.split()
def maxm(L,t): return max(m for m in range(L+1) if 100.0*(L-m)/L>=100.0*t)
def read_uc(p):
    u=pd.read_csv(p,sep='\t',header=None,usecols=[0,8,9],names=['t','q','h'],dtype=str); u['h']=u.h.where(u.t=='H'); return u.set_index('q').h
mt=[]; cov=[]; tie=[]; sh=[]
import os
for w in WIN:
    if not os.path.exists(f'pred/pred_{w}.csv.gz'): print('skip',w); continue
    L=idx[idx.window==w].frag_len; Lm=int(L.mode().iloc[0])
    e=pd.read_csv(f'exh/exh_{w}.tsv',sep='\t',names=cols,usecols=['query','target','mism','gaps','alnlen','ids','ql','qilo','qihi'])
    e['idx']=100.0*e.ids/e.alnlen
    e['fullcov']=(np.minimum(e.qilo,e.qihi)==1)&(np.maximum(e.qilo,e.qihi)==e.ql)
    e=e.sort_values(['idx','fullcov'],ascending=False).drop_duplicates(['query','target'])
    fg=e[e.fullcov&(e.gaps==0)&(e.alnlen==e.ql)].copy()
    for t in TH:
        lut={int(l):maxm(int(l),t) for l in fg.ql.unique()}; thr=fg.ql.map(lut)
        qual=fg.idx>=100.0*t
        allq=e[e.idx>=100.0*t]
        mt.append(dict(window=w,modal_len=Lm,len_min=int(L.min()),len_max=int(L.max()),threshold=t,
            theoretical_max_mismatches_modal=maxm(Lm,t),theoretical_max_mismatches_range=f'{maxm(int(L.min()),t)}-{maxm(int(L.max()),t)}',
            n_fullcov_gapless_hits_checked=len(fg),n_violations=int((qual!=(fg.mism<=thr)).sum()),
            empirical_max_mismatches_qualifying_modal=int(fg[qual&(fg.ql==Lm)].mism.max()) if (qual&(fg.ql==Lm)).any() else np.nan,
            empirical_max_mism_plus_gaps_any_qualifying=int((allq.mism+allq.gaps).max()) if len(allq) else np.nan,
            pct_qualifying_hits_partial_query=100*(~allq.fullcov).mean(),
            min_aligned_cols_qualifying=int(allq.alnlen.min()) if len(allq) else np.nan))
    P=pd.read_csv(f'pred/pred_{w}.csv.gz',usecols=['FastaID','excl','t','panel_all10','R1_hit','R1_hit_fullcov','R2_hit','R2_hit_fullcov','n_qual','n_top','top_discordant','R1_bin','n_qual_fc'],low_memory=False)
    for panel in ['all','panel10']:
        D0=P if panel=='all' else P[P.panel_all10]
        for (excl,t),D in D0.groupby(['excl','t']):
            h=D.R1_hit.notna(); h2=D.R2_hit.notna(); m=D.n_qual>0
            cov.append(dict(window=w,panel=panel,exclusion=excl,threshold=t,n_queries=len(D),n_R1_hits=int(h.sum()),
                pct_R1_tophit_partial=100*(D.R1_hit_fullcov[h]!=True).mean(),
                pct_R1_inhibitory_calls_from_partial=100*((D.R1_hit_fullcov!=True)&D.R1_bin&h).sum()/max(1,(D.R1_bin&h).sum()),
                pct_default_miss_with_exh_hit=100*(m&~h).sum()/max(1,m.sum()),
                pct_default_miss_with_fullcov_exh_hit=100*((D.n_qual_fc>0)&~h).sum()/max(1,(D.n_qual_fc>0).sum()),
                n_R2_hits=int(h2.sum()),pct_R2_hit_partial=100*(D.R2_hit_fullcov[h2]!=True).mean()))
            tie.append(dict(window=w,panel=panel,exclusion=excl,threshold=t,n_matched=int(m.sum()),
                pct_ties_at_max_identity=100*(D.n_top[m]>1).mean(),pct_tied_top_discordant_inhibitory=100*D.top_discordant[m].mean(),
                median_n_refs_at_max=float(D.n_top[m].median())))
    base=read_uc(f'dflt/self_{w}_Full_0.99.uc'); fb=a.Func.reindex(base).eq('Inhibitory').values
    S=pd.DataFrame({'h0':base,'inh0':fb},index=base.index)
    for s in range(1,6):
        u=read_uc(f'shuf/self_{w}_shuf{s}_0.99.uc').reindex(S.index); S[f'h{s}']=u.values; S[f'inh{s}']=a.Func.reindex(u).eq('Inhibitory').values
    pan=set(idx[(idx.window==w)&idx.panel_all10].FastaID)
    for panel in ['all','panel10']:
        SS=S if panel=='all' else S[S.index.isin(pan)]
        mm=SS.h0.notna()
        hc=pd.concat([(SS[f'h{s}']!=SS.h0)&mm for s in range(1,6)],axis=1)
        ic=pd.concat([SS[f'inh{s}']!=SS.inh0 for s in range(1,6)],axis=1)
        sh.append(dict(window=w,panel=panel,n_queries=len(SS),n_matched=int(mm.sum()),
            pct_tophit_changes_any_shuffle=100*hc.any(axis=1)[mm].mean(),
            pct_inhibitory_call_changes_any_shuffle=100*ic.any(axis=1).mean(),
            pct_inhibitory_call_changes_mean_per_shuffle=100*ic.mean().mean(),
            n_isolates_inhibitory_call_changed=int(ic.any(axis=1).sum()),
            pct_inhibitory_calls_unstable=100*(ic.any(axis=1)&(SS[[f'inh{s}' for s in range(6)]].any(axis=1))).sum()/max(1,SS[[f'inh{s}' for s in range(6)]].any(axis=1).sum())))
    print(w,'mechanics done',flush=True)
pd.DataFrame(mt).to_csv('out/r3_mech_mismatch_table.csv',index=False)
pd.DataFrame(cov).to_csv('out/r3_mech_partial_coverage.csv',index=False)
pd.DataFrame(tie).to_csv('out/r3_mech_ties.csv',index=False)
pd.DataFrame(sh).to_csv('out/r3_mech_shuffles.csv',index=False)
