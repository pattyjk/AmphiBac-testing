"""Round 3 step 1c: per-query predictions for every window x exclusion x threshold (definitions as round 1 lt_03,
plus full-coverage variants requested in round 3).
Identity = 100*ids/alnlen (vsearch iddef 2, terminal gaps excluded); qualify iff >= 100*t.
Full query coverage: alignment spans query positions 1..ql (qilo==1 and qihi==ql, terminal gaps excluded).
R1      Func of the q2-default top hit (FullDatabase); Inhibitory call iff top-hit Func == Inhibitory.
R1_fc   R1, but the call is dropped (-> no call) when the default top hit does not cover the whole fragment.
R2/R3   matched the Inhibitory / InhibitoryStrict db in the default call.  R2_fc/R3_fc: that hit must cover the fragment.
R2x/R3x any qualifying ref (exhaustive) in Inhibitory / Strict subset; _fc: any qualifying full-coverage ref.
R4      majority vote over all qualifying FULL-COVERAGE refs with a tested Func (Inhibitory iff n_inh > n_noeff+n_fac).
R4_anycov  round-1 R4 definition (no coverage requirement).
Leave-study-out for exhaustive-derived rules = drop same-study targets; default-call rules use per-study dbs."""
import sys, pandas as pd, numpy as np
TH=[0.97,0.98,0.99,0.995,1.0]; CL=['Inhibitory','NoEffect','Facilitating']
WIN = sys.argv[1:] or ['V4_254','V3V4_429','V3V4_500','V2V3_410','V2V4_600','V1V4_700','V4V5_374','V5V6_281','V6V8_431','V2V8_1100']
a=pd.read_csv('db/audit_per_sequence.csv',index_col=0); a['Reference']=a.Reference.fillna('NA')
sid={s:i for i,s in pd.read_csv('studydb/study_index.csv',index_col=0).Reference.items()}
inh=set(a.index[a.in_Inhibitory]); strict=set(a.index[a.in_InhibitoryStrict])
idx=pd.read_csv('frags/fragment_index.csv')
cols='query target id mism gaps alnlen ids ql tl qilo qihi tilo tihi qstrand'.split()
def read_uc(p, split=False):
    u=pd.read_csv(p,sep='\t',header=None,usecols=[0,8,9],names=['t','q','h'],dtype=str)
    if split: u[['q','w']]=u.q.str.split('|',expand=True)
    u['h']=u.h.where(u.t=='H'); return u
for w in WIN:
    q=idx[idx.window==w].set_index('FastaID')
    q=q.join(a[['Func','Reference','score']])
    e=pd.read_csv(f'exh/exh_{w}.tsv',sep='\t',names=cols)
    e['idx']=100.0*e.ids/e.alnlen
    lo=np.minimum(e.qilo,e.qihi); hi=np.maximum(e.qilo,e.qihi)
    e['fullcov']=(lo==1)&(hi==e.ql)
    e=e.sort_values(['idx','fullcov'],ascending=False).drop_duplicates(['query','target'])  # strand duplicates
    e['tFunc']=a.Func.reindex(e.target).values
    e['same']=a.Reference.reindex(e.target).values==a.Reference.reindex(e['query']).values
    out=[]; checks=[]
    for excl in ['self','study']:
        E=e if excl=='self' else e[~e.same]
        EE=E.set_index(['query','target'])[['idx','fullcov','mism','gaps','alnlen']]
        U={}
        for t in TH:
            Q=E[E.idx>=100.0*t]; Qf=Q[Q.fullcov]
            d=pd.DataFrame(index=q.index)
            d['n_qual']=Q.groupby('query').size().reindex(d.index).fillna(0).astype(int)
            d['n_qual_fc']=Qf.groupby('query').size().reindex(d.index).fillna(0).astype(int)
            for nm,QQ in [('R4',Qf),('R4_anycov',Q)]:
                vc=QQ[QQ.tFunc.isin(CL)].groupby(['query','tFunc']).size().unstack(fill_value=0).reindex(columns=CL,fill_value=0).reindex(d.index).fillna(0)
                d[nm+'_has']=vc.sum(1)>0; d[nm+'_bin']=d[nm+'_has']&(vc.Inhibitory>(vc.NoEffect+vc.Facilitating))
            for nm,S in [('R2x',inh),('R3x',strict)]:
                d[nm]=d.index.isin(Q.loc[Q.target.isin(S),'query']); d[nm+'_fc']=d.index.isin(Qf.loc[Qf.target.isin(S),'query'])
            # ties at max identity (any coverage, labelled or not)
            mx=Q.groupby('query').idx.transform('max'); top=Q[Q.idx==mx]
            d['n_top']=top.groupby('query').size().reindex(d.index).fillna(0).astype(int)
            tt=top.assign(inhb=top.tFunc.eq('Inhibitory')).groupby('query').inhb.agg(['min','max'])
            d['top_discordant']=(tt['min']!=tt['max']).reindex(d.index).fillna(False)
            # default (q2) runs
            for dn in ['Full','Inhibitory','InhibitoryStrict']:
                if excl=='self': U[dn]=read_uc(f'dflt/self_{w}_{dn}_{t}.uc').set_index('q').h
                else:
                    parts=[]
                    for s in q.Reference.unique():
                        u=read_uc(f'dflt/study{sid[s]}_{dn}_{t}.uc',split=True); parts.append(u[u.w==w].set_index('q').h)
                    U[dn]=pd.concat(parts)
            for dn,nm in [('Full','R1'),('Inhibitory','R2'),('InhibitoryStrict','R3')]:
                h=U[dn].reindex(d.index); d[nm+'_hit']=h.values
                key=pd.MultiIndex.from_arrays([d.index,h.fillna('').values]); inf=EE.reindex(key)
                d[nm+'_hit_idx']=inf.idx.values; d[nm+'_hit_fullcov']=inf.fullcov.values
                hit=h.notna().values
                checks.append(dict(window=w,excl=excl,t=t,db=dn,n_default_hits=int(hit.sum()),
                    hit_not_in_exh=int(inf.idx[hit].isna().sum()),hit_below_t=int((inf.idx[hit]<100*t).sum()),
                    exh_match_default_miss=int(((d.n_qual>0)&~hit).sum()) if dn=='Full' else np.nan))
            d['R1_has']=d.R1_hit.notna(); d['R1_bin']=a.Func.reindex(d.R1_hit).eq('Inhibitory').values
            d['R1_fc_has']=d.R1_has&(d.R1_hit_fullcov==True); d['R1_fc_bin']=d.R1_bin&d.R1_fc_has
            for nm in ['R2','R3']:
                d[nm]=d[nm+'_hit'].notna(); d[nm+'_fc']=d[nm]&(d[nm+'_hit_fullcov']==True)
            d=d.join(q[['Func','Reference','frag_len','panel_all10']]); d['window']=w; d['excl']=excl; d['t']=t
            out.append(d.reset_index())
    P=pd.concat(out,ignore_index=True); P.to_csv(f'pred/pred_{w}.csv.gz',index=False)
    pd.DataFrame(checks).to_csv(f'pred/checks_{w}.csv',index=False)
    print(w,'done',P.shape,flush=True)
