#!/bin/bash
# Round 3 step 1a: exhaustive leave-self-out search per window (all hits >=97%, iddef 2 default) against FullDatabase.
# Used for R4 (majority of qualifying full-coverage refs), exhaustive/full-coverage variants of R2/R3, study exclusion
# of R4 (filtering same-study targets), ties and coverage diagnostics. 4 threads (machine CPU cap 5 incl. default runs).
F="query+target+id+mism+gaps+alnlen+ids+ql+tl+qilo+qihi+tilo+tihi+qstrand"
for w in V4_254 V5V6_281 V4V5_374 V6V8_431 V2V3_410 V3V4_429 V3V4_500 V2V4_600 V1V4_700 V2V8_1100; do
  [ -s exh/exh_${w}.done ] && continue
  vsearch --usearch_global frags/${w}.fasta --id 0.97 --db db/FullDatabase_2025.1.fasta \
    --userout exh/exh_${w}.tsv --userfields $F --strand both --qmask none --threads 4 \
    --minseqlength 1 --self --maxaccepts 0 --maxrejects 0 2> exh/exh_${w}.log && date > exh/exh_${w}.done
done
