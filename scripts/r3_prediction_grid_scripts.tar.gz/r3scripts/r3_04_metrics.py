"""Round 3 step 1d: binary (Inhibitory vs not) metrics per window x panel x rule x exclusion x threshold, with
study-cluster bootstrap 95% CIs (B=500, studies resampled with replacement; one weight matrix per window x panel,
shared by all rules/exclusions/thresholds so contrasts are paired). Basis 'all': every held-out isolate scored, no
call -> non-inhibitory (what the pipeline effectively does). Panels: 'all' (every isolate with that window) and
'panel10' (fixed 1,397 isolates present in all ten windows).
Genus-majority baseline (round-2 g02 definition): genus_full (RDP v18 SINTAX, 0.8) of the held-out isolate; prediction
= Inhibitory iff >50% of the other tested, genus-assigned database isolates of that genus (excluding itself, or its
whole study) are Inhibitory; no genus / no other members -> non-inhibitory. Threshold-independent (threshold = NaN)."""
import glob, zlib, pandas as pd, numpy as np
B=500; TESTED=['Inhibitory','NoEffect','Facilitating']
RULES={'R1_tophit':('R1_bin','R1_has'),'R1_tophit_fullcov':('R1_fc_bin','R1_fc_has'),
       'R2_Inhibitory':('R2','R2'),'R2_Inhibitory_fullcov':('R2_fc','R2_fc'),
       'R3_InhibitoryStrict':('R3','R3'),'R3_InhibitoryStrict_fullcov':('R3_fc','R3_fc'),
       'R2x_Inhibitory_exhaustive':('R2x','R2x'),'R2x_Inhibitory_exhaustive_fullcov':('R2x_fc','R2x_fc'),
       'R3x_Strict_exhaustive':('R3x','R3x'),'R3x_Strict_exhaustive_fullcov':('R3x_fc','R3x_fc'),
       'R4_majority_fullcov':('R4_bin','R4_has'),'R4_majority_anycov':('R4_anycov_bin','R4_anycov_has')}
G=pd.read_csv('genus/genus_assignments.csv',index_col=0)
pool=G[G.Func.isin(TESTED)&G.genus_full.notna()]
cnt=pool.groupby('genus_full').Func.agg(n='size',ninh=lambda s:(s=='Inhibitory').sum())
cst=pool.groupby(['genus_full','Reference']).Func.agg(n='size',ninh=lambda s:(s=='Inhibitory').sum())
def genus_pred(ids, refs, excl):
    g=G.genus_full.reindex(ids).values
    n=np.array([cnt.n.get(x,0) if isinstance(x,str) else 0 for x in g],float)
    k=np.array([cnt.ninh.get(x,0) if isinstance(x,str) else 0 for x in g],float)
    if excl=='self':
        selfin=np.array([isinstance(x,str) for x in g])&G.Func.reindex(ids).isin(TESTED).values
        n-=selfin; k-=selfin&(G.Func.reindex(ids).values=='Inhibitory')
    else:
        n-=np.array([cst.n.get((x,r),0) if isinstance(x,str) else 0 for x,r in zip(g,refs)])
        k-=np.array([cst.ninh.get((x,r),0) if isinstance(x,str) else 0 for x,r in zip(g,refs)])
    with np.errstate(invalid='ignore',divide='ignore'): fr=k/n
    return np.nan_to_num(fr)>0.5, n>0
def bin_stats(TP,FP,TN,FN,M,N):
    n=TP+FP+TN+FN
    with np.errstate(all='ignore'):
        se=TP/(TP+FN); sp=TN/(TN+FP); pe=((TP+FP)*(TP+FN)+(FN+TN)*(FP+TN))/n**2; acc=(TP+TN)/n
        return dict(match_rate=M/N,n_scored=n,accuracy=acc,sensitivity=se,specificity=sp,PPV=TP/(TP+FP),
                    balanced_accuracy=(se+sp)/2,kappa=(acc-pe)/(1-pe),pred_inhibitory_rate=(TP+FP)/n,prevalence=(TP+FN)/n)
rows=[]; per_iso=[]
for f in sorted(glob.glob('pred/pred_*.csv.gz')):
    P=pd.read_csv(f,low_memory=False); w=P.window.iloc[0]
    for c in set(sum(RULES.values(),())): P[c]=P[c].astype(bool)
    for panel in ['all','panel10']:
        D0=P if panel=='all' else P[P.panel_all10.astype(bool)]
        studies=np.array(sorted(D0.Reference.unique())); S=len(studies)
        W=np.random.default_rng(zlib.crc32(f'{w}|{panel}'.encode())).multinomial(S,np.ones(S)/S,size=B)
        def score(y,pred,has,si,**lab):
            c=np.zeros((S,6))
            for j,v in enumerate([y&pred,~y&pred,~y&~pred,y&~pred,has,np.ones_like(y)]): np.add.at(c[:,j],si,v)
            pt=bin_stats(*c.sum(0)); bs=bin_stats(*(W@c).T)
            for m,v in pt.items():
                lo,hi=np.nanpercentile(bs[m],[2.5,97.5]) if m!='n_scored' else (np.nan,np.nan)
                rows.append(dict(window=w,panel=panel,**lab,metric=m,value=float(v),ci_lo=lo,ci_hi=hi,n_isolates=len(y),n_studies=S))
        for (excl,t),D in D0.groupby(['excl','t']):
            si=pd.Categorical(D.Reference,categories=studies).codes; y=D.Func.eq('Inhibitory').values
            for r,(pc,hc) in RULES.items(): score(y,D[pc].values,D[hc].values,si,rule=r,exclusion=excl,threshold=t)
            if t==0.99:
                gp,gh=genus_pred(D.FastaID.values,D.Reference.values,excl)
                score(y,gp,gh,si,rule='G_genus_majority',exclusion=excl,threshold=np.nan)
                if panel=='all': per_iso.append(D[['FastaID','window','excl','Func','Reference']].assign(G_bin=gp,G_has=gh))
    print(w,'scored',flush=True)
M=pd.DataFrame(rows); M.to_csv('out/r3_metrics_long.csv',index=False)
pd.concat(per_iso).to_csv('out/r3_genus_per_isolate.csv.gz',index=False)
k=M[M.metric=='kappa'].set_index(['window','panel','rule','exclusion','threshold'])
S=k[['value','ci_lo','ci_hi','n_isolates','n_studies']].rename(columns={'value':'kappa','ci_lo':'kappa_ci_lo','ci_hi':'kappa_ci_hi'})
for m in ['specificity','sensitivity','PPV','balanced_accuracy','match_rate','pred_inhibitory_rate','prevalence']:
    S[m]=M[M.metric==m].set_index(['window','panel','rule','exclusion','threshold']).value
S.reset_index().to_csv('out/r3_summary_tidy.csv',index=False)
print(M.shape, S.shape)
