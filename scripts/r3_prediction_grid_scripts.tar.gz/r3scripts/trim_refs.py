"""Build per-window reference sets trimmed to the E. coli window +/- MARGIN (from frags/ecoli_map.tsv alignment rows),
in E. coli orientation. Used only to speed the exhaustive (maxaccepts 0/maxrejects 0) search; equivalence to the
full-length-reference search is verified on query subsets (verify_trim.py)."""
import sys, pandas as pd
from Bio import SeqIO
MARGIN = int(sys.argv[1]) if len(sys.argv) > 1 else 60
W = {'V4_254':(533,786),'V3V4_429':(357,785),'V3V4_500':(296,795),'V2V3_410':(101,510),'V2V4_600':(201,800),
     'V1V4_700':(121,820),'V4V5_374':(533,906),'V5V6_281':(780,1060),'V6V8_431':(960,1390),'V2V8_1100':(236,1335)}
m = pd.read_csv('frags/ecoli_map.tsv', sep='\t', header=None,
                names='query id ql qilo qihi tilo tihi qstrand qrow trow'.split())
m = m.dropna(subset=['qrow','trow']).drop_duplicates('query')   # first (top) alignment per reference
full = {r.id: str(r.seq) for r in SeqIO.parse('db/FullDatabase_2025.1.fasta', 'fasta')}
unmapped = set(full) - set(m['query'])
import os; os.makedirs('trimdb', exist_ok=True)
for w, (a, b) in W.items():
    lo, hi = a - MARGIN, b + MARGIN
    with open(f'trimdb/{w}.fasta', 'w') as fh:
        for r in m.itertuples():
            pos = r.tilo - 1; seg = []
            for qc, tc in zip(r.qrow, r.trow):
                if tc != '-': pos += 1
                if lo <= pos <= hi and qc != '-': seg.append(qc)
            s = ''.join(seg)
            if s: fh.write(f'>{r.query}\n{s}\n')
        for u in unmapped: fh.write(f'>{u}\n{full[u]}\n')   # keep unmapped refs untrimmed
print('unmapped refs kept full length:', len(unmapped))
