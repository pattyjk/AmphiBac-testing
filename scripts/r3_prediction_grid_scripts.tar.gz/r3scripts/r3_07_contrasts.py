"""Round 3: paired study-cluster bootstrap contrasts on the fixed 1,397-isolate panel (17 studies), leave-study-out, 99%.
One weight matrix (B=500, seed 7) shared across all windows and rules, so window-vs-window and rule-vs-rule
differences are paired. Reports kappa difference, 95% CI and bootstrap P(diff>0)."""
import pandas as pd, numpy as np, glob
exec(open('r3_04_metrics.py').read().split('rows=[]; per_iso=[]')[0])   # RULES, genus_pred, bin_stats
P=pd.concat([pd.read_csv(f,low_memory=False) for f in glob.glob('pred/pred_*.csv.gz')])
P=P[P.panel_all10.astype(bool)&(P.excl=='study')&np.isclose(P.t,0.99)]
studies=np.array(sorted(P.Reference.unique())); S=len(studies); B=500
W=np.random.default_rng(7).multinomial(S,np.ones(S)/S,size=B)
K={}
for w,D in P.groupby('window'):
    D=D.sort_values('FastaID'); si=pd.Categorical(D.Reference,categories=studies).codes; y=D.Func.eq('Inhibitory').values
    gp,_=genus_pred(D.FastaID.values,D.Reference.values,'study')
    preds={r:D[RULES[r][0]].astype(bool).values for r in ['R1_tophit','R1_tophit_fullcov','R2_Inhibitory','R3_InhibitoryStrict','R4_majority_fullcov','R4_majority_anycov']}
    preds['G_genus_majority']=gp
    for r,p in preds.items():
        c=np.zeros((S,6))
        for j,v in enumerate([y&p,~y&p,~y&~p,y&~p,p,np.ones_like(y)]): np.add.at(c[:,j],si,v)
        K[(w,r)]=(bin_stats(*c.sum(0))['kappa'],bin_stats(*(W@c).T)['kappa'])
rows=[]
def add(kind,a,b):
    d=K[a][0]-K[b][0]; bd=K[a][1]-K[b][1]
    rows.append(dict(contrast=kind,a=f'{a[0]}:{a[1]}',b=f'{b[0]}:{b[1]}',kappa_a=K[a][0],kappa_b=K[b][0],diff=d,ci_lo=np.nanpercentile(bd,2.5),ci_hi=np.nanpercentile(bd,97.5),p_boot_gt0=float(np.mean(bd>0))))
wins=sorted({k[0] for k in K})
for w in wins:
    add('genus_minus_rule',(w,'G_genus_majority'),(w,'R4_majority_fullcov')); add('genus_minus_rule',(w,'G_genus_majority'),(w,'R1_tophit'))
    add('R4fc_minus_R1',(w,'R4_majority_fullcov'),(w,'R1_tophit'))
    add('fullcov_minus_default',(w,'R1_tophit_fullcov'),(w,'R1_tophit'))
    if w!='V4_254':
        for r in ['R1_tophit','R2_Inhibitory','R3_InhibitoryStrict','R4_majority_fullcov']: add('window_minus_V4',(w,r),('V4_254',r))
C=pd.DataFrame(rows); C.to_csv('out/r3_paired_contrasts_panel10.csv',index=False)
print(C.round(3).to_string())
