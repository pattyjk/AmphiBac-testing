"""Round 3 step 1b/2d: exact q2-vsearch closed-reference call (vsearch defaults maxaccepts 1 / maxrejects 32) per
window x db x threshold.
 (i) leave-self-out: q2 call + --self (query label == FastaID == target label), one query file per window.
 (ii) leave-study-out: q2 call against each db with all isolates of the query's study removed (per-study dbs);
      query file per study = that study's fragments from all ten windows, label FastaID|window.
 (iii) reference-order shuffles: FullDatabase with record order permuted (seeds 1-5), --self, 99%.
1 thread per run (exhaustive search runs concurrently on 4 threads; machine cap 5)."""
import os, subprocess, itertools, random, pandas as pd
from Bio import SeqIO
TH = [0.97, 0.98, 0.99, 0.995, 1.0]
WIN = ['V4_254','V3V4_429','V3V4_500','V2V3_410','V2V4_600','V1V4_700','V4V5_374','V5V6_281','V6V8_431','V2V8_1100']
DBS = {'Full':'db/FullDatabase_2025.1.fasta','Inhibitory':'db/Inhibitory_2025.1.fasta','InhibitoryStrict':'db/InhibitoryStrict_2025.1.fasta'}
def nq(f): return sum(1 for l in open(f) if l.startswith('>'))
def nrec(uc): return sum(1 for l in open(uc) if l[0] in 'HN') if os.path.exists(uc) else -1
def q2(query, db, t, uc, extra=()):
    if nrec(uc) == nq(query): return
    cmd = ['vsearch','--usearch_global',query,'--id',str(t),'--db',db,'--uc',uc,'--strand','both','--qmask','none',
           '--notmatched',uc.replace('.uc','.unmatched.fasta'),'--threads','1','--minseqlength','1','--fasta_width','0',*extra]
    subprocess.run(cmd, check=True, stderr=subprocess.DEVNULL)
a = pd.read_csv('db/audit_per_sequence.csv', index_col=0); a['Reference'] = a.Reference.fillna('NA')
studies = sorted(a.Reference.unique()); sid = {s:i for i,s in enumerate(studies)}
pd.Series(studies).to_csv('studydb/study_index.csv', header=['Reference'])
# (i) self
for w, (dn, dp), t in itertools.product(WIN, DBS.items(), TH):
    q2(f'frags/{w}.fasta', dp, t, f'dflt/self_{w}_{dn}_{t}.uc', ('--self',))
print('self done', flush=True)
# (iii) shuffles
full = list(SeqIO.parse(DBS['Full'], 'fasta'))
for s in range(1, 6):
    p = f'shuf/Full_shuf{s}.fasta'
    if not os.path.exists(p):
        r = full[:]; random.Random(s).shuffle(r); SeqIO.write(r, p, 'fasta-2line')
    for w in WIN: q2(f'frags/{w}.fasta', p, 0.99, f'shuf/self_{w}_shuf{s}_0.99.uc', ('--self',))
print('shuffles done', flush=True)
# (ii) study exclusion
idx = pd.read_csv('frags/fragment_index.csv'); idx['Reference'] = a.Reference.reindex(idx.FastaID).values
seqs = {w: {r.id: str(r.seq) for r in SeqIO.parse(f'frags/{w}.fasta','fasta')} for w in WIN}
dbseq = {dn: list(SeqIO.parse(dp,'fasta')) for dn, dp in DBS.items()}
jobs = []
for s, g in idx.groupby('Reference'):
    i = sid[s]; qf = f'studydb/q_{i}.fasta'
    if not os.path.exists(qf):
        with open(qf,'w') as fh:
            for r in g.itertuples(): fh.write(f'>{r.FastaID}|{r.window}\n{seqs[r.window][r.FastaID]}\n')
    excl = set(a.index[a.Reference == s])
    for dn, recs in dbseq.items():
        p = f'studydb/{dn}_minus{i}.fasta'
        if not os.path.exists(p):
            with open(p,'w') as fh:
                for r in recs:
                    if r.id not in excl: fh.write(f'>{r.id}\n{r.seq}\n')
        for t in TH: jobs.append((qf, p, t, f'dflt/study{i}_{dn}_{t}.uc'))
# 99% and 100% first so a time-limited run still has the headline thresholds
jobs.sort(key=lambda j: (j[2] not in (0.99, 1.0), j[2]))
for k, j in enumerate(jobs):
    q2(*j)
    if k % 50 == 0: print('study', k, len(jobs), flush=True)
print('study done', flush=True)
