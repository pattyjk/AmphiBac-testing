## Round-3 step 2: phylogenetic signal of binary Bd inhibition per 16S window.
## Trees: FastTree -nt -gtr -gamma on unique fragments, midpoint-rooted, expanded to isolate tips (identical fragments =
## star polytomy with 1e-6 branches; round-2 expand_tree). Metrics:
##  consenTRAIT tauD (Martiny 2013; round-2 vectorised code, 90% threshold) on isolate tips;
##  Fritz-Purvis D (caper phylo.d definition: sum of sister-clade differences on the fully resolved tree, node value =
##  1/branch-length-weighted mean of daughters with PIC branch adjustment; random reference = 1000 tip shuffles; Brownian reference = 1000 BM simulations thresholded to the
##  observed number of positives) re-implemented in vectorised form (validated against caper::phylo.d, see d06);
##  permutation nulls: global label shuffle and within-study label shuffle (NP each), statistic recomputed per permutation.
##  Two tip sets: isolate tips (primary) and unique-sequence tips with one random isolate per identical fragment
##  (round-2 D convention; 5 draws).
## Usage: Rscript d05_signal.R WINDOW SET(panel|all) NP
args <- commandArgs(TRUE); w <- args[1]; set <- args[2]; NP <- as.integer(args[3])
source("scripts/p2_signal_functions.R"); set.seed(1)
d <- read.csv(sprintf("work/%s_%s_isolates.csv", w, set), stringsAsFactors = FALSE)
tr0 <- midpoint.root(read.tree(sprintf("work/%s_%s_unique.tre", w, set)))
tr <- expand_tree(tr0, d[, c("FastaID", "uid")])
d <- d[match(tr$tip.label, d$FastaID), ]; stopifnot(all(d$FastaID == tr$tip.label))
write.tree(tr, sprintf("out/trees/%s_%s_isolate_tree.nwk", w, set))
## ---- vectorised D machinery
prep_D <- function(phy) {
  phy <- multi2di(phy, random = FALSE); phy$edge.length[phy$edge.length < EPS] <- EPS; phy$node.label <- NULL
  phy <- reorder(phy, "postorder"); n <- Ntip(phy)
  ch <- split(phy$edge[, 2], phy$edge[, 1]); nodes <- unique(phy$edge[, 1])   # postorder parents
  list(phy = phy, n = n, nodes = nodes, c1 = sapply(ch[as.character(nodes)], `[`, 1), c2 = sapply(ch[as.character(nodes)], `[`, 2),
       pre = reorder(phy, "cladewise"), el = phy$edge.length[match(seq_len(n + phy$Nnode), phy$edge[, 2])])
}
sumdiff <- function(P, X) {   # X: tips x reps (0/1); returns sum of |sister differences| per column
  # caper phylo.d: node value = mean of daughters weighted by 1/(branch length + PIC adjustment); adjustment
  # prod(bl)/sum(bl) is added to the parent's branch; contrast = |a - b|
  V <- matrix(0, P$n + length(P$nodes), ncol(X)); V[1:P$n, ] <- X; S <- numeric(ncol(X)); adj <- numeric(nrow(V))
  for (k in seq_along(P$nodes)) { i1 <- P$c1[k]; i2 <- P$c2[k]; b1 <- P$el[i1] + adj[i1]; b2 <- P$el[i2] + adj[i2]
    a <- V[i1, ]; b <- V[i2, ]; S <- S + abs(a - b); V[P$nodes[k], ] <- (a / b1 + b / b2) / (1 / b1 + 1 / b2); adj[P$nodes[k]] <- b1 * b2 / (b1 + b2) }
  S
}
sim_bm <- function(P, nsim) {  # continuous BM tip values, nsim columns
  e <- P$pre$edge; L <- P$pre$edge.length; V <- matrix(0, P$n + P$pre$Nnode, nsim)
  for (i in seq_len(nrow(e))) V[e[i, 2], ] <- V[e[i, 1], ] + rnorm(nsim, 0, sqrt(L[i]))
  V[1:P$n, , drop = FALSE]
}
thresh <- function(B, k) apply(B, 2, function(v) { x <- integer(length(v)); x[order(v, decreasing = TRUE)[seq_len(k)]] <- 1L; x })
D_full <- function(P, x, g, B, NP) {   # x 0/1 in P$phy tip order; g study; B continuous BM sims
  k <- sum(x); obs <- sumdiff(P, matrix(x, ncol = 1))
  sr <- sumdiff(P, sapply(1:1000, function(i) sample(x))); sb <- sumdiff(P, thresh(B, k))
  Df <- function(s) (s - mean(sb)) / (mean(sr) - mean(sb))
  ng <- Df(sumdiff(P, sapply(1:NP, function(i) sample(x)))); ns <- Df(sumdiff(P, sapply(1:NP, function(i) perm_within(x, g))))
  list(D = Df(obs), obs = obs, mean_random = mean(sr), mean_brownian = mean(sb),
       P_random = mean(sr <= obs), P_brownian = mean(sb >= obs), ng = ng, ns = ns)
}
rowD <- function(tipset, rep, r, n, k) {
  do.call(rbind, lapply(c("global", "within-study"), function(nm) { nul <- if (nm == "global") r$ng else r$ns
    data.frame(window = w, set = set, tips = tipset, rep = rep, metric = "D", null = nm, n_tips = n, n_positive = k,
      obs = r$D, null_mean = mean(nul), null_q025 = quantile(nul, .025), null_q975 = quantile(nul, .975),
      p_signal = (1 + sum(nul <= r$D)) / (length(nul) + 1), SES = (r$D - mean(nul)) / sd(nul),
      D_P_random = r$P_random, D_P_brownian = r$P_brownian, n_clades = NA, frac_pos_tips_in_clades = NA) })) }
rowT <- function(tipset, rep, obs, ng, ns, n, k) {
  do.call(rbind, lapply(c("global", "within-study"), function(nm) { nul <- if (nm == "global") ng else ns
    data.frame(window = w, set = set, tips = tipset, rep = rep, metric = "tauD", null = nm, n_tips = n, n_positive = k,
      obs = obs["tauD"], null_mean = mean(nul["tauD", ]), null_q025 = quantile(nul["tauD", ], .025), null_q975 = quantile(nul["tauD", ], .975),
      p_signal = (1 + sum(nul["tauD", ] >= obs["tauD"])) / (ncol(nul) + 1), SES = (obs["tauD"] - mean(nul["tauD", ])) / sd(nul["tauD", ]),
      D_P_random = NA, D_P_brownian = NA, n_clades = obs["n_clades"], frac_pos_tips_in_clades = obs["tips_in_clades"] / k) })) }
out <- list(); t0 <- Sys.time()
## ---- isolate tips
x <- as.integer(d$Func == "Inhibitory"); P <- prep_consentrait(tr)
obs <- consentrait(P, matrix(x, ncol = 1))[, 1]
ng <- consentrait(P, sapply(1:NP, function(i) sample(x))); ns <- consentrait(P, sapply(1:NP, function(i) perm_within(x, d$study)))
out[[length(out) + 1]] <- rowT("isolate tips", NA, obs, ng, ns, length(x), sum(x))
saveRDS(list(global = ng["tauD", ], within = ns["tauD", ]), sprintf("work/null_tau_%s_%s.rds", w, set))
PD <- prep_D(tr); di <- d[match(PD$phy$tip.label, d$FastaID), ]; xd <- as.integer(di$Func == "Inhibitory")
B <- sim_bm(PD, 1000); r <- D_full(PD, xd, di$study, B, NP)
out[[length(out) + 1]] <- rowD("isolate tips", NA, r, length(xd), sum(xd))
saveRDS(list(global = r$ng, within = r$ns), sprintf("work/null_D_%s_%s.rds", w, set))
cat(w, set, "isolate tips: tauD", obs["tauD"], " D", r$D, format(Sys.time() - t0), "\n")
## ---- unique-sequence tips, one random isolate per identical fragment (5 draws)
tu <- tr0; tu$edge.length[tu$edge.length < EPS] <- EPS; Pu <- prep_consentrait(tu); PDu <- prep_D(tu); Bu <- sim_bm(PDu, 1000)
NPu <- max(199, NP %/% 5)
for (rep in 1:5) {
  pick <- do.call(rbind, lapply(split(d, d$uid), function(g) g[sample.int(nrow(g), 1), ]))
  pk <- pick[match(tu$tip.label, pick$uid), ]; x <- as.integer(pk$Func == "Inhibitory")
  obs <- consentrait(Pu, matrix(x, ncol = 1))[, 1]
  out[[length(out) + 1]] <- rowT("unique-sequence tips (1 random isolate each)", rep, obs,
    consentrait(Pu, sapply(1:NPu, function(i) sample(x))), consentrait(Pu, sapply(1:NPu, function(i) perm_within(x, pk$study))), length(x), sum(x))
  pd <- pick[match(PDu$phy$tip.label, pick$uid), ]; xd <- as.integer(pd$Func == "Inhibitory")
  r <- D_full(PDu, xd, pd$study, Bu, NPu)
  out[[length(out) + 1]] <- rowD("unique-sequence tips (1 random isolate each)", rep, r, length(xd), sum(xd))
}
res <- do.call(rbind, out); rownames(res) <- NULL
write.csv(res, sprintf("out/signal/signal_%s_%s.csv", w, set), row.names = FALSE)
cat(w, set, "done", format(Sys.time() - t0), "\n")
