# per-window alignment (mafft --auto) + FastTree -nt -gtr -gamma on unique fragments; fixed panel and all isolates
# 2 threads (CPU cap 4 total, other 2 used by all-pairs)
export TMPDIR=$PWD/tmp OMP_NUM_THREADS=1
for w in V5V6_281 V6V8_431 V4V5_374 V4_254 V2V3_410 V3V4_429 V3V4_500 V2V4_600 V1V4_700 V2V8_1100; do
 for t in panel all; do
  f=work/${w}_${t}_unique; [ -s $f.tre ] && continue
  s=$(date +%s)
  mafft --auto --thread 2 --quiet $f.fasta > $f.aln.fasta
  FastTree -nt -gtr -gamma -quiet $f.aln.fasta > $f.tre 2> logs/ft_${w}_${t}.log
  echo "$w $t $(( $(date +%s) - s ))s" | tee -a logs/trees.log
 done
done
