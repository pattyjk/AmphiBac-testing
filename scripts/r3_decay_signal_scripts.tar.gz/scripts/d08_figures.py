"""Round-3 decay/signal figures (300 dpi). Run after d07_tables.py."""
import numpy as np, pandas as pd, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
INH = '#2166AC'; GREY = '#8C8C8C'
WIN = ['V1V4_700', 'V2V3_410', 'V2V4_600', 'V2V8_1100', 'V3V4_429', 'V3V4_500', 'V4_254', 'V4V5_374', 'V5V6_281', 'V6V8_431']
coords = {'V4_254': '533-786', 'V3V4_429': '357-785', 'V3V4_500': '296-795', 'V2V3_410': '101-510', 'V2V4_600': '201-800',
          'V1V4_700': '121-820', 'V4V5_374': '533-906', 'V5V6_281': '780-1060', 'V6V8_431': '960-1390', 'V2V8_1100': '236-1335'}
dec = pd.read_csv('out/r3_decay_all_windows.csv', dtype={'bin': str}); bs = pd.read_csv('out/r3_decay_bootstrap_all_windows.csv')
wd = pd.read_csv('out/r3_window_sets.csv').set_index(['window', 'panel'])
MB = ['0', '1', '2', '3', '4-5', '6-10', '11-20', '>20']; IB = ['<97', '97-98', '98-99', '99-99.5', '99.5-<100', '100']
STY = {'panel': dict(color='black', ls='-', marker='o', label='fixed panel (1,397 isolates, 17 studies)'),
       'all': dict(color=GREY, ls='--', marker='s', label='all isolates with this window')}
def facet(metric, grouping, bins, ylabel, fname, boot_bin, ylim, base=False):
    fig, axs = plt.subplots(2, 5, figsize=(7.2, 3.9), sharex=True, sharey=True)
    for ax, w in zip(axs.flat, WIN):
        for p in ('all', 'panel'):
            x = dec[(dec.window == w) & (dec.panel == p) & (dec.stratum == 'between-study') & (dec.grouping == grouping)].set_index('bin').reindex(bins)
            st = STY[p]; ax.plot(range(len(bins)), x[metric].values, color=st['color'], ls=st['ls'], marker=st['marker'], ms=2.8, lw=1)
            b = bs[(bs.window == w) & (bs.panel == p) & (bs.bin == boot_bin) & (bs.stratum == 'between-study') & (bs.metric == metric)]
            if len(b) and grouping == 'identity':   # pooled >=99.5% bin drawn as a separate open point with its CI
                xi = len(bins) + 0.3
                pv = dec[(dec.window == w) & (dec.panel == p) & (dec.stratum == 'between-study') & (dec.grouping == 'identity') & (dec.bin == '>=99.5')][metric].iloc[0]
                ax.plot(xi + (0.3 if p == 'all' else 0), pv, marker=st['marker'], mfc='white', mec=st['color'], ms=3, ls='none')
                ax.errorbar(xi + (0.3 if p == 'all' else 0), pv, yerr=[[max(pv - b.lo95.iloc[0], 0)], [max(b.hi95.iloc[0] - pv, 0)]], color=st['color'], lw=0.8, capsize=1.5, fmt='none')
            elif len(b) and boot_bin:
                xi = bins.index('0')
                ax.errorbar(xi + (0.25 if p == 'all' else 0), b['median'].iloc[0], yerr=[[b['median'].iloc[0] - b.lo95.iloc[0]], [b.hi95.iloc[0] - b['median'].iloc[0]]],
                            color=st['color'], lw=0.8, capsize=1.5, fmt='none')
            if base:
                rb = dec[(dec.window == w) & (dec.panel == p) & (dec.stratum == 'between-study') & (dec.grouping == 'baseline')][metric].iloc[0]
                ax.axhline(rb, color=st['color'], lw=0.5, ls=':')
        if not base: ax.axhline(0, color='0.6', lw=0.5)
        na, npn = wd.loc[(w, 'all'), 'n_isolates'], wd.loc[(w, 'panel'), 'n_isolates']
        ax.set_title(f'{w.replace("_", " ")} bp ({coords[w]})', fontsize=7, loc='left')
        ax.text(0.97, 0.97, f'all n={na:,}', transform=ax.transAxes, ha='right', va='top', fontsize=6, color=GREY)
        ax.set_ylim(*ylim)
        if grouping == 'identity':
            ax.set_xticks(list(range(len(bins))) + [len(bins) + 0.45]); ax.set_xticklabels(bins + ['>=99.5\npooled'], rotation=90, fontsize=6)
        else:
            ax.set_xticks(range(len(bins))); ax.set_xticklabels(bins, rotation=90, fontsize=6)
    fig.supylabel(ylabel, fontsize=8)
    for ax in axs[1]: ax.set_xlabel('fragment differences' if grouping == 'differences' else '% identity (vsearch id)')
    h = [Line2D([], [], **{k: v for k, v in STY[p].items()}, ms=3, lw=1) for p in ('panel', 'all')]
    if base: h.append(Line2D([], [], color='0.3', ls=':', lw=0.7, label='random between-study pair'))
    fig.legend(handles=h, loc='upper center', ncol=len(h), frameon=False, fontsize=7, bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.94), h_pad=0.6, w_pad=0.3); fig.savefig(fname, dpi=300); plt.close(fig)
facet('kappa_binary_vs_studyprev', 'differences', MB, 'kappa vs study prevalence (between-study pairs)', 'fig/r3_fig1_decay_kappa_between.png', '0 differences', (-0.15, 0.75))
facet('P_partner_inh_given_inh', 'identity', IB, 'P(partner inhibitory | focal inhibitory), between-study pairs', 'fig/r3_fig2_decay_Ppartner_identity_between.png', '>=99.5% identity', (0.3, 0.95), base=True)
# Fig 3: D and tauD by window
sig = pd.read_csv('out/r3_signal_all_windows.csv')
iso = sig[sig.tips == 'isolate tips']
uq = sig[sig.tips != 'isolate tips']
order = sorted(WIN, key=lambda w: int(coords[w].split('-')[0]))
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.9))
for p, off in (('panel', -0.15), ('all', 0.15)):
    st = STY[p]
    for j, w in enumerate(order):
        g = iso[(iso.window == w) & (iso.set == p) & (iso.metric == 'D')].set_index('null')
        axs[0].plot(j + off, g.loc['global', 'obs'], marker=st['marker'], color=st['color'], ms=3.5, ls='none')
        axs[0].errorbar(j + off + 0.06, g.loc['within-study', 'null_mean'], yerr=[[g.loc['within-study', 'null_mean'] - g.loc['within-study', 'null_q025']], [g.loc['within-study', 'null_q975'] - g.loc['within-study', 'null_mean']]],
                        color=st['color'], alpha=0.45, lw=0.8, capsize=1.2, fmt='_', ms=4)
        u = uq[(uq.window == w) & (uq.set == p) & (uq.metric == 'D') & (uq.null == 'global')]
        axs[1].plot(j + off, u.obs.median(), marker=st['marker'], color=st['color'], ms=3.5, ls='none')
        axs[1].vlines(j + off, u.obs.min(), u.obs.max(), color=st['color'], lw=0.8)
        t = iso[(iso.window == w) & (iso.set == p) & (iso.metric == 'tauD')].set_index('null')
        axs[2].plot(j + off, t.loc['within-study', 'SES'], marker=st['marker'], color=st['color'], ms=3.5, ls='none')
axs[0].axhline(1, color='0.6', lw=0.5, ls=':'); axs[0].axhline(0, color='0.6', lw=0.5, ls=':'); axs[1].axhline(1, color='0.6', lw=0.5, ls=':')
axs[2].axhline(0, color='0.6', lw=0.5); axs[2].axhline(1.645, color='0.6', lw=0.5, ls=':')
axs[0].set_ylabel('Fritz-Purvis D'); axs[0].set_ylim(0.3, 1.1); axs[1].set_ylim(0.3, 1.1)
axs[0].set_title('D, isolate tips\n(bars: within-study null 95%)', loc='left', fontsize=7)
axs[1].set_title('D, unique-sequence tips\n(5 random-isolate draws, range)', loc='left', fontsize=7)
axs[2].set_title('consenTRAIT tauD vs\nwithin-study null', loc='left', fontsize=7); axs[2].set_ylabel('tauD SES (>1.645: clustered)')
for ax in axs:
    ax.set_xticks(range(len(order))); ax.set_xticklabels([w.replace('_', ' ') for w in order], rotation=90, fontsize=6); ax.set_xlim(-0.6, len(order) - 0.4)
axs[0].text(0.02, 0.03, 'D=1 random; D=0 Brownian', transform=axs[0].transAxes, fontsize=6, color='0.4')
h = [Line2D([], [], color=STY[p]['color'], marker=STY[p]['marker'], ls='none', ms=3.5, label=STY[p]['label']) for p in ('panel', 'all')]
fig.legend(handles=h, loc='upper center', ncol=2, frameon=False, fontsize=7, bbox_to_anchor=(0.5, 1.0))
fig.tight_layout(rect=(0, 0, 1, 0.92), w_pad=1.0); fig.savefig('fig/r3_fig3_signal_D_tauD_by_window.png', dpi=300); plt.close(fig)
