"""Round-3 decay/signal track, step 0: per-window isolate table (Func, score, study [round-2 definition], uid of
identical fragment), dereplicated FASTA for all isolates and for the fixed 1,397-isolate panel (panel_all10)."""
import pandas as pd
from Bio import SeqIO
a = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
m = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', index_col=0, low_memory=False)
a = a.join(m[['Researchers', 'Isolate.ID']])
unpub = a.Reference.str.lower().str.contains('publish') | a.Reference.isna()
a['study'] = a.Reference.str.strip().str.lower().str.split(' ').str[0]
a.loc[unpub, 'study'] = 'unpub|' + a.loc[unpub, 'Researchers'].fillna('NA').astype(str)
idx = pd.read_csv('frags/fragment_index.csv')
W = list(idx.window.unique())
for w in W:
    seqs = {r.id: str(r.seq).upper() for r in SeqIO.parse(f'frags/{w}.fasta', 'fasta')}
    d = idx[idx.window == w].set_index('FastaID')[['frag_len', 'panel_all10']].copy()
    d['seq'] = [seqs[f] for f in d.index]
    d = d.join(a[['Func', 'score', 'study', 'Isolate.ID']])
    assert d.Func.isin(['Inhibitory', 'NoEffect', 'Facilitating']).all()
    for tag, dd in (('all', d), ('panel', d[d.panel_all10])):
        u = {s: f'u{i}' for i, s in enumerate(dd.seq.unique())}
        dd = dd.copy(); dd['uid'] = dd.seq.map(u)
        with open(f'work/{w}_{tag}_unique.fasta', 'w') as fh:
            for s, i in u.items(): fh.write(f'>{i}\n{s}\n')
        dd.drop(columns='seq').to_csv(f'work/{w}_{tag}_isolates.csv')
        print(w, tag, 'isolates', len(dd), 'unique', len(u), 'studies', dd.study.nunique(), 'inh%', round(100*(dd.Func=='Inhibitory').mean(),1))
