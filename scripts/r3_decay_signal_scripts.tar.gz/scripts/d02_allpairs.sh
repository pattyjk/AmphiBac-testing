# exhaustive all-vs-all global alignment of unique fragments per window (no subsampling); 2 threads (CPU cap 4 total)
for w in V5V6_281 V6V8_431 V4V5_374 V2V8_1100 V4_254 V2V3_410 V3V4_500 V3V4_429 V1V4_700 V2V4_600; do
  [ -s work/${w}_allpairs.tsv.done ] && continue
  s=$(date +%s)
  vsearch --allpairs_global work/${w}_all_unique.fasta --acceptall --threads 2 --qmask none \
    --userout work/${w}_allpairs.tsv --userfields query+target+id+mism+gaps+alnlen+ids --quiet
  echo "$w $(( $(date +%s) - s ))s $(wc -l < work/${w}_allpairs.tsv)" | tee -a logs/allpairs.log
  echo ok > work/${w}_allpairs.tsv.done
done
