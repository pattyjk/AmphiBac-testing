"""Round-3 step 1: label-decay curves per 16S window (exhaustive isolate pairs, no subsampling).
Definitions reused from round-2 p1_decay.py / p1_fulllength.py:
  differences = alnlen - identities from vsearch --allpairs_global of unique fragments (terminal gaps count; identical = 0)
  % identity  = vsearch id (iddef 2, terminal gaps ignored); bins [<97,97-98,98-99,99-99.5,99.5-<100,100]
  study = Reference first token (unpublished split by Researchers); kappa vs study prevalence:
  expected binary agreement = p_si p_sj + (1-p_si)(1-p_sj), p_s = inhibitory fraction of study s in the analysed set.
Panels: 'all' (all isolates with that window) and 'panel' (fixed 1,397 isolates present in all 10 windows; study
prevalences recomputed on the panel). Cluster bootstrap (2,000 reps) for the 0-difference bin (clusters = identical-
fragment groups, as round 2) and the >=99.5% identity bin (clusters = single-linkage components at >=99.5% id).
Usage: python d04_decay.py WINDOW"""
import sys, numpy as np, pandas as pd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
w = sys.argv[1]
d0 = pd.read_csv(f'work/{w}_all_isolates.csv', index_col=0)
U = sorted(d0.uid.unique(), key=lambda s: int(s[1:])); ui = {u: i for i, u in enumerate(U)}; nu = len(U)
Dm = np.full((nu, nu), 9999, dtype=np.int16); np.fill_diagonal(Dm, 0)
Im = np.full((nu, nu), -1, dtype=np.float32); np.fill_diagonal(Im, 100)
p = pd.read_csv(f'work/{w}_allpairs.tsv', sep='\t', header=None, names=['q', 't', 'id', 'mism', 'gaps', 'alnlen', 'ids'])
qi = p.q.map(ui).values; ti = p.t.map(ui).values; diff = (p.alnlen - p.ids).values.astype(np.int16)
Dm[qi, ti] = diff; Dm[ti, qi] = diff; Im[qi, ti] = p.id.values; Im[ti, qi] = p.id.values
assert (Dm == 9999).sum() == 0 and (Im < 0).sum() == 0
# single-linkage components of unique fragments at >=99.5% id (for cluster bootstrap)
A = coo_matrix(Im >= 99.5); ncomp, comp = connected_components(A, directed=False)
MEDGES = [(0, 0, '0'), (1, 1, '1'), (2, 2, '2'), (3, 3, '3'), (4, 5, '4-5'), (6, 10, '6-10'), (11, 20, '11-20'), (21, 99999, '>20')]
IEDGES = [(0, 97, '<97'), (97, 98, '97-98'), (98, 99, '98-99'), (99, 99.5, '99-99.5'), (99.5, 99.9999, '99.5-<100'), (99.9999, 101, '100')]
rows, boots = [], []
rng = np.random.default_rng(1)
for panel in ('all', 'panel'):
    d = d0 if panel == 'all' else d0[d0.panel_all10]
    n = len(d); u = d.uid.map(ui).values
    inh = (d.Func == 'Inhibitory').values; fac = (d.Func == 'Facilitating').values
    lab = d.Func.map({'Inhibitory': 0, 'NoEffect': 1, 'Facilitating': 2}).values
    st = pd.factorize(d.study)[0]; sc = d.score.values.astype(float)
    pst = pd.Series(inh).groupby(st).mean().values
    I, J = np.triu_indices(n, 1); I = I.astype(np.int32); J = J.astype(np.int32)
    uI, uJ = u[I], u[J]
    dd = Dm[uI, uJ]; idv = Im[uI, uJ]
    within = st[I] == st[J]
    sameb = inh[I] == inh[J]; both = inh[I] & inh[J]; one = inh[I] ^ inh[J]
    same3 = lab[I] == lab[J]
    fb = fac[I] & fac[J]; fo = fac[I] ^ fac[J]
    sdiff = np.abs(sc[I] - sc[J])
    pi_, pj_ = pst[st[I]], pst[st[J]]; expb = pi_ * pj_ + (1 - pi_) * (1 - pj_)
    mb = np.full(len(dd), -1, np.int8)
    for k, (lo, hi, _) in enumerate(MEDGES): mb[(dd >= lo) & (dd <= hi)] = k
    ib = np.full(len(dd), -1, np.int8)
    for k, (lo, hi, _) in enumerate(IEDGES): ib[(idv >= lo) & (idv < hi)] = k
    assert (mb >= 0).all() and (ib >= 0).all()
    def summ(mk, grouping, bl, stratum):
        npair = int(mk.sum())
        r = dict(window=w, panel=panel, grouping=grouping, bin=bl, stratum=stratum, n_pairs=npair)
        if npair == 0: return r
        nb, no = both[mk].sum(), one[mk].sum(); s = sdiff[mk]; s = s[~np.isnan(s)]
        e = expb[mk].mean(); ps = sameb[mk].mean()
        r.update(n_isolates=len(np.unique(np.concatenate([I[mk], J[mk]]))),
                 n_unique_seq=len(np.unique(np.concatenate([uI[mk], uJ[mk]]))),
                 P_same_binary=ps, P_same_binary_expected_studyprev=e,
                 kappa_binary_vs_studyprev=(ps - e) / (1 - e) if e < 1 else np.nan,
                 P_partner_inh_given_inh=2 * nb / (2 * nb + no) if (2 * nb + no) else np.nan,
                 n_pairs_with_inh=int(nb + no), P_same_3class=same3[mk].mean(),
                 P_partner_fac_given_fac=2 * fb[mk].sum() / (2 * fb[mk].sum() + fo[mk].sum()) if (fb[mk].sum() + fo[mk].sum()) else np.nan,
                 n_pairs_scored=len(s), absdiff_score_median=np.median(s) if len(s) else np.nan,
                 absdiff_score_q25=np.percentile(s, 25) if len(s) else np.nan,
                 absdiff_score_q75=np.percentile(s, 75) if len(s) else np.nan)
        return r
    strata = (('all pairs', np.ones(len(dd), bool)), ('within-study', within), ('between-study', ~within))
    for sn, sm in strata:
        for k, (_, _, bl) in enumerate(MEDGES): rows.append(summ(sm & (mb == k), 'differences', bl, sn))
        for k, (_, _, bl) in enumerate(IEDGES): rows.append(summ(sm & (ib == k), 'identity', bl, sn))
        rows.append(summ(sm & (idv >= 99.5), 'identity', '>=99.5', sn))
        rows.append(summ(sm, 'baseline', 'random pair (all)', sn))
    # cluster bootstrap
    for bname, z, clus in (('0 differences', dd == 0, uI), ('>=99.5% identity', idv >= 99.5, comp[uI])):
        cl = pd.DataFrame(dict(c=clus[z], w=within[z], sb=sameb[z], bo=both[z], on=one[z], ex=expb[z]))
        agg = cl.groupby(['c', 'w']).agg(n=('sb', 'size'), sb=('sb', 'sum'), bo=('bo', 'sum'), on=('on', 'sum'), ex=('ex', 'sum')).unstack(fill_value=0)
        C = len(agg); arr = {k: agg[k].reindex(columns=[True, False], fill_value=0).values for k in ('n', 'sb', 'bo', 'on', 'ex')}
        K = rng.integers(0, C, (2000, C))
        out = {}
        for wi, nm in ((0, 'within-study'), (1, 'between-study')):
            S = {k: arr[k][:, wi][K].sum(1).astype(float) for k in arr}
            with np.errstate(invalid='ignore', divide='ignore'):
                ps = S['sb'] / S['n']; e = S['ex'] / S['n']
                out[nm] = dict(P_same_binary=ps, kappa_binary_vs_studyprev=(ps - e) / (1 - e),
                               P_partner_inh_given_inh=2 * S['bo'] / (2 * S['bo'] + S['on']))
        for nm, mets in out.items():
            for met, v in mets.items():
                boots.append(dict(window=w, panel=panel, bin=bname, stratum=nm, metric=met, n_clusters=C,
                                  lo95=np.nanpercentile(v, 2.5), median=np.nanmedian(v), hi95=np.nanpercentile(v, 97.5)))
        dv = out['within-study']['kappa_binary_vs_studyprev'] - out['between-study']['kappa_binary_vs_studyprev']
        boots.append(dict(window=w, panel=panel, bin=bname, stratum='within minus between', metric='kappa_binary_vs_studyprev',
                          n_clusters=C, lo95=np.nanpercentile(dv, 2.5), median=np.nanmedian(dv), hi95=np.nanpercentile(dv, 97.5)))
    del I, J, uI, uJ, dd, idv
res = pd.DataFrame(rows); res.to_csv(f'out/decay_{w}.csv', index=False)
pd.DataFrame(boots).to_csv(f'out/decay_{w}_bootstrap.csv', index=False)
print(w, 'unique', nu, 'components>=99.5', ncomp)
x = res[(res.stratum == 'between-study') & (res.grouping != 'baseline')]
print(x[['panel', 'grouping', 'bin', 'n_pairs', 'P_partner_inh_given_inh', 'kappa_binary_vs_studyprev']].round(3).to_string(index=False))
