"""Assemble tidy summary (decay + signal), combined decay table, bootstrap table, xlsx."""
import pandas as pd, glob
WIN = ['V1V4_700', 'V2V3_410', 'V2V4_600', 'V2V8_1100', 'V3V4_429', 'V3V4_500', 'V4_254', 'V4V5_374', 'V5V6_281', 'V6V8_431']
dec = pd.concat([pd.read_csv(f'out/decay_{w}.csv') for w in WIN], ignore_index=True)
bs = pd.concat([pd.read_csv(f'out/decay_{w}_bootstrap.csv') for w in WIN], ignore_index=True)
sig = pd.concat([pd.read_csv(f) for f in sorted(glob.glob('out/signal/signal_*.csv'))], ignore_index=True)
idx = pd.read_csv('frags/fragment_index.csv')
coords = {'V4_254': '533-786', 'V3V4_429': '357-785', 'V3V4_500': '296-795', 'V2V3_410': '101-510', 'V2V4_600': '201-800',
          'V1V4_700': '121-820', 'V4V5_374': '533-906', 'V5V6_281': '780-1060', 'V6V8_431': '960-1390', 'V2V8_1100': '236-1335'}
# tidy summary: decay rows (long) + signal rows
keep = ['P_partner_inh_given_inh', 'kappa_binary_vs_studyprev', 'P_same_binary', 'P_same_binary_expected_studyprev', 'absdiff_score_median', 'n_pairs']
t1 = dec.melt(id_vars=['window', 'panel', 'grouping', 'bin', 'stratum'], value_vars=keep, var_name='metric', value_name='value')
t1['section'] = 'decay'
b = bs.rename(columns={'median': 'boot_median', 'lo95': 'ci_lo95', 'hi95': 'ci_hi95'}); b['grouping'] = 'cluster bootstrap'; b['section'] = 'decay_bootstrap'
iso = sig[sig.tips == 'isolate tips'].copy()
uq = sig[sig.tips != 'isolate tips'].groupby(['window', 'set', 'tips', 'metric', 'null'], as_index=False)[['n_tips', 'n_positive', 'obs', 'null_mean', 'null_q025', 'null_q975', 'p_signal', 'SES']].median()
s = pd.concat([iso, uq], ignore_index=True)
rows = []
for r in s.itertuples():
    base = dict(section='phylo_signal', window=r.window, panel=r.set, grouping=r.tips, bin='', stratum=f'{r.null} label-permutation null')
    for m in ('obs', 'null_mean', 'null_q025', 'null_q975', 'p_signal', 'SES', 'n_tips'):
        rows.append({**base, 'metric': f'{r.metric}_{m}', 'value': getattr(r, m)})
t2 = pd.DataFrame(rows)
b2 = b.melt(id_vars=['section', 'window', 'panel', 'grouping', 'bin', 'stratum', 'metric', 'n_clusters'], value_vars=['boot_median', 'ci_lo95', 'ci_hi95'], var_name='stat')
b2['metric'] = b2.metric + '_' + b2.stat; b2 = b2.drop(columns='stat')
tidy = pd.concat([t1, b2, t2], ignore_index=True)
tidy['window_coords_Ecoli'] = tidy.window.map(coords)
tidy = tidy[['section', 'window', 'window_coords_Ecoli', 'panel', 'grouping', 'bin', 'stratum', 'metric', 'value', 'n_clusters']]
tidy.to_csv('out/r3_decay_signal_summary_tidy.csv', index=False)
dec.to_csv('out/r3_decay_all_windows.csv', index=False); bs.to_csv('out/r3_decay_bootstrap_all_windows.csv', index=False)
sig.to_csv('out/r3_signal_all_windows.csv', index=False)
# window description
wd = []
for w in WIN:
    for p in ('all', 'panel'):
        d = pd.read_csv(f'work/{w}_{p}_isolates.csv')
        wd.append(dict(window=w, coords=coords[w], panel=p, n_isolates=len(d), n_unique_fragments=d.uid.nunique(), n_studies=d.study.nunique(),
                       pct_inhibitory=100 * (d.Func == 'Inhibitory').mean(), median_frag_len=d.frag_len.median()))
wd = pd.DataFrame(wd); wd.to_csv('out/r3_window_sets.csv', index=False)
# headline wide tables
k = dec[(dec.stratum == 'between-study') & (((dec.grouping == 'differences')) | ((dec.grouping == 'identity') & (dec.bin == '>=99.5')))]
hk = k.pivot_table(index=['panel', 'window'], columns='bin', values='kappa_binary_vs_studyprev')[['0', '1', '2', '3', '4-5', '6-10', '11-20', '>20', '>=99.5']]
hp = k.pivot_table(index=['panel', 'window'], columns='bin', values='P_partner_inh_given_inh')[['0', '1', '2', '3', '4-5', '6-10', '11-20', '>20', '>=99.5']]
with pd.ExcelWriter('out/r3_decay_signal_tables.xlsx') as xw:
    pd.DataFrame({'sheet': ['windows', 'kappa_between_wide', 'Ppartner_between_wide', 'decay_long', 'bootstrap', 'signal', 'D_validation', 'tidy_summary'],
                  'content': ['isolate sets per window (all / fixed 1,397 panel)', 'between-study kappa vs study prevalence by differences bin (+ >=99.5% id)',
                              'between-study P(partner inhibitory | focal inhibitory)', 'all decay metrics, all strata/bins/panels',
                              'cluster bootstrap (2,000 reps) 0-difference and >=99.5% bins', 'D and tauD with global / within-study nulls',
                              'vectorised D vs caper::phylo.d check', 'tidy long summary']}).to_excel(xw, sheet_name='README', index=False)
    wd.to_excel(xw, sheet_name='windows', index=False); hk.round(4).to_excel(xw, sheet_name='kappa_between_wide'); hp.round(4).to_excel(xw, sheet_name='Ppartner_between_wide')
    dec.to_excel(xw, sheet_name='decay_long', index=False); bs.to_excel(xw, sheet_name='bootstrap', index=False); sig.to_excel(xw, sheet_name='signal', index=False)
    pd.read_csv('out/signal/D_validation_vs_caper.csv').to_excel(xw, sheet_name='D_validation', index=False); tidy.to_excel(xw, sheet_name='tidy_summary', index=False)
print(len(tidy), 'tidy rows'); print(wd.round(1).to_string(index=False))
