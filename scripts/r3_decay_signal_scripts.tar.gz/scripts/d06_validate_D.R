## Validate vectorised D (d05) against caper::phylo.d on the V4_254 panel unique-sequence tree, one random isolate each
suppressPackageStartupMessages(library(caper)); source("scripts/p2_signal_functions.R"); set.seed(2)
src <- readLines("scripts/d05_signal.R"); i1 <- grep("^prep_D <- ", src); i2 <- grep("^rowD <- ", src) - 1
eval(parse(text = src[i1:i2]))
d <- read.csv("work/V4_254_panel_isolates.csv", stringsAsFactors = FALSE)
tu <- midpoint.root(read.tree("work/V4_254_panel_unique.tre")); tu$edge.length[tu$edge.length < EPS] <- EPS
pick <- do.call(rbind, lapply(split(d, d$uid), function(g) g[sample.int(nrow(g), 1), ]))
PD <- prep_D(tu); pd <- pick[match(PD$phy$tip.label, pick$uid), ]; x <- as.integer(pd$Func == "Inhibitory")
r <- D_full(PD, x, pd$study, sim_bm(PD, 1000), 99)
df <- data.frame(tip = PD$phy$tip.label, inh = x)
rc <- phylo.d(comparative.data(PD$phy, df, names.col = "tip"), binvar = inh, permut = 1000)
v <- data.frame(impl = c("vectorised (d05)", "caper::phylo.d"), D = c(r$D, rc$DEstimate), obs_sumdiff = c(r$obs, rc$Parameters$Observed),
  mean_random = c(r$mean_random, rc$Parameters$MeanRandom), mean_brownian = c(r$mean_brownian, rc$Parameters$MeanBrownian),
  P_random = c(r$P_random, rc$Pval1), P_brownian = c(r$P_brownian, rc$Pval0))
print(v); write.csv(v, "out/signal/D_validation_vs_caper.csv", row.names = FALSE)
