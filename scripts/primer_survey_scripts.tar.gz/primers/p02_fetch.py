import requests, pandas as pd, os, time
from concurrent.futures import ThreadPoolExecutor
D=pd.read_csv('epmc_hits.csv'); ids=D.pmcid.dropna().unique()
def get(p):
    f=f'xml/{p}.xml'
    if os.path.exists(f) and os.path.getsize(f)>500: return p,'cached'
    for i in range(3):
        try:
            r=requests.get(f'https://www.ebi.ac.uk/europepmc/webservices/rest/{p}/fullTextXML',timeout=60)
            if r.status_code==200 and len(r.content)>500: open(f,'wb').write(r.content); return p,'ok'
            if r.status_code==404: return p,'404'
        except Exception as e: pass
        time.sleep(2)
    return p,'fail'
with ThreadPoolExecutor(4) as ex: res=list(ex.map(get,ids))
s=pd.Series([r[1] for r in res]).value_counts(); print(s.to_dict())
pd.DataFrame(res,columns=['pmcid','status']).to_csv('fetch_status.csv',index=False)
