"""Europe PMC search for amphibian skin microbiome amplicon studies; saves metadata for all hits."""
import requests, json, time, pandas as pd
Q=('(TITLE_ABS:(amphibian OR amphibians OR frog OR frogs OR salamander OR salamanders OR newt OR newts OR toad OR toads OR anuran OR anurans OR caecilian OR tadpole OR tadpoles) '
   'AND (skin OR cutaneous OR "skin microbiome" OR "skin microbiota" OR "skin bacteria" OR "skin bacterial") '
   'AND (microbiome OR microbiota OR "bacterial community" OR "bacterial communities" OR "bacterial assemblage" OR microbial)) '
   'AND ("16S" OR "16S rRNA" OR amplicon OR "high-throughput sequencing" OR illumina OR "454")')
rows=[]; cursor='*'
while True:
    r=requests.get('https://www.ebi.ac.uk/europepmc/webservices/rest/search',params={'query':Q,'format':'json','pageSize':1000,'cursorMark':cursor,'resultType':'core'},timeout=60).json()
    for x in r['resultList']['result']:
        rows.append(dict(id=x.get('id'),source=x.get('source'),pmcid=x.get('pmcid'),doi=x.get('doi'),title=x.get('title'),year=x.get('pubYear'),journal=(x.get('journalInfo') or {}).get('journal',{}).get('title'),
                         pubtype=';'.join((x.get('pubTypeList') or {}).get('pubType',[])),isOA=x.get('isOpenAccess'),inPMC=x.get('inPMC'),hasFT=x.get('hasTextMinedTerms'),
                         abstract=x.get('abstractText','')))
    nc=r.get('nextCursorMark')
    if not nc or nc==cursor or not r['resultList']['result']: break
    cursor=nc; time.sleep(0.3)
D=pd.DataFrame(rows).drop_duplicates('id'); D.to_csv('epmc_hits.csv',index=False)
print('hits',r.get('hitCount'),'rows',len(D),'with PMCID',D.pmcid.notna().sum(),'OA',(D.isOA=='Y').sum())
print(D.source.value_counts().to_dict()); print(D.pubtype.str.contains('review',case=False).sum(),'reviews'); print(D.year.value_counts().sort_index().to_dict())
