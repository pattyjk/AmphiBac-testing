"""Extract 16S primers / variable regions, target genes and platforms from Europe PMC full-text XML (Methods sections)."""
import re, os, pandas as pd, xml.etree.ElementTree as ET, itertools, collections
D = pd.read_csv('epmc_hits.csv')
IUPAC = {'A':'A','C':'C','G':'G','T':'T','U':'T','R':'AG','Y':'CT','S':'CG','W':'AT','K':'GT','M':'AC','B':'CGT','D':'AGT','H':'ACT','V':'ACG','N':'ACGT','I':'ACGT'}
# (name, sequence 5'->3', E. coli position of 5' end, orientation, canonical label)
CAT = [
 ('8F/27F','AGAGTTTGATCMTGGCTCAG',8,'F'), ('27F-YM','AGAGTTTGATYMTGGCTCAG',8,'F'),
 ('68F','TNANACATGCAAGTCGRRCG',49,'F'),
 ('338F/357F','ACTCCTACGGGAGGCAGCAG',338,'F'), ('341F','CCTACGGGNGGCWGCAG',341,'F'), ('341F-B','CCTAYGGGRBGCASCAG',341,'F'),
 ('515F','GTGCCAGCMGCCGCGGTAA',515,'F'), ('515F-Y','GTGYCAGCMGCCGCGGTAA',515,'F'),
 ('799F','AACMGGATTAGATACCCKG',799,'F'), ('967F','CAACGCGAAGAACCTTACC',967,'F'),('1114F','GCAACGAGCGCAACCC',1114,'F'),
 ('338R','GCTGCCTCCCGTAGGAGT',338,'R'), ('518R/534R','ATTACCGCGGCTGCTGG',518,'R'),
 ('785R/805R','GACTACHVGGGTATCTAATCC',785,'R'), ('806R','GGACTACHVGGGTWTCTAAT',806,'R'), ('806R-B','GGACTACNVGGGTWTCTAAT',806,'R'),
 ('907R','CCGTCAATTCMTTTRAGTTT',907,'R'), ('926R','CCGYCAATTYMTTTRAGTTT',926,'R'),
 ('1046R','CGACAGCCATGCANCACCT',1046,'R'), ('1193R','ACGTCATCCCCACCTTCC',1193,'R'), ('1391R','GACGGGCGGTGTGTRCA',1391,'R'), ('1492R','GGTTACCTTGTTACGACTT',1492,'R'),
]
def cls(c): return '['+IUPAC.get(c,'ACGT')+']'
def pat(seq, core=15):
    s = seq[-core:]  # 3' core is the most conserved part reported
    return re.compile(''.join(cls(c) for c in s))
def matchseq(txt_seq, prim):
    # text sequence (may contain IUPAC) matches primer if every position is compatible
    p = prim[-15:]; t = txt_seq
    for i in range(0, len(t)-len(p)+1):
        if all(set(IUPAC.get(a,'ACGT')) & set(IUPAC.get(b,'ACGT')) for a,b in zip(t[i:i+len(p)], p)): return True
    return False
NAME_RX = [(r'\b(?:515F|515f|F515|515-F|515\s?F)\b','515F'),(r'\b(?:806R|806r|R806|806-R|806\s?R)\b','806R'),(r'\b(?:341F|341f|F341|338F|338f|357F)\b','341F/338F'),
 (r'\b(?:785R|805R|806RB|R805|785r|805r)\b','785R/805R'),(r'\b(?:27F|27f|8F|8f|F27)\b','27F'),(r'\b(?:1492R|1492r|1391R|1391r)\b','1391R/1492R'),
 (r'\b(?:926R|907R|909R|926r|907r)\b','907R/926R'),(r'\b(?:799F|799f|1193R|1193r)\b','799F/1193R'),(r'\b(?:518R|534R|533R|519R)\b','518R/534R'),
 (r'\b(?:967F|1046R|1061R|1064R)\b','V6 primers'),(r'\b(?:1114F|1392R)\b','V8 primers')]
REG_RX = re.compile(r'\bV\s?([1-9])\s?(?:(?:-|–|—|to|and|/|\+)\s?V?\s?([1-9]))?\b(?:\s|-)?(?:hyper)?\s?(?:variable\s)?(?:region|regions|domain|hypervariable)?', re.I)
PLAT = [('Illumina',r'illumina|miseq|hiseq|novaseq|nextseq|iseq'),('454',r'\b454\b|pyrosequenc|gs flx|titanium'),('Ion Torrent',r'ion torrent|ion pgm|ion s5|ion personal'),
        ('PacBio',r'pacbio|pacific biosciences|sequel'),('Nanopore',r'nanopore|minion|gridion|promethion'),('Sanger/clone library',r'clone librar|sanger sequencing|cloning'),('DGGE/T-RFLP',r'dgge|t-rflp|trflp|arisa')]
TARG = [('16S',r'16s'),('ITS',r'\bits\s?[12]?\b|its1f|its86f|its4|internal transcribed spacer'),('18S',r'\b18s\b'),('shotgun metagenome',r'shotgun|metagenom'),('16S full-length',r'full-length 16s|full length 16s|near-full-length')]
def text_parts(path):
    root = ET.parse(path).getroot()
    def tx(e): return ' '.join(''.join(e.itertext()).split())
    body = root.find('.//body')
    meth = []
    if body is not None:
        for sec in body.iter('sec'):
            t = sec.find('title'); st = (sec.get('sec-type') or '') + ' ' + (tx(t) if t is not None else '')
            if re.search(r'method|material|procedure|sequenc|experimental|library|molecular|dna extraction|amplicon', st, re.I): meth.append(tx(sec))
    full = tx(body) if body is not None else ''
    supp = ' '.join(tx(s) for s in root.iter('supplementary-material'))
    return ' '.join(dict.fromkeys(meth)), full
SEQ_RX = re.compile(r"(?:5[′'’]?\s*-?\s*)?([ACGTURYSWKMBDHVNI]{15,30})(?:\s*-?\s*3[′'’]?)?")
rows = []
for _, r in D.iterrows():
    p = r.pmcid; f = f'xml/{p}.xml' if isinstance(p,str) else None
    rec = dict(id=r.id, pmcid=p, doi=r.doi, year=r.year, title=r.title, has_xml=bool(f and os.path.exists(f)))
    if rec['has_xml']:
        meth, full = text_parts(f); txt = meth if len(meth) > 300 else full; rec['text_scope'] = 'methods' if len(meth) > 300 else 'full body'
    else:
        txt = str(r.abstract) if isinstance(r.abstract,str) else ''; rec['text_scope'] = 'abstract'
    low = txt.lower()
    # sequences
    seqs = set(m.group(1).upper().replace('U','T') for m in SEQ_RX.finditer(txt.replace(' ','') if False else txt))
    seqhits = sorted(set(nm for nm, s, _, _ in CAT for t in seqs if matchseq(t, s)))
    rec['primer_seq_hits'] = ';'.join(seqhits)
    rec['primer_name_hits'] = ';'.join(sorted(set(lab for rx, lab in NAME_RX if re.search(rx, txt))))
    regs = set()
    for m in REG_RX.finditer(txt):
        a, b = m.group(1), m.group(2)
        ctx = txt[max(0,m.start()-60):m.end()+60].lower()
        if not re.search(r'16s|region|hypervariable|primer|amplif|rrna|rdna', ctx): continue
        regs.add(f'V{a}' if not b or b == a else f'V{a}-V{b}')
    rec['region_mentions'] = ';'.join(sorted(regs))
    rec['platforms'] = ';'.join(nm for nm, rx in PLAT if re.search(rx, low))
    rec['targets'] = ';'.join(nm for nm, rx in TARG if re.search(rx, low))
    rows.append(rec)
X = pd.DataFrame(rows)
# region call: sequences first, then names, then explicit region
F = {nm:(pos,o) for nm,_,pos,o in CAT}
def region_from_primers(names):
    fw = sorted(F[n][0] for n in names if n in F and F[n][1]=='F'); rv = sorted(F[n][0] for n in names if n in F and F[n][1]=='R')
    pairs=set()
    def reg(a,b):
        V={'V1':(69,99),'V2':(137,242),'V3':(433,497),'V4':(576,682),'V5':(822,879),'V6':(986,1043),'V7':(1117,1173),'V8':(1243,1294),'V9':(1435,1465)}
        inside=[k for k,(s,e) in V.items() if s>=a-20 and e<=b+20]
        return (inside[0] if len(inside)==1 else f'{inside[0]}-{inside[-1]}') if inside else None
    for a in fw:
        bs=[b for b in rv if b>a]
        if bs: pairs.add(reg(a,min(bs)))
    return sorted(p for p in pairs if p)
NM2SEQ = {'515F':['515F'],'806R':['806R'],'341F/338F':['341F'],'785R/805R':['785R/805R'],'27F':['8F/27F'],'1391R/1492R':['1492R'],'907R/926R':['926R'],'799F/1193R':['799F','1193R'],'518R/534R':['518R/534R'],'V6 primers':['967F','1046R'],'V8 primers':['1114F','1391R']}
calls=[]; how=[]
for _, r in X.iterrows():
    s = [x for x in r.primer_seq_hits.split(';') if x]
    c = region_from_primers(s); h = 'primer sequences'
    if not c:
        n = [y for x in r.primer_name_hits.split(';') if x for y in NM2SEQ.get(x,[])]
        c = region_from_primers(n); h = 'primer names'
    if not c and r.region_mentions:
        c = [x for x in r.region_mentions.split(';')]; h = 'region named in text'
    calls.append(';'.join(c)); how.append(h if c else '')
X['region_call'] = calls; X['region_evidence'] = how
X.to_csv('primer_extraction.csv', index=False)
print(X.text_scope.value_counts().to_dict()); print('with region call', (X.region_call!='').sum(), X.region_evidence.value_counts().to_dict())
