"""Score all methods (env vsearch: needs scikit-learn) on identical held-out isolates (LOSO). Env: placement or vsearch (pandas, numpy, scipy, sklearn optional).
Outputs results/per_isolate_predictions.csv, results/metrics_tidy.csv, results/paired_diffs.csv, results/nsti_strata.csv,
results/abstention.csv, results/calibration.csv"""
import numpy as np, pandas as pd
from scipy import stats
rng = np.random.default_rng(20261030); B = 500
t = pd.read_csv('ref/tip_table.csv').set_index('FastaID')
g = pd.read_csv('v5f91e1d1_genus_assignments.csv').set_index('FastaID')
fi = pd.read_csv('frags/fragment_index.csv')
tp = pd.read_csv('gp/tree_preds.csv'); bp = pd.read_csv('base/baseline_preds.csv')
d = tp.merge(bp.drop(columns=['study']), on=['FastaID', 'window'], how='inner')
d = d.merge(fi[['window', 'FastaID', 'panel_all10']], on=['window', 'FastaID'], how='left')
d['y'] = (t.Func.reindex(d.FastaID).values == 'Inhibitory').astype(int)
d['Func'] = t.Func.reindex(d.FastaID).values; d['score'] = t.score.reindex(d.FastaID).values
d['in_tree'] = t.in_tree.reindex(d.FastaID).values; d['genus'] = g.genus_full.reindex(d.FastaID).values
# genus majority + fold prior (training = tested isolates of all other studies)
tt = t.copy(); tt['study'] = tt.Reference.astype(str); tt['genus'] = g.genus_full.reindex(tt.index); tt['inh'] = (tt.Func == 'Inhibitory').astype(int)
pg, prior = [], {}
for s, sub in d.groupby('study'):
    tr = tt[tt.study != s]; prior[s] = tr.inh.mean()
    gm = tr.dropna(subset=['genus']).groupby('genus').inh.mean()
    pg.append(pd.Series(sub.genus.map(gm).values, index=sub.index))
d['P_genus_raw'] = pd.concat(pg); d['prior'] = d.study.map(prior)
d['genus_known'] = d.P_genus_raw.notna()
d['P_genus'] = d.P_genus_raw.fillna(d.prior)
d['P_R1'] = d.R1_pred.astype(float); d['P_R2'] = d.R2_pred.astype(float)
d['P_R4'] = d.R4_frac.fillna(d.prior)
METHODS = {'R1 top hit 99%': 'P_R1', 'R2 any Inhibitory hit': 'P_R2', 'R4 majority full-cov hits': 'P_R4', 'Genus majority': 'P_genus',
           'M1 nearest tip (LWR vote)': 'P_M1', 'M1 nearest tip (top placement)': 'P_M1top',
           'M2 max parsimony': 'P_M2_mp', 'M2 empirical prob.': 'P_M2_emp_prob', 'M2 subtree average': 'P_M2_subtree_average',
           'M2 Mk (AIC ER/ARD)': 'P_M2_mk', 'M2 Mk, attachment point': 'P_M2_mk_att', 'M3 BM': 'P_BM', 'M3 BM+residual': 'P_BMe', 'M3 OU': 'P_OU', 'M3 OU+residual': 'P_OUe',
           'M4 phylo+study GP': 'P_M4s', 'M4 phylo+study+genotype GP': 'P_M4',
           'M3 BM+residual (Platt)': 'Pc_BMe', 'M3 OU+residual (Platt)': 'Pc_OUe',
           'M4 phylo+study GP (Platt)': 'Pc_M4s', 'M4 phylo+study+genotype GP (Platt)': 'Pc_M4'}
# Platt mapping P = logistic(a + b*mu), fitted per held-out study on the LOSO predictions of the other studies only
from sklearn.linear_model import LogisticRegression
for m in ['BMe', 'OUe', 'M4s', 'M4']:
    for w in d.window.unique():
        dw = d[d.window == w]
        for s in dw.study.unique():
            o = dw.study != s
            lr = LogisticRegression(C=1e6).fit(dw.loc[o, ['mu_' + m]].values / 100, dw.y[o].values)
            d.loc[dw.index[~o], 'Pc_' + m] = lr.predict_proba(dw.loc[~o, ['mu_' + m]].values / 100)[:, 1]
SCORECOL = {'Pc_BMe': 'mu_BMe', 'Pc_OUe': 'mu_OUe', 'Pc_M4s': 'mu_M4s', 'Pc_M4': 'mu_M4', 'P_BM': 'mu_BM', 'P_BMe': 'mu_BMe', 'P_OU': 'mu_OU', 'P_OUe': 'mu_OUe', 'P_M4s': 'mu_M4s', 'P_M4': 'mu_M4'}
# hard predictions at 0.5 (R1/R2 binary; R4 uses its rule: no hits -> not inhibitory)
for m, c in METHODS.items():
    d['H05_' + c] = (d[c] > 0.5).astype(int)
d['H05_P_R4'] = d.R4_pred.astype(int)
# training-fold threshold maximising balanced accuracy (pooled LOSO predictions of the other studies)
def bal_acc(y, h):
    tp_ = ((h == 1) & (y == 1)).sum(); tn = ((h == 0) & (y == 0)).sum(); p = (y == 1).sum(); n = (y == 0).sum()
    return 0.5 * (tp_ / p if p else np.nan) + 0.5 * (tn / n if n else np.nan)
grid = np.round(np.arange(0.02, 0.99, 0.02), 2)
thr_rows = []
for w in d.window.unique():
    dw = d[d.window == w]
    for m, c in METHODS.items():
        if c in ('P_R1', 'P_R2'):
            d.loc[dw.index, 'HT_' + c] = dw[c].astype(int); continue
        P = dw[c].values; Y = dw.y.values; S = dw.study.values
        for s in np.unique(S):
            o = S != s
            bas = [bal_acc(Y[o], (P[o] > th).astype(int)) for th in grid]
            th = grid[int(np.nanargmax(bas))]; thr_rows.append(dict(window=w, method=m, study=s, thr=th))
            d.loc[dw.index[S == s], 'HT_' + c] = (P[S == s] > th).astype(int)
pd.DataFrame(thr_rows).to_csv('results/tuned_thresholds.csv', index=False)
def kappa(y, h):
    n = len(y); po = (y == h).mean(); pe = y.mean() * h.mean() + (1 - y.mean()) * (1 - h.mean())
    return (po - pe) / (1 - pe) if pe < 1 else np.nan
def auc(y, p):
    if y.min() == y.max(): return np.nan
    r = stats.rankdata(p); n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def metrics(df, c):
    y = df.y.values; p = df[c].values; h = df['H05_' + c].values; ht = df['HT_' + c].values
    sc = df.score.values; cs = SCORECOL.get(c, c); ok = ~np.isnan(sc)
    return dict(kappa05=kappa(y, h), kappa_tuned=kappa(y, ht), bal_acc05=bal_acc(y, h), bal_acc_tuned=bal_acc(y, ht),
                acc05=(y == h).mean(), sens05=h[y == 1].mean(), spec05=1 - h[y == 0].mean(),
                AUC=auc(y, p), Brier=np.mean((p - y) ** 2),
                spearman=stats.spearmanr(df[cs].values[ok], sc[ok])[0] if ok.sum() > 10 else np.nan)
KEYS = ['kappa05', 'kappa_tuned', 'bal_acc05', 'bal_acc_tuned', 'acc05', 'sens05', 'spec05', 'AUC', 'Brier', 'spearman']
rows, prow = [], []
for w in d.window.unique():
    for setname in ['all', 'panel']:
        dd = d[(d.window == w) & ((setname == 'all') | (d.panel_all10 == True))].reset_index(drop=True)
        studies = dd.study.unique(); grp = {s: np.where(dd.study.values == s)[0] for s in studies}
        boots = [np.concatenate([grp[s] for s in rng.choice(studies, len(studies))]) for _ in range(B)]
        pt = {m: metrics(dd, c) for m, c in METHODS.items()}
        bt = {m: [] for m in METHODS}
        for bi in boots:
            db = dd.iloc[bi]
            for m, c in METHODS.items(): bt[m].append(metrics(db, c))
        for m in METHODS:
            bdf = pd.DataFrame(bt[m])
            for k in KEYS:
                rows.append(dict(window=w, set=setname, method=m, metric=k, value=pt[m][k],
                                 lo=np.nanpercentile(bdf[k], 2.5), hi=np.nanpercentile(bdf[k], 97.5),
                                 n=len(dd), n_studies=len(studies), n_inhib=int(dd.y.sum())))
            for ref in ['Genus majority', 'R4 majority full-cov hits']:
                if m == ref: continue
                rdf = pd.DataFrame(bt[ref])
                for k in ['kappa05', 'kappa_tuned', 'AUC', 'Brier', 'spearman']:
                    diff = bdf[k] - rdf[k]
                    prow.append(dict(window=w, set=setname, method=m, vs=ref, metric=k, diff=pt[m][k] - pt[ref][k],
                                     lo=np.nanpercentile(diff, 2.5), hi=np.nanpercentile(diff, 97.5), p_le0=np.nanmean(diff <= 0)))
        print(w, setname, len(dd), flush=True)
pd.DataFrame(rows).to_csv('results/metrics_tidy.csv', index=False)
pd.DataFrame(prow).to_csv('results/paired_diffs.csv', index=False)
# NSTI strata, abstention, calibration (all isolates)
bins = [-1, 0.0005, 0.01, 0.05, 0.1, 100]; blab = ['~0 (<0.0005)', '0.0005-0.01', '0.01-0.05', '0.05-0.1', '>0.1']
d['nsti_bin'] = pd.cut(d.nsti_top, bins, labels=blab)
srows, arows, crows = [], [], []
for w in d.window.unique():
    for setname in ['all', 'panel']:
        dd = d[(d.window == w) & ((setname == 'all') | (d.panel_all10 == True))]
        for m, c in METHODS.items():
            for b, sub in dd.groupby('nsti_bin', observed=True):
                mm = metrics(sub, c) if len(sub) > 5 else {}
                srows.append(dict(window=w, set=setname, method=m, nsti_bin=b, n=len(sub), n_studies=sub.study.nunique(),
                                  frac_inhib=sub.y.mean(), **mm))
            for crit in ['nsti', 'confidence']:
                key = dd.nsti_top.values if crit == 'nsti' else -np.abs(dd[c].values - 0.5)
                o = np.lexsort((rng.random(len(key)), key));  # ties (e.g. NSTI at EPA-ng's 1e-4 pendant floor) broken at random
                y = dd.y.values[o]; h = dd['H05_' + c].values[o]; p = dd[c].values[o]
                for cov in np.round(np.arange(0.1, 1.01, 0.05), 2):
                    k = max(int(round(cov * len(o))), 1)
                    arows.append(dict(window=w, set=setname, method=m, criterion=crit, coverage=cov, n=k,
                                      threshold=float(np.sort(key)[k - 1]) if crit == 'nsti' else float(0.5 - np.sort(key)[k - 1]),
                                      accuracy=(y[:k] == h[:k]).mean(), kappa=kappa(y[:k], h[:k]), bal_acc=bal_acc(y[:k], h[:k]),
                                      AUC=auc(y[:k], p[:k]), frac_inhib=y[:k].mean()))
            if setname == 'all':
                cb = pd.cut(dd[c], np.linspace(0, 1, 11), include_lowest=True)
                for b, sub in dd.groupby(cb, observed=True):
                    crows.append(dict(window=w, method=m, bin=str(b), p_mean=sub[c].mean(), obs=sub.y.mean(), n=len(sub)))
pd.DataFrame(srows).to_csv('results/nsti_strata.csv', index=False)
pd.DataFrame(arows).to_csv('results/abstention.csv', index=False)
pd.DataFrame(crows).to_csv('results/calibration.csv', index=False)
d.to_csv('results/per_isolate_predictions.csv', index=False)
print('done', len(d))
