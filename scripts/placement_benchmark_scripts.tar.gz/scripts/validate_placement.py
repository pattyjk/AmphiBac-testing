"""Validation of the AmphiBac reference package: (1) place 300 random isolate V4 / V3-V4 fragments into the
full tree; (2) leave-one-study-out placement for two studies (prune study tips, re-place their V4 fragments)."""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(__file__)); import placement_lib as P
import numpy as np, pandas as pd
from Bio import SeqIO
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
REF = 'ref'; TH = int(os.environ.get('TH', 10))
tips = pd.read_csv(f'{REF}/tip_table.csv'); tips = tips[tips.in_tree]
genus = dict(zip(tips.FastaID, tips.genus_full)); func = dict(zip(tips.FastaID, tips.Func))
MODEL = f'{REF}/ref_model.txt'; TREE = f'{REF}/ref_tree.nwk'; MSA = f'{REF}/ref_msa.fasta'; CM = f'{REF}/RF00177.cm'

def topo_dist_factory(jplace):
    J = json.load(open(jplace))
    parent, blen, enum, label, children, is_leaf = P._parse_jplace_tree(J['tree'])
    depth = np.zeros(len(parent), int)
    order = [0]; i = 0
    while i < len(order):
        v = order[i]; i += 1
        for c in children[v]: depth[c] = depth[v] + 1; order.append(c)
    lab2 = {l: k for k, l in enumerate(label) if l}
    e2n = {e: k for k, e in enumerate(enum) if e >= 0}
    def dist(edge, tiplab):  # edges between child node of placement edge and the tip
        a, b = e2n[edge], lab2[tiplab]; d = 0
        while a != b:
            if depth[a] >= depth[b]: a = parent[a]
            else: b = parent[b]
            d += 1
        return d
    return dist

def annotate(df, jplace, window, self_in_tree=True):
    frag = {r.id: str(r.seq) for r in SeqIO.parse(f'frags/{window}.fasta', 'fasta')}
    ts = P.edge_tipsets(jplace)
    out = []
    dist = topo_dist_factory(jplace) if self_in_tree else None
    for r in df.itertuples():
        g = genus.get(r.query); clade = ts[r.edge_num]
        cg = pd.Series([genus.get(x) for x in clade]).dropna()
        d = dict(query=r.query, window=window, lwr=r.lwr, pendant=r.pendant_length, nsti=r.nsti,
                 nearest_tip=r.nearest_tip, clade_size=len(clade), query_genus=g,
                 nearest_tip_genus=genus.get(r.nearest_tip), query_func=func.get(r.query),
                 nearest_tip_func=func.get(r.nearest_tip),
                 clade_genus_majority=cg.mode().iloc[0] if len(cg) else None,
                 clade_genus_pure=(len(cg) > 0 and (cg == g).all()))
        if self_in_tree:
            d['own_edge'] = r.edge_child == r.query
            d['identical_frag_edge'] = r.edge_child is not None and frag.get(r.edge_child) == frag[r.query]
            d['own_in_clade'] = r.query in clade
            d['topo_dist_to_own_tip'] = dist(r.edge_num, r.query)
        out.append(d)
    return pd.DataFrame(out)

if __name__ == '__main__':
    os.makedirs('val', exist_ok=True); rt = []
    res = []
    for w in ['V4_254', 'V3V4_429']:
        t = P.run_epa(TREE, MSA, f'val/q300_{w}.afa', MODEL, f'val/epa_full_{w}', threads=TH)
        jp = f'val/epa_full_{w}/epa_result.jplace'
        df = P.parse_jplace(jp); rt.append(dict(task=f'full_tree_300_{w}', epa_s=t))
        res.append(annotate(df, jp, w)); print(w, 'epa', round(t, 1), 's', flush=True)
    pd.concat(res).to_csv('val/val300_full_tree.csv', index=False)
    # leave-one-study-out
    studies = sys.argv[1:] or ['10.1111/mec.13135', '10.1038/s41396-019-0388-x']
    frag = {r.id: str(r.seq) for r in SeqIO.parse('frags/V4_254.fasta', 'fasta')}
    lres = []
    for k, s in enumerate(studies):
        ids = tips.FastaID[tips.Reference == s].tolist(); q = [i for i in ids if i in frag]
        d = f'val/loso_{k}'; os.makedirs(d, exist_ok=True)
        t0 = time.time(); n = P.prune_reference(TREE, MSA, ids, f'{d}/tree.nwk', f'{d}/msa.fasta'); tp = time.time() - t0
        with open(f'{d}/q.fasta', 'w') as fh:
            for i in q: fh.write(f'>{i}\n{frag[i]}\n')
        ta, _ = P.align_queries(f'{d}/q.fasta', f'{d}/q.afa', CM, threads=TH)
        te = P.run_epa(f'{d}/tree.nwk', f'{d}/msa.fasta', f'{d}/q.afa', MODEL, f'{d}/epa', threads=TH)
        jp = f'{d}/epa/epa_result.jplace'
        a = annotate(P.parse_jplace(jp), jp, 'V4_254', self_in_tree=False); a['study'] = s; lres.append(a)
        rt.append(dict(task=f'LOSO_{s}', n_removed=len(ids), n_ref_left=n, n_query=len(q), prune_s=tp, align_s=ta, epa_s=te))
        print(s, len(ids), 'removed', n, 'left; prune', round(tp, 1), 'align', round(ta, 1), 'epa', round(te, 1), flush=True)
    pd.concat(lres).to_csv('val/val_loso.csv', index=False)
    pd.DataFrame(rt).to_csv('val/runtimes.csv', index=False)
