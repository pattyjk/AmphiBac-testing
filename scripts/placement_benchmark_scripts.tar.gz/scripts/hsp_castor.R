# Hidden-state prediction (castor) of binary Inhibitory on a (pruned) reference tree.
# Usage: Rscript hsp_castor.R tree.nwk tipstates.csv out_prefix   (env rcastor, castor in ./Rlib)
suppressMessages({library(ape); library(castor, lib.loc = "Rlib"); library(jsonlite)})
a <- commandArgs(TRUE)
tr <- read.tree(a[1]); ts <- read.csv(a[2], stringsAsFactors = FALSE)
st <- ts$state[match(tr$tip.label, ts$label)]          # 1 = not inhibitory, 2 = inhibitory, NA = unknown
if (any(is.na(st))) stop("missing tip states")
tr$edge.length[tr$edge.length <= 0] <- 1e-8
labs <- c(tr$tip.label, tr$node.label)
res <- data.frame(label = labs)
t0 <- Sys.time()
mp <- hsp_max_parsimony(tr, st, Nstates = 2, transition_costs = "all_equal", weight_by_scenarios = TRUE)
res$mp <- mp$likelihoods[, 2]
ep <- hsp_empirical_probabilities(tr, st, Nstates = 2)
res$emp_prob <- ep$likelihoods[, 2]
sa <- hsp_subtree_averaging(tr, as.numeric(st == 2))
res$subtree_average <- sa$states
fits <- list()
for (rm in c("ER", "ARD")) {
  f <- hsp_mk_model(tr, st, Nstates = 2, rate_model = rm, root_prior = "empirical", Ntrials = 2, Nthreads = 2)
  res[[paste0("mk_", rm)]] <- f$likelihoods[, 2]
  fits[[rm]] <- list(loglik = f$loglikelihood, Q = f$transition_matrix, k = ifelse(rm == "ER", 1, 2),
                     AIC = -2 * f$loglikelihood + 2 * ifelse(rm == "ER", 1, 2))
}
best <- ifelse(fits$ER$AIC <= fits$ARD$AIC, "ER", "ARD")
res$mk <- res[[paste0("mk_", best)]]
fits$best <- best; fits$sec <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
write.csv(res, paste0(a[3], "_hsp.csv"), row.names = FALSE)
write(toJSON(fits, auto_unbox = TRUE, digits = 10), paste0(a[3], "_mk.json"))
cat(best, fits$ER$AIC, fits$ARD$AIC, fits$sec, "\n")
