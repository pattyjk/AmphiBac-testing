"""Tree arrays, tree covariance, exact GP prediction at placement points, castor HSP glue.
All prediction is done on the jplace (pruned reference) tree of each fold, rooted at its basal trifurcation."""
import json, os, subprocess, numpy as np, pandas as pd
from scipy import linalg, optimize, stats
import placement_lib as P

class Tree:
    def __init__(self, jplace=None, newick=None):
        if jplace is not None: J = json.load(open(jplace))
        else: J = {'tree': open(newick).read().strip(), 'placements': [], 'fields': []}
        self.J = J
        (self.parent, self.blen, self.enum, self.label, self.children, self.is_leaf) = P._parse_jplace_tree(J['tree'])
        N = len(self.parent); self.N = N
        order = []; st = [0]
        while st:
            v = st.pop(); order.append(v); st.extend(reversed(self.children[v]))
        self.order = order
        self.depth = np.zeros(N)
        for v in order:
            if self.parent[v] >= 0: self.depth[v] = self.depth[self.parent[v]] + self.blen[v]
        # contiguous tip ranges in preorder
        self.tips = [v for v in order if self.is_leaf[v]]
        pos = {v: i for i, v in enumerate(self.tips)}
        self.lo = np.zeros(N, int); self.hi = np.zeros(N, int)
        for v in reversed(order):
            if self.is_leaf[v]: self.lo[v] = pos[v]; self.hi[v] = pos[v] + 1
            else:
                self.lo[v] = min(self.lo[c] for c in self.children[v]); self.hi[v] = max(self.hi[c] for c in self.children[v])
        self.tip_labels = [self.label[v] for v in self.tips]
        self.e2node = {e: k for k, e in enumerate(self.enum) if e >= 0}

    def cov(self):
        """C[i,j] = depth of MRCA (shared root path), tips in preorder."""
        n = len(self.tips); C = np.empty((n, n))
        for v in self.order:
            ch = self.children[v]
            if not ch: C[self.lo[v], self.lo[v]] = self.depth[v]; continue
            d = self.depth[v]
            for a in range(len(ch)):
                for b in range(a + 1, len(ch)):
                    A = slice(self.lo[ch[a]], self.hi[ch[a]]); B = slice(self.lo[ch[b]], self.hi[ch[b]])
                    C[A, B] = d; C[B, A] = d
        return C

    def newick(self):
        """Newick with internal nodes labelled n<idx>."""
        out = {}
        for v in reversed(self.order):
            if self.is_leaf[v]: s = self.label[v]
            else: s = '(' + ','.join(out.pop(c) for c in self.children[v]) + f')n{v}'
            if self.parent[v] >= 0: s += f':{self.blen[v]:.10g}'
            out[v] = s
        return out[0] + ';'

    def placements(self, min_lwr=0.01):
        """All placements with LWR >= min_lwr (top always kept), renormalised; attachment geometry."""
        f = self.J['fields']; rows = []
        for pl in self.J['placements']:
            names = [x if isinstance(x, str) else x[0] for x in pl.get('n', pl.get('nm', []))]
            Pp = sorted([dict(zip(f, p)) for p in pl['p']], key=lambda d: -d['like_weight_ratio'])
            keep = [p for k, p in enumerate(Pp) if k == 0 or p['like_weight_ratio'] >= min_lwr]
            tot = sum(p['like_weight_ratio'] for p in keep)
            for k, p in enumerate(keep):
                c = self.e2node[p['edge_num']]; L = self.blen[c]
                x = min(max(p['distal_length'], 0.0), L)
                for q in names:
                    rows.append(dict(query=q, rank=k, w=p['like_weight_ratio'] / tot, lwr=p['like_weight_ratio'],
                                     child=c, par=self.parent[c], L=L, distal=x, pendant=p['pendant_length'],
                                     att_depth=self.depth[c] - x))
        return pd.DataFrame(rows)

def cov_rows(T, C, pl, train_pos):
    """Covariance (BM, unit rate) between placement points and training tips (positions in T.tips order).
    For tips inside subtree(child): depth of attachment point; outside: C[t, i] with t any tip under child."""
    tp = np.asarray(train_pos); K = np.empty((len(pl), len(tp)))
    for r, (c, a) in enumerate(zip(pl.child.values, pl.att_depth.values)):
        row = C[T.lo[c], tp].copy()
        inside = (tp >= T.lo[c]) & (tp < T.hi[c]); row[inside] = a
        K[r] = row
    return K

# ---------------- Gaussian models ----------------
def build_K(theta, model, Cs, Zs, n):
    """theta: dict of variances. model 'M4': sp2*C + sum_k s_k^2 Z_k Z_k' + se2 I; 'BM': sp2*C + jitter;
    'OU': s2*exp(-alpha*D) (Cs = D); 'BMe': sp2*C + se2*I."""
    if model == 'OU':
        K = theta['s2'] * np.exp(-theta['alpha'] * Cs)
    else:
        K = theta['sp2'] * Cs
    for k, Z in Zs.items():
        if k in theta: K = K + theta[k] * (Z @ Z.T)
    K = K + (theta.get('se2', 0.0) + theta.get('jit', 0.0)) * np.eye(n)
    return K

def reml(y, K):
    n = len(y); X = np.ones((n, 1))
    try: L = linalg.cholesky(K, lower=True, check_finite=False)
    except linalg.LinAlgError: return 1e30, None
    Ki_y = linalg.cho_solve((L, True), y, check_finite=False); Ki_X = linalg.cho_solve((L, True), X, check_finite=False)
    XKX = X.T @ Ki_X; beta = np.linalg.solve(XKX, X.T @ Ki_y)
    r = y - X @ beta; Ki_r = linalg.cho_solve((L, True), r, check_finite=False)
    ld = 2 * np.log(np.diag(L)).sum()
    nll = 0.5 * (ld + np.log(np.linalg.det(XKX)) + r @ Ki_r + (n - 1) * np.log(2 * np.pi))
    return nll, dict(L=L, beta=float(beta[0]), Ki_r=Ki_r)

def gp_predict(fit, Kq, var_q):
    """mean = beta + Kq Ki r; var = var_q - diag(Kq K^-1 Kq') (exact; GLS-mean uncertainty ignored)."""
    mean = fit['beta'] + Kq @ fit['Ki_r']
    V = linalg.solve_triangular(fit['L'], Kq.T, lower=True, check_finite=False)
    var = var_q - (V * V).sum(0)
    return mean, np.maximum(var, 1e-9)
