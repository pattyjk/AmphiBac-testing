"""Step 3 baselines on the same LOSO folds (env vsearch).
R1: q2-vsearch default call (first hit, --id 0.99) against FullDatabase minus held-out study -> Func of hit.
R2: same call against Inhibitory subset minus held-out study -> any hit = Inhibitory.
R4: exhaustive (--maxaccepts 0 --maxrejects 0) >=99% hits to tested isolates of other studies, full query coverage
    (qilo==1 & qihi==ql) -> fraction Inhibitory; majority (>0.5) = Inhibitory.
Usage: python scripts/02_baselines_vsearch.py THREADS [WINDOWS comma-sep] [--parse-only]
vsearch outputs per fold are reused if present (resumable)."""
import sys, os, subprocess
import pandas as pd
from Bio import SeqIO
TH = sys.argv[1] if len(sys.argv) > 1 else '6'
aud = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
ref = aud.Reference.astype(str)
folds = pd.read_csv('loso/folds.csv')
full = {r.id: str(r.seq) for r in SeqIO.parse('db/FullDatabase_2025.1.fasta', 'fasta')}
inh = {r.id: str(r.seq) for r in SeqIO.parse('db/Inhibitory_2025.1.fasta', 'fasta')}
tested = set(aud.index[aud.Func.isin(['Inhibitory', 'NoEffect', 'Facilitating'])])
def wfa(path, d, keep):
    with open(path, 'w') as fh:
        for k in keep: fh.write(f'>{k}\n{d[k]}\n')
def uc_hits(path):
    try: u = pd.read_csv(path, sep='\t', header=None, dtype=str)
    except pd.errors.EmptyDataError: return {}
    u = u[u[0] == 'H']; return dict(zip(u[8], u[9]))
WINS = sys.argv[2].split(',') if len(sys.argv) > 2 and not sys.argv[2].startswith('--') else ['V4_254', 'V3V4_429']
PARSE = '--parse-only' in sys.argv
rows = []
for w in WINS:
    q = {r.id: str(r.seq) for r in SeqIO.parse(f'frags/{w}.fasta', 'fasta')}
    for s, slug in zip(folds.study, folds.slug):
        ids = [i for i in q if ref.get(i) == s]
        if not ids: continue
        d = f'base/{slug}'; os.makedirs(d, exist_ok=True)
        done = all(os.path.exists(f'{d}/{w}_{x}') for x in ['R1.uc', 'R2.uc', 'R4.done'])
        if not done and not PARSE:
          wfa(f'{d}/{w}_q.fa', q, ids)
          keepF = [k for k in full if ref.get(k) != s]; wfa(f'{d}/{w}_full.fa', full, keepF)
          keepI = [k for k in inh if ref.get(k) != s]; wfa(f'{d}/{w}_inh.fa', inh, keepI)
          keepT = [k for k in keepF if k in tested]; wfa(f'{d}/{w}_tested.fa', full, keepT)
          base = '--id 0.99 --strand both --qmask none --minseqlength 1 --threads ' + TH
          subprocess.run(f'vsearch --usearch_global {d}/{w}_q.fa --db {d}/{w}_full.fa {base} --uc {d}/{w}_R1.uc --quiet', shell=True, check=True)
          subprocess.run(f'vsearch --usearch_global {d}/{w}_q.fa --db {d}/{w}_inh.fa {base} --uc {d}/{w}_R2.uc --quiet', shell=True, check=True)
          subprocess.run(f'vsearch --usearch_global {d}/{w}_q.fa --db {d}/{w}_tested.fa {base} --maxaccepts 0 --maxrejects 0 '
                         f'--userfields query+target+id+qilo+qihi+ql --userout {d}/{w}_R4.tsv --quiet', shell=True, check=True)
          open(f'{d}/{w}_R4.done', 'w').write('ok')
          for f in ['full.fa', 'inh.fa', 'tested.fa']: os.remove(f'{d}/{w}_{f}')
        h1 = uc_hits(f'{d}/{w}_R1.uc'); h2 = uc_hits(f'{d}/{w}_R2.uc')
        try: u4 = pd.read_csv(f'{d}/{w}_R4.tsv', sep='\t', header=None, names=['q', 't', 'id', 'qilo', 'qihi', 'ql'])
        except pd.errors.EmptyDataError: u4 = pd.DataFrame(columns=['q', 't', 'id', 'qilo', 'qihi', 'ql'])
        u4 = u4[(u4.qilo == 1) & (u4.qihi == u4.ql)]
        u4['inh'] = (aud.Func.reindex(u4.t).values == 'Inhibitory')
        g4 = u4.groupby('q').inh.agg(['sum', 'size'])
        for i in ids:
            f1 = aud.Func.get(h1[i]) if i in h1 else None
            n4 = int(g4['size'].get(i, 0)); k4 = int(g4['sum'].get(i, 0))
            rows.append(dict(FastaID=i, window=w, study=s, R1_hit=h1.get(i), R1_hitFunc=f1,
                             R1_pred=int(f1 == 'Inhibitory'), R2_pred=int(i in h2),
                             R4_nhits=n4, R4_frac=(k4 / n4) if n4 else float('nan'),
                             R4_pred=int(n4 > 0 and k4 / n4 > 0.5)))
        print(w, slug, len(ids), flush=True)
pd.DataFrame(rows).to_csv('base/baseline_preds_' + '_'.join(WINS) + '.csv', index=False)
print('done')
