"""Per-fold predictions: M1 nearest tip, M2 castor HSP (mp, emp_prob, subtree_average, mk), M3 BM/BMe/OU/OUe,
M4 (phylo + study [+ genotype] + residual) GP, at the EPA-ng placement points (LWR>=0.01, renormalised).
Env: placement (calls Rscript in env rcastor via conda run path given by RSCRIPT env var)."""
import sys, os, json, subprocess, time
sys.path.insert(0, 'scripts'); import bench_lib as B, placement_lib as P
import numpy as np, pandas as pd
from scipy import stats, linalg
RS = os.environ['RSCRIPT']
t = pd.read_csv('ref/tip_table.csv').set_index('FastaID')
t['study'] = t.Reference.astype(str); t['geno'] = t['Bd.Genotype'].astype(str).str.replace(' ', '', regex=False)
folds = pd.read_csv('loso/folds.csv')
vc = pd.read_csv('gp/varcomp_full.csv').set_index('model')  # REML fits on full data (03_varcomp.py)
GPM = ['BM', 'BMe', 'OU', 'OUe', 'M4s', 'M4']
TH = {m: {k: v for k, v in vc.loc[m].items() if k in ['sp2', 'se2', 's2', 'alpha', 'ss2', 'sg2', 'jit'] and pd.notna(v)} for m in GPM}
HSP = ['mp', 'emp_prob', 'subtree_average', 'mk']
HSPOUT = HSP + ['mk_att']
out = []
def logit_mix(df, col):  # LWR-weighted mean of a per-placement quantity
    return (df[col] * df.w).groupby(df['query']).sum()
for s, slug in zip(folds.study, folds.slug):
    for w in ['V4_254', 'V3V4_429']:
        jp = f'loso/{slug}/{w}/epa_result.jplace'
        if not os.path.exists(jp): continue
        t0 = time.time()
        T = B.Tree(jp); pl = T.placements(0.01)
        lab = np.array(T.tip_labels); func = t.Func.reindex(lab).values; inh = (func == 'Inhibitory').astype(float)
        # ---- M1 nearest tip per placement
        down, dleaf, up, uleaf = P.nearest_tip_tables(T.parent, T.blen, T.children, T.is_leaf)
        vc_ = pl.distal + down[pl.child]; vp_ = (pl.L - pl.distal) + up[pl.child]
        nt = np.where(vc_ <= vp_, dleaf[pl.child], uleaf[pl.child])
        pl['nsti'] = pl.pendant + np.minimum(vc_, vp_)
        pl['nt'] = [T.label[v] for v in nt]
        pl['nt_inh'] = (t.Func.reindex(pl.nt).values == 'Inhibitory').astype(float)
        # ---- M2 castor HSP
        pre = f'loso/{slug}/{w}_c'
        open(pre + '_tree.nwk', 'w').write(T.newick())
        pd.DataFrame({'label': lab, 'state': np.where(inh == 1, 2, 1)}).to_csv(pre + '_tips.csv', index=False)
        r = subprocess.run(f'{RS} scripts/hsp_castor.R {pre}_tree.nwk {pre}_tips.csv {pre}', shell=True, capture_output=True, text=True)
        if r.returncode: raise RuntimeError(r.stderr)
        H = pd.read_csv(pre + '_hsp.csv'); mk = json.load(open(pre + '_mk.json'))
        idx = {l: i for i, l in enumerate(H.label)}
        def node_lab(v): return T.label[v] if T.is_leaf[v] else f'n{v}'
        ci = np.array([idx[node_lab(v)] for v in pl.child]); pi = np.array([idx[node_lab(v)] for v in pl.par])
        fr = np.where(pl.L > 0, pl.distal / pl.L.replace(0, 1), 0.0)
        Q = np.array(mk[mk['best']]['Q']); a, b = Q[0, 1], Q[1, 0]; pi1 = a / (a + b)
        for m in HSP:
            v = H[m].values; patt = fr * v[pi] + (1 - fr) * v[ci]
            if m == 'mk':
                pl['p_mk_att'] = patt                      # attachment point, no pendant propagation
                patt = pi1 + (patt - pi1) * np.exp(-(a + b) * pl.pendant.values)
            pl['p_' + m] = patt
        # ---- M3/M4 Gaussian models on scored training tips
        C = T.cov(); sc = t.score.reindex(lab).values; tr = np.where(~np.isnan(sc))[0]; y = sc[tr]
        Ct = C[np.ix_(tr, tr)]; dg = np.diag(Ct); D = dg[:, None] + dg[None, :] - 2 * Ct
        sub = t.loc[lab[tr]]
        Zs = {'ss2': pd.get_dummies(sub.study).values.astype(float), 'sg2': pd.get_dummies(sub.geno).values.astype(float)}
        Kc = B.cov_rows(T, C, pl, tr)                                    # unit-rate BM covariance, all placements
        top = (pl['rank'] == 0).values; vq_bm = (pl.att_depth + pl.pendant).values
        for m in GPM:
            th = TH[m]; isou = m.startswith('OU')
            K = B.build_K(th, 'OU' if isou else 'G', D if isou else Ct, Zs, len(y))
            _, fit = B.reml(y, K)
            if isou:
                dq = vq_bm[:, None] + dg[None, :] - 2 * Kc; Kq = th['s2'] * np.exp(-th['alpha'] * dq); vq = np.full(len(pl), th['s2'])
            else:
                Kq = th['sp2'] * Kc; vq = th['sp2'] * vq_bm
            vq = vq + th.get('se2', 0) + th.get('ss2', 0) + th.get('sg2', 0) + th.get('jit', 0)
            mean = fit['beta'] + Kq @ fit['Ki_r']; pl['mu_' + m] = mean
            _, var = B.gp_predict(fit, Kq[top], vq[top])
            pl.loc[top, 'var_' + m] = var
        # ---- aggregate per query
        g = pl.groupby('query'); topr = pl[top].set_index('query')
        res = pd.DataFrame(index=topr.index)
        res['n_place'] = g.size(); res['lwr_top'] = topr.lwr; res['pendant_top'] = topr.pendant
        res['nsti'] = logit_mix(pl, 'nsti'); res['nsti_top'] = topr.nsti
        res['M1_nearest_tip'] = topr.nt; res['P_M1top'] = topr.nt_inh; res['P_M1'] = logit_mix(pl, 'nt_inh')
        for m in HSPOUT: res['P_M2_' + m] = logit_mix(pl, 'p_' + m)
        for m in GPM:
            mu = logit_mix(pl, 'mu_' + m)
            between = ((pl['mu_' + m] - mu.reindex(pl['query']).values) ** 2 * pl.w).groupby(pl['query']).sum()
            sd = np.sqrt(topr['var_' + m] + between)
            res['mu_' + m] = mu; res['sd_' + m] = sd
            res['P_' + m] = 1 - stats.norm.cdf((80 - mu) / sd)
        res['window'] = w; res['study'] = s; res['slug'] = slug
        res['mk_model'] = mk['best']; res['mk_q01'] = a; res['mk_q10'] = b
        res['n_ref'] = len(lab); res['n_train_scored'] = len(y)
        out.append(res.reset_index().rename(columns={'query': 'FastaID'}))
        for f in ['_tree.nwk', '_tips.csv']: os.remove(pre + f)
        print(slug, w, len(res), len(pl), round(time.time() - t0, 1), flush=True)
pd.concat(out).to_csv('gp/tree_preds.csv', index=False)
print('done')
