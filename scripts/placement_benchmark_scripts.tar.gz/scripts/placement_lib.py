"""Reusable functions for AmphiBac phylogenetic placement (PICRUSt2-style).
Environment: conda env `placement` (epa-ng 0.3.8, gappa 0.9.0, infernal 1.1.5, raxml-ng 2.0.3, dendropy).
Reference package layout (refdir): ref_msa.fasta (cmalign --matchonly RF00177 frame, 1533 cols),
ref_tree.nwk (raxml-ng --evaluate GTR+G), ref_model.txt (raxml bestModel string), RF00177.cm, tip_table.csv.
"""
import os, re, json, subprocess, time, tempfile
import numpy as np, pandas as pd
import dendropy
from Bio import SeqIO
from Bio.Seq import Seq

def _run(cmd, log=None):
    t0 = time.time()
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"command failed: {cmd}\n{r.stderr[-2000:]}\n{r.stdout[-2000:]}")
    return time.time() - t0

# ---------------- (a) query alignment ----------------
def align_queries(query_fasta, out_afa, cm, threads=10, orient=False):
    """Align query sequences (E. coli/sense orientation expected; set orient=True to try both strands
    via cmalign scores) to the RF00177 covariance model, match columns only, so the output has
    exactly the reference MSA width (1533). Returns (runtime_s, score_table)."""
    d = tempfile.mkdtemp(dir=os.path.dirname(os.path.abspath(out_afa)) or '.')
    q = query_fasta
    if orient:
        recs = list(SeqIO.parse(query_fasta, 'fasta'))
        fw = os.path.join(d, 'both.fa')
        with open(fw, 'w') as fh:
            for r in recs:
                s = str(r.seq).upper().replace('U', 'T')
                fh.write(f'>{r.id}__F\n{s}\n>{r.id}__R\n{str(Seq(s).reverse_complement())}\n')
        q = fw
    pf, scf = os.path.join(d, 'q.pfam'), os.path.join(d, 'q.sc')
    rt = _run(f"cmalign --cpu {threads} --noprob --matchonly --outformat Pfam -o {pf} --sfile {scf} {cm} {q}")
    sc = pd.read_csv(scf, sep=r'\s+', comment='#', header=None)
    sc = sc.iloc[:, :8]; sc.columns = ['idx', 'id', 'len', 'cm_from', 'cm_to', 'trunc', 'bits', 'pp']
    afa = os.path.join(d, 'q.afa'); _run(f"esl-reformat afa {pf} > {afa}")
    seqs = {r.id: str(r.seq).upper().replace('.', '-').replace('U', 'T') for r in SeqIO.parse(afa, 'fasta')}
    if orient:
        sc['qid'] = sc.id.str.rsplit('__', n=1).str[0]
        best = sc.sort_values('bits', ascending=False).drop_duplicates('qid')
        seqs = {r.qid: seqs[r.id] for r in best.itertuples()}
        sc = best.assign(strand=best.id.str[-1]).drop(columns='id').rename(columns={'qid': 'id'})
    with open(out_afa, 'w') as fh:
        for k, v in seqs.items(): fh.write(f'>{k}\n{v}\n')
    sc['bits_per_nt'] = sc.bits / sc.len
    return rt, sc

# ---------------- (d) pruning ----------------
def _load_tree(nwk):
    return dendropy.Tree.get(path=nwk, schema='newick', preserve_underscores=True, rooting='force-unrooted')

def prune_reference(tree_nwk, msa_fasta, drop_ids, out_tree, out_msa):
    """Remove tips (e.g. one study) from the tree and MSA. Branch lengths of merged edges are summed;
    the basal node is kept as a trifurcation (EPA-ng needs an unrooted tree)."""
    drop = set(drop_ids)
    tr = _load_tree(tree_nwk)
    labs = [lf.taxon.label for lf in tr.leaf_node_iter()]
    tr.prune_taxa_with_labels([l for l in labs if l in drop], suppress_unifurcations=True)
    tr.is_rooted = False
    sn = tr.seed_node
    if len(sn.child_nodes()) == 2:  # collapse basal bifurcation
        a, b = sn.child_nodes()
        inner = a if not a.is_leaf() else b
        other = b if inner is a else a
        other.edge_length = (other.edge_length or 0) + (inner.edge_length or 0)
        inner.edge_length = None
        tr.reroot_at_node(inner, suppress_unifurcations=True, update_bipartitions=False)
    tr.write(path=out_tree, schema='newick', suppress_rooting=True, unquoted_underscores=True)
    n = 0
    with open(out_msa, 'w') as fh:
        for r in SeqIO.parse(msa_fasta, 'fasta'):
            if r.id not in drop: fh.write(f'>{r.id}\n{str(r.seq)}\n'); n += 1
    return n

# ---------------- (b) EPA-ng ----------------
def run_epa(tree, ref_msa, query_afa, model, outdir, threads=10, extra=''):
    """model: path to raxml-ng .bestModel file or a model string. Returns runtime (s); jplace at outdir/epa_result.jplace"""
    os.makedirs(outdir, exist_ok=True)
    # EPA-ng 0.3.8 parses a raxml-ng .bestModel FILE directly; the raw model string (FU/G4m{..}) fails to parse.
    rt = _run(f"epa-ng --redo --tree {tree} --ref-msa {ref_msa} --query {query_afa} --model '{model}' "
              f"--threads {threads} --outdir {outdir} {extra}")
    return rt

# ---------------- (c) jplace parsing + NSTI ----------------
_edge_re = re.compile(r'\{(\d+)\}')

def _parse_jplace_tree(tstr):
    """Parse jplace newick with {edge_num} after branch lengths into arrays.
    Returns parent, blen, edge_num per node, leaf labels."""
    # tokenise manually (fast, handles 10^4 tips)
    parent = []; blen = []; enum = []; label = []
    stack = []; cur = None; i = 0; n = len(tstr)
    def new(par):
        parent.append(par); blen.append(0.0); enum.append(-1); label.append(None); return len(parent) - 1
    root = new(-1); cur = root
    while i < n:
        c = tstr[i]
        if c == '(':
            stack.append(cur); cur = new(cur); i += 1
        elif c == ',':
            cur = new(stack[-1]); i += 1
        elif c == ')':
            cur = stack.pop(); i += 1
        elif c == ':':
            j = i + 1
            while tstr[j] not in ',){;[': j += 1
            blen[cur] = float(tstr[i + 1:j]); i = j
        elif c == '{':
            j = tstr.index('}', i); enum[cur] = int(tstr[i + 1:j]); i = j + 1
        elif c == ';':
            break
        else:
            j = i
            while tstr[j] not in ':,(){;': j += 1
            lab = tstr[i:j].strip("'")
            if lab: label[cur] = lab
            i = j
    parent = np.array(parent); blen = np.array(blen); enum = np.array(enum)
    children = [[] for _ in parent]
    for k, p in enumerate(parent):
        if p >= 0: children[p].append(k)
    is_leaf = np.array([len(c) == 0 for c in children])
    return parent, blen, enum, label, children, is_leaf

def nearest_tip_tables(parent, blen, children, is_leaf):
    """down[v] = min dist from v to a leaf in its subtree (and that leaf);
    up[v] = min dist from v to a leaf NOT in subtree(v), via its parent (and that leaf)."""
    N = len(parent); order = []
    st = [0]
    while st:
        v = st.pop(); order.append(v); st.extend(children[v])
    down = np.full(N, np.inf); dleaf = np.full(N, -1)
    for v in reversed(order):
        if is_leaf[v]: down[v] = 0; dleaf[v] = v
        else:
            for c in children[v]:
                d = down[c] + blen[c]
                if d < down[v]: down[v] = d; dleaf[v] = dleaf[c]
    up = np.full(N, np.inf); uleaf = np.full(N, -1)
    for v in order:
        ch = children[v]
        if not ch: continue
        vals = [(down[c] + blen[c], dleaf[c]) for c in ch]
        for k, c in enumerate(ch):
            best = (up[v], uleaf[v])
            for kk, (d, l) in enumerate(vals):
                if kk != k and d < best[0]: best = (d, l)
            up[c] = best[0] + blen[c]; uleaf[c] = best[1]
    return down, dleaf, up, uleaf

def parse_jplace(jplace_path, all_placements=False):
    """Return DataFrame: one row per query (top-LWR placement) or per placement if all_placements.
    Columns: query, edge_num, lwr, likelihood, distal_length, pendant_length, edge_child (tip label if the
    edge leads to a tip else None), nsti (pendant + distance from attachment point to nearest reference tip),
    nearest_tip, n_placements, lwr_sum_top_edge.
    Convention (jplace spec / EPA-ng): distal_length is measured from the distal (child-side) node."""
    J = json.load(open(jplace_path))
    parent, blen, enum, label, children, is_leaf = _parse_jplace_tree(J['tree'])
    down, dleaf, up, uleaf = nearest_tip_tables(parent, blen, children, is_leaf)
    e2node = {e: k for k, e in enumerate(enum) if e >= 0}
    f = J['fields']; rows = []
    for pl in J['placements']:
        names = [x if isinstance(x, str) else x[0] for x in pl.get('n', pl.get('nm', []))]
        P = sorted([dict(zip(f, p)) for p in pl['p']], key=lambda d: -d['like_weight_ratio'])
        use = P if all_placements else P[:1]
        for rank, p in enumerate(use):
            v = e2node[p['edge_num']]
            dl = p['distal_length']; L = blen[v]
            via_child = dl + down[v]; via_par = (L - dl) + up[v]
            if via_child <= via_par: d, nt = via_child, dleaf[v]
            else: d, nt = via_par, uleaf[v]
            for q in names:
                rows.append(dict(query=q, rank=rank, edge_num=p['edge_num'], lwr=p['like_weight_ratio'],
                                 likelihood=p['likelihood'], distal_length=dl, pendant_length=p['pendant_length'],
                                 edge_length=L, edge_child=label[v] if is_leaf[v] else None,
                                 nsti=p['pendant_length'] + d, nearest_tip=label[nt], n_placements=len(P)))
    return pd.DataFrame(rows)

def edge_tipsets(jplace_path):
    """dict edge_num -> frozenset of tip labels on the child side (for clade tests)."""
    J = json.load(open(jplace_path))
    parent, blen, enum, label, children, is_leaf = _parse_jplace_tree(J['tree'])
    order = []; st = [0]
    while st:
        v = st.pop(); order.append(v); st.extend(children[v])
    tips = [None] * len(parent)
    for v in reversed(order):
        tips[v] = frozenset([label[v]]) if is_leaf[v] else frozenset().union(*[tips[c] for c in children[v]])
    return {enum[v]: tips[v] for v in range(len(parent)) if enum[v] >= 0}
