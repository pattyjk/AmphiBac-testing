"""Step 1: leave-study-out EPA-ng placement of V4_254 and V3V4_429 fragments (tested isolates).
Env: placement. Usage: python scripts/01_loso_place.py THREADS"""
import sys, os, time, re, json
sys.path.insert(0, 'scripts'); import placement_lib as P
import pandas as pd
from Bio import SeqIO
TH = int(sys.argv[1]) if len(sys.argv) > 1 else 6
t = pd.read_csv('ref/tip_table.csv')
t['study'] = t.Reference.astype(str)
studies = t.study.value_counts().index.tolist()
slug = {s: f"s{i:02d}" for i, s in enumerate(studies)}
pd.DataFrame({'study': studies, 'slug': [slug[s] for s in studies],
              'n_tested': t.study.value_counts().values}).to_csv('loso/folds.csv', index=False)
WIN = ['V4_254', 'V3V4_429']
# 1) align all fragments once (cmalign is per-sequence against the CM, independent of the reference tree)
for w in WIN:
    out = f'loso/{w}_all.afa'
    if not os.path.exists(out):
        rt, sc = P.align_queries(f'frags/{w}.fasta', out, 'ref/RF00177.cm', threads=TH)
        sc.to_csv(f'loso/{w}_cmalign_scores.csv', index=False); print(w, 'aligned', round(rt), flush=True)
aln = {w: {r.id: str(r.seq) for r in SeqIO.parse(f'loso/{w}_all.afa', 'fasta')} for w in WIN}
log = []
for s in studies:
    d = f'loso/{slug[s]}'; os.makedirs(d, exist_ok=True)
    ids = set(t.FastaID[t.study == s])
    if all(os.path.exists(f'{d}/{w}/epa_result.jplace') for w in WIN if any(i in aln[w] for i in ids)):
        continue
    t0 = time.time()
    nref = P.prune_reference('ref/ref_tree.nwk', 'ref/ref_msa.fasta', ids, f'{d}/tree.nwk', f'{d}/msa.fasta')
    for w in WIN:
        q = [i for i in ids if i in aln[w]]
        if not q: continue
        with open(f'{d}/{w}_q.afa', 'w') as fh:
            for i in q: fh.write(f'>{i}\n{aln[w][i]}\n')
        rt = P.run_epa(f'{d}/tree.nwk', f'{d}/msa.fasta', f'{d}/{w}_q.afa', 'ref/ref_model.txt', f'{d}/{w}', threads=TH)
        log.append(dict(study=s, slug=slug[s], window=w, n_query=len(q), n_ref=nref, epa_s=rt))
        print(slug[s], w, len(q), nref, round(rt, 1), flush=True)
    os.remove(f'{d}/msa.fasta')
pd.DataFrame(log).to_csv('loso/epa_log.csv', index=False)
print('done')
