"""Fit Gaussian tree models for the CFS score by REML on all scored in-tree isolates (full reference tree).
Models: BM (sp2*C, tiny jitter), BMe (sp2*C + se2 I), OU (s2 exp(-a D)), OUe (+ se2 I),
M4 (sp2*C + ss2 Zstudy + sg2 Zgenotype + se2 I), M4s (no genotype). Env: placement."""
import sys, os, json, time
sys.path.insert(0, 'scripts'); import bench_lib as B
import numpy as np, pandas as pd
from scipy import optimize
def groups(df):
    g = df['Bd.Genotype'].astype(str).str.replace(' ', '', regex=False)
    return {'ss2': pd.get_dummies(df.Reference.astype(str)).values.astype(float),
            'sg2': pd.get_dummies(g).values.astype(float)}
MODELS = {'BM': ['sp2'], 'BMe': ['sp2', 'se2'], 'OU': ['s2', 'alpha'], 'OUe': ['s2', 'alpha', 'se2'],
          'M4s': ['sp2', 'ss2', 'se2'], 'M4': ['sp2', 'ss2', 'sg2', 'se2']}
JIT = 1e-4  # absolute jitter (score units^2) on the diagonal for numerical stability
def fit_model(name, y, C, D, Zs, x0=None):
    pars = MODELS[name]; Cs = D if name.startswith('OU') else C
    v = np.var(y)
    if x0 is None:
        init = {'sp2': v / max(np.mean(np.diag(C)), 1e-3) / 2, 'se2': v / 2, 'ss2': v / 10, 'sg2': v / 10, 's2': v, 'alpha': 1.0}
        x0 = np.log([init[p] for p in pars])
    def f(lx):
        th = dict(zip(pars, np.exp(lx))); th['jit'] = JIT
        return B.reml(y, B.build_K(th, 'OU' if name.startswith('OU') else 'G', Cs, Zs, len(y)))[0]
    r = optimize.minimize(f, x0, method='L-BFGS-B', bounds=[(-25, 25)] * len(pars), options=dict(maxiter=200))
    th = dict(zip(pars, np.exp(r.x))); th['jit'] = JIT
    return th, r.fun, r
if __name__ == '__main__':
    t = pd.read_csv('ref/tip_table.csv').set_index('FastaID')
    T = B.Tree(newick='ref/ref_tree.nwk'); C = T.cov()
    lab = np.array(T.tip_labels); sc = t.score.reindex(lab)
    keep = np.where(sc.notna().values)[0]
    y = sc.values[keep]; Cs = C[np.ix_(keep, keep)]
    dg = np.diag(Cs); D = dg[:, None] + dg[None, :] - 2 * Cs
    df = t.loc[lab[keep]]; Zs = groups(df)
    out = []
    for m in MODELS:
        t0 = time.time(); th, nll, r = fit_model(m, y, Cs, D, Zs)
        k = len(MODELS[m]); row = dict(model=m, reml_nll=nll, k=k, AIC_reml=2 * nll + 2 * k, converged=bool(r.success), sec=time.time() - t0, **th)
        if 'sp2' in th:
            phyl = th['sp2'] * np.mean(np.diag(Cs))  # average phylogenetic variance across tips (non-ultrametric tree)
            tot = phyl + th.get('ss2', 0) + th.get('sg2', 0) + th.get('se2', 0)
            row.update(mean_tipdepth=float(np.mean(np.diag(Cs))), phylo_var=phyl, h2_phylo=phyl / tot,
                       study_share=th.get('ss2', 0) / tot, genotype_share=th.get('sg2', 0) / tot, resid_share=th.get('se2', 0) / tot)
        if m.startswith('OU'):
            tot = th['s2'] + th.get('se2', 0); row.update(h2_phylo=th['s2'] / tot, ou_halflife=np.log(2) / th['alpha'], resid_share=th.get('se2', 0) / tot)
        out.append(row); print(row, flush=True)
    pd.DataFrame(out).to_csv('gp/varcomp_full.csv', index=False)
