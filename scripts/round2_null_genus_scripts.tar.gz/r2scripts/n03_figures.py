"""Round-2 figures (null + genus). Run from r2/ after n01, n02, g02. Style: figure-style skill apply_figure_style(sizes=(8,7,6))
was applied in the session; here approximated with rcParams (font sizes 8/7/6, no top/right spines)."""
import pickle, numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 7, 'axes.titlesize': 8, 'axes.labelsize': 8, 'xtick.labelsize': 6, 'ytick.labelsize': 6,
                     'legend.fontsize': 7, 'axes.spines.top': False, 'axes.spines.right': False})
res = pickle.load(open('out/perm_null.pkl', 'rb'))['res']
S = pd.read_csv('out/null_per_sample_summary.csv'); C = pd.read_csv('out/null_contrasts.csv')
SH = {'global': '#4d4d4d', 'genus': '#1b7837', 'study': '#b8860b'}
SHL = {'global': 'All isolates', 'genus': 'Within genus', 'study': 'Within study'}
CI, CN, CF = '#2166AC', '#E08214', '#7B3294'
# ---- Fig N1 per-sample
fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.9), gridspec_kw=dict(width_ratios=[1, 1, 1.25], wspace=0.62))
rr = res['meta']
for ax, met, lim, ttl, ylab in ((axs[0], 'any', 1.0, 'Pipeline: random labels match it', 'Observed Inhibitory_Proportion'),
                               (axs[1], 'maj', 0.4, 'Majority: exceeds random', 'Observed majority-rule proportion')):
    mu = rr['null']['global'][met].mean(1)
    ax.scatter(mu, rr['obs_' + met], s=3, alpha=0.35, color=CI, lw=0, rasterized=True)
    ax.plot([0, lim], [0, lim], color='0.4', lw=0.7, ls='--'); ax.set_xlim(-0.01, lim + 0.02); ax.set_ylim(-0.02, 1.02)
    ax.set_xlabel('Mean under shuffled labels'); ax.set_ylabel(ylab); ax.set_title(ttl, loc='left')
    rho = S.query("dataset=='meta' and metric==@met and shuffle=='global'").spearman_obs_vs_nullmean.iloc[0]
    if met == 'any': ax.text(0.04, 0.96, f'ρ = {rho:.2f}\nn = 2,411 samples', transform=ax.transAxes, va='top', fontsize=7)
    else: ax.text(0.62, 0.72, f'ρ = {rho:.2f}', transform=ax.transAxes, va='top', fontsize=7)
ax = axs[2]; w = 0.26; cats = [('meta', 'any'), ('meta', 'maj'), ('bf', 'any'), ('bf', 'maj')]
for j, k in enumerate(('global', 'genus', 'study')):
    v = [S.query("dataset==@d and metric==@m and shuffle==@k").pct_samples_obs_gt_null95.iloc[0] for d, m in cats]
    ax.barh(np.arange(4) + (j - 1) * w, v, height=w, color=SH[k], label=SHL[k])
    for i, x in enumerate(v):
        if x == 0: ax.plot(0.4, i + (j - 1) * w, '|', color=SH[k], ms=4, mew=1.5)
ax.text(6.5, 2, '0 of 40 samples', fontsize=6, va='center')
ax.axvline(5, color='#b2182b', lw=0.8, ls=':'); ax.text(6, -0.55, '5% expected by chance', fontsize=6, color='#b2182b', va='bottom')
ax.set_yticks(range(4)); ax.set_yticklabels(['Meta, pipeline', 'Meta, majority', 'Bullfrog, pipeline', 'Bullfrog, majority'])
ax.set_ylim(3.5, -0.75); ax.set_xlim(0, 60); ax.set_xlabel('% samples above null 95th pct')
ax.legend(frameon=False, fontsize=6, loc='lower right', title='Labels shuffled', title_fontsize=6); ax.set_title('Few samples beat the null', loc='left')
for a, l in zip(axs, 'abc'): a.text(-0.08, 1.07, l, transform=a.transAxes, fontweight='bold', fontsize=10, ha='right')
fig.savefig('fig_null_per_sample.png', dpi=300, bbox_inches='tight')
# ---- Fig N2 contrasts
cons = list(rr['contrast_obs'].keys())
ctitle = {cons[0]: 'Adult vs larvae', cons[1]: 'Madagascar vs USA', cons[2]: '$\\it{A.\\ boreas}$ vs $\\it{L.\\ catesbeianus}$'}
fig2, axs2 = plt.subplots(2, 3, figsize=(7.2, 4.4), sharex=True, gridspec_kw=dict(hspace=0.45, wspace=0.12))
for i, met in enumerate(('any', 'maj')):
    for j, c in enumerate(cons):
        ax = axs2[i, j]
        for k, kind in enumerate(('global', 'genus', 'study')):
            rn = rr['null'][kind]['contrast'][c][met][0]
            parts = ax.violinplot([rn], positions=[k], orientation='horizontal', widths=0.8, showextrema=False)
            for b in parts['bodies']: b.set_facecolor(SH[kind]); b.set_alpha(0.7); b.set_edgecolor('none')
            row = C[(C.contrast == c) & (C.metric == met) & (C.shuffle == kind)].iloc[0]
            ax.text(1.32, k, f'{row.pct_null_p_lt_005:.0f}%', va='center', ha='right', fontsize=6, color=SH[kind])
        ro = float(np.ravel(rr['contrast_obs'][c][met][0])[0]); po = float(np.ravel(rr['contrast_obs'][c][met][1])[0])
        ax.axvline(ro, color=CI, lw=1.5); ax.axvline(0, color='0.7', lw=0.6, ls=':')
        ax.set_yticks(range(3)); ax.set_yticklabels([SHL[k] for k in ('global', 'genus', 'study')] if j == 0 else [])
        ax.set_ylim(2.6, -0.9); ax.set_xlim(-0.65, 1.35); ax.set_xticks([-0.5, 0, 0.5, 1])
        ax.text(ro + 0.03 if ro < 0.5 else ro - 0.03, -0.6, f'observed r = {ro:.2f}' + (' (n.s.)' if po >= 0.05 else ''), fontsize=6, color=CI, ha='left' if ro < 0.5 else 'right')
        na, nb = rr['contrast_n'][c]
        if i == 0: ax.set_title(f'{ctitle[c]} (n = {na} / {nb})', loc='left', fontsize=7)
axs2[1, 1].set_xlabel('Rank-biserial r under shuffled labels (1,000 shuffles each); blue line = observed')
axs2[0, 0].text(-0.45, 1.2, 'a   Pipeline Inhibitory mode (any ≥99% hit Inhibitory)', transform=axs2[0, 0].transAxes, fontsize=8, fontweight='bold')
axs2[1, 0].text(-0.45, 1.08, 'b   Majority of ≥99% hits Inhibitory', transform=axs2[1, 0].transAxes, fontsize=8, fontweight='bold')
axs2[0, 2].text(1.0, 1.2, '% shuffles with MWU p < 0.05', transform=axs2[0, 2].transAxes, fontsize=6, ha='right')
fig2.savefig('fig_null_contrasts.png', dpi=300, bbox_inches='tight')
# ---- Fig G1 genus baseline
M = pd.read_csv('out/genus_baseline_metrics_long.csv'); H = pd.read_csv('out/genus_heterogeneity_top20.csv', index_col=0)
rules = [('R2_Inhibitory_subset', 'Any hit to Inhibitory subset (R2)', '#9e9e9e'), ('R1_tophit', 'Default top hit (R1)', '#636363'),
         ('R4_majority99', 'Majority of ≥99% hits (R4)', '#252525'), ('G_genus_majority_fragment', 'Genus majority, genus from amplicon', '#4daf4a'),
         ('G_genus_majority_fullseq', 'Genus majority, genus from isolate', '#1b7837')]
fig = plt.figure(figsize=(7.2, 4.6)); gs = fig.add_gridspec(1, 2, width_ratios=[1, 1.05], wspace=0.55)
ax = fig.add_subplot(gs[0]); groups = [('120', 'self'), ('120', 'study'), ('V4full', 'self'), ('V4full', 'study')]
glab = {('120', 'self'): '120 bp\nleave-self-out', ('120', 'study'): '120 bp\nleave-study-out', ('V4full', 'self'): 'Full V4\nleave-self-out', ('V4full', 'study'): 'Full V4\nleave-study-out'}
for gi, (f, e) in enumerate(groups):
    for ri, (r_, lab, c) in enumerate(rules):
        d = M[(M.fragment == f) & (M.exclusion == e) & (M.rule == r_) & (M.metric == 'kappa')].iloc[0]
        ax.errorbar(d.value, gi * 6 + ri, xerr=[[d.value - d.ci_lo], [d.ci_hi - d.value]], fmt='o', color=c, ms=4, lw=1, capsize=0, label=lab if gi == 0 else None)
ax.set_yticks([gi * 6 + 2 for gi in range(4)]); ax.set_yticklabels([glab[g] for g in groups]); ax.invert_yaxis()
ax.axvline(0, color='0.6', lw=0.6, ls=':'); ax.set_xlabel("Cohen's κ vs isolate label (Inhibitory vs not)")
ax.set_title('Genus alone matches or beats 99% identity', loc='left')
ax.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.45, -0.13), ncol=1)
ax2 = fig.add_subplot(gs[1]); h = H.iloc[::-1]; y = np.arange(len(h))
pi = 100 * h.n_inhibitory / h.n; pn = 100 * h.n_noeffect / h.n; pf = 100 * h.n_facilitating / h.n
ax2.barh(y, pi, color=CI, label='Inhibitory'); ax2.barh(y, pn, left=pi, color=CN, label='No effect'); ax2.barh(y, pf, left=pi + pn, color=CF, label='Facilitating')
ax2.set_yticks(y); ax2.set_yticklabels([f'$\\it{{{g}}}$' for g in h.index])
for yy, (n, s) in zip(y, zip(h.n, h.n_studies)): ax2.text(101.5, yy, f'{n} / {s}', va='center', fontsize=6)
ax2.text(101.5, len(h) - 0.1, 'n / studies', fontsize=6, va='bottom')
ax2.set_xlim(0, 100); ax2.set_xlabel('% of tested isolates'); ax2.set_ylim(-0.6, len(h) + 0.2)
ax2.set_title('Labels are mixed within every large genus', loc='left')
ax2.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.4, -0.08), ncol=3, handlelength=1)
for a, l in ((ax, 'a'), (ax2, 'b')): a.text(-0.02, 1.04, l, transform=a.transAxes, fontweight='bold', fontsize=10, ha='right')
fig.savefig('fig_genus_baseline.png', dpi=300, bbox_inches='tight')
print('figures written')
