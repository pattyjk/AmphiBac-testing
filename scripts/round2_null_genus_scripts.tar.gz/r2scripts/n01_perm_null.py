"""Round 2, track 'null': label-permutation null for per-sample Inhibitory_Proportion.
Hits (feature -> all >=99% Full-db isolates, vsearch exhaustive, iddef 2) are fixed; Func labels are permuted
among the 8,739 database isolates (global, within-genus [SINTAX genus], within-study [Reference]); B=1000 each.
Inhibitory-mode call ('any-hit approximation of subset mode'): feature inhibitory if ANY >=99% isolate with 100% query
coverage has Func=='Inhibitory' (full-coverage hits reproduce the pipeline; any-coverage hits do not, see check). Majority metric: frac Inhibitory among tested (Inhibitory/NoEffect/Facilitating) qualifying
isolates > 0.5, on full-coverage hits ('maj') and on any-coverage hits ('maj_r1' = round-1 Majority_Proportion). Single-threaded (OMP/BLAS 1).
Run from r2/: python n01_perm_null.py <map.txt> <r1_meta_feature_labels.csv> <r1_meta_per_sample.csv> <r1_bf_per_sample.csv> <r1_bf_feature_labels.csv>"""
import os
for v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'): os.environ[v] = '1'
import sys, numpy as np, pandas as pd, scipy.sparse as sp, pickle
from scipy import stats
MAP, R1META_L, R1META_S, R1BF_S, R1BF_L = sys.argv[1:6]
B = 1000; os.makedirs('out', exist_ok=True)
aud = pd.read_csv('db/audit_per_sequence.csv', index_col=0)
gen = pd.read_csv('out/genus_assignments.csv', index_col=0)
iso = aud.index.tolist(); ii = {k: i for i, k in enumerate(iso)}; NI = len(iso)
func = np.array(aud.Func.fillna('NA').tolist(), dtype='U32')
TESTED = np.isin(func, ['Inhibitory', 'NoEffect', 'Facilitating'])
genus = np.array(gen.reindex(iso).genus_full.fillna('unassigned').tolist(), dtype=object)
study = np.array(aud.Reference.fillna('NA').tolist(), dtype=object)

def rarefy(M, depth, seed):
    rng = np.random.default_rng(seed); M = M.tocsc(); rows, cols, vals = [], [], []
    for j in range(M.shape[1]):
        s, e = M.indptr[j], M.indptr[j+1]; c = M.data[s:e].astype(np.int64)
        if c.sum() < depth: continue
        d = rng.multivariate_hypergeometric(c, depth); k = d > 0
        rows.append(M.indices[s:e][k]); cols.append(np.full(k.sum(), j)); vals.append(d[k])
    return sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=M.shape)

def load(ds):
    if ds == 'meta':
        feats = pd.read_csv('work/meta_features.csv').fid.tolist()
        samples = pd.read_csv('work/meta_samples.csv', header=None)[0].tolist(); depth = 1000
        R = sp.load_npz('work/meta_rare_s1.npz').tocsr()
    else:
        bf = pd.read_csv('work/bf_raw.csv', index_col=0); bf = bf.loc[:, bf.sum(axis=0) >= 10]
        depth = int(bf.sum(axis=0).min()); feats = bf.index.tolist(); samples = bf.columns.tolist()
        R = rarefy(sp.csc_matrix(bf.values.round().astype(np.int64)), depth, 1).tocsr()
    return feats, samples, depth, R

def hitmat(ds, feats, qcov_full):
    ex = pd.read_csv(f'work/{ds}_exh099.tsv', sep='\t', header=None, names=['q', 'r', 'id', 'alnlen', 'qcov'])
    ex['q'] = ex.q.str.split(';').str[0]; ex = ex[ex.id >= 99.0 - 1e-9]
    if qcov_full: ex = ex[ex.qcov >= 100.0 - 1e-9]
    fi = {f: i for i, f in enumerate(feats)}
    H = sp.csr_matrix((np.ones(len(ex), np.float32), (ex.q.map(fi).values, ex.r.map(ii).values)), shape=(len(feats), NI))
    return H

def perms(kind, rng):
    """Return (NI x B) array of permuted Func-index (permutation of isolate indices)."""
    P = np.empty((NI, B), np.int32)
    groups = {'global': np.zeros(NI, int), 'genus': pd.factorize(genus)[0], 'study': pd.factorize(study)[0]}[kind]
    idx_by = [np.where(groups == g)[0] for g in np.unique(groups)]
    for b in range(B):
        p = np.arange(NI)
        for ix in idx_by:
            if len(ix) > 1: p[ix] = ix[rng.permutation(len(ix))]
        P[:, b] = p
    return P

def metrics_from_labels(Hf, Ha, R, depth, inh, tst):
    """Hf: full-query-coverage hits; Ha: any-coverage hits. inh, tst: NI x k float arrays.
    Returns per-sample proportions (samples x k): any-hit (Hf), majority (Hf), majority_r1 (Ha)."""
    RT = R.T.tocsr(); out = []
    n_inh = np.asarray(Hf @ inh); out.append((n_inh > 0).astype(np.float32))
    for H in (Hf, Ha):
        n_inh = np.asarray(H @ inh); n_t = np.asarray(H @ tst)
        with np.errstate(invalid='ignore', divide='ignore'): out.append((np.nan_to_num(n_inh / n_t) > 0.5).astype(np.float32))
    return [np.asarray(RT @ x) / depth for x in out]

mp = pd.read_csv(MAP, sep='\t', dtype=str).set_index('#SampleID')
CONTR = [('lifestage', 'adult', 'larvae'), ('country', 'madagascar', 'usa'), ('host_scientific_name', 'anaxyrus boreas', 'lithobates catesbeianus')]
def rb(X, ga, gb):
    """rank-biserial r (=2U/(n1 n2)-1, a vs b) and MWU p for columns of X."""
    x, y = X[ga], X[gb]
    U, p = stats.mannwhitneyu(x, y, alternative='two-sided', axis=0)
    return 2 * U / (len(x) * len(y)) - 1, p

res = {}; check = {}
for ds in ('meta', 'bf'):
    feats, samples, depth, R = load(ds)
    r1s = pd.read_csv(R1META_S if ds == 'meta' else R1BF_S, index_col=0).reindex(samples)
    r1l = pd.read_csv(R1META_L if ds == 'meta' else R1BF_L, index_col=0).reindex(feats)
    pipe_feat = r1l.pipeline_inhibitory_ref.notna().values
    inh0 = (func == 'Inhibitory').astype(np.float32)[:, None]; tst0 = TESTED.astype(np.float32)[:, None]
    present = np.asarray(R.sum(1)).ravel() > 0
    Hs = {qc: hitmat(ds, feats, qc) for qc in (False, True)}
    for qc in (False, True):
        H = Hs[qc]
        anyf = np.asarray(H @ inh0).ravel() > 0
        a_obs, _, m_obs = metrics_from_labels(H, H, R, depth, inh0, tst0)
        check[(ds, 'qcov100' if qc else 'any_cov')] = dict(
            n_features=len(feats), n_present=int(present.sum()),
            feat_agree_all=float((anyf == pipe_feat).mean()), n_anyhit_inh=int(anyf.sum()), n_pipe_inh=int(pipe_feat.sum()),
            n_anyhit_not_pipe=int((anyf & ~pipe_feat).sum()), n_pipe_not_anyhit=int((~anyf & pipe_feat).sum()),
            n_anyhit_not_pipe_present=int((anyf & ~pipe_feat & present).sum()), n_pipe_not_anyhit_present=int((~anyf & pipe_feat & present).sum()),
            feat_agree_present=float((anyf == pipe_feat)[present].mean()),
            sample_exact_equal=float(np.mean(np.isclose(a_obs.ravel(), r1s.Inhibitory_Proportion.values))),
            sample_max_absdiff=float(np.nanmax(np.abs(a_obs.ravel() - r1s.Inhibitory_Proportion.values))),
            sample_spearman=float(stats.spearmanr(a_obs.ravel(), r1s.Inhibitory_Proportion.values)[0]),
            sample_pearson=float(np.corrcoef(a_obs.ravel(), r1s.Inhibitory_Proportion.values)[0, 1]),
            majority_max_absdiff_vs_r1=float(np.nanmax(np.abs(m_obs.ravel() - r1s.Majority_Proportion.values))))
        print(ds, 'qcov100' if qc else 'any_cov', check[(ds, 'qcov100' if qc else 'any_cov')], flush=True)
    Hf, Ha = Hs[True], Hs[False]
    a_obs, m_obs, m1_obs = [x.ravel() for x in metrics_from_labels(Hf, Ha, R, depth, inh0, tst0)]
    pipe_obs = r1s.Inhibitory_Proportion.values
    res[ds] = dict(samples=samples, obs_any=a_obs, obs_maj=m_obs, obs_maj_r1=m1_obs, obs_pipeline=pipe_obs, obs_full=r1s.Full_Proportion.values, null={})
    if ds == 'meta':
        md = mp.reindex(samples)
        G = [((md[c] == a).values, (md[c] == b).values) for c, a, b in CONTR]
        res[ds]['contrast_obs'] = {f'{c}: {a} vs {b}': {k: rb(v[:, None], *g) for k, v in (('any', a_obs), ('maj', m_obs), ('maj_r1', m1_obs), ('pipeline', pipe_obs))}
                                   for (c, a, b), g in zip(CONTR, G)}
        res[ds]['contrast_n'] = {f'{c}: {a} vs {b}': (int(g[0].sum()), int(g[1].sum())) for (c, a, b), g in zip(CONTR, G)}
    for kind in ('global', 'genus', 'study'):
        rng = np.random.default_rng({'global': 11, 'genus': 12, 'study': 13}[kind] + (0 if ds == 'meta' else 100))
        P = perms(kind, rng)
        NA = np.zeros((len(samples), B), np.float32); NM = np.zeros_like(NA); NM1 = np.zeros_like(NA)
        for s0 in range(0, B, 100):
            Pb = P[:, s0:s0+100]
            a, m, m1 = metrics_from_labels(Hf, Ha, R, depth, (func[Pb] == 'Inhibitory').astype(np.float32), TESTED[Pb].astype(np.float32))
            NA[:, s0:s0+100] = a; NM[:, s0:s0+100] = m; NM1[:, s0:s0+100] = m1
        res[ds]['null'][kind] = dict(any=NA, maj=NM, maj_r1=NM1, n_inh_isolates_perm=int((func[P[:, 0]] == 'Inhibitory').sum()),
                                     frac_isolates_label_changed=float(np.mean(func[P] != func[:, None])))
        if ds == 'meta':
            res[ds]['null'][kind]['contrast'] = {f'{c}: {a} vs {b}': {'any': rb(NA, *g), 'maj': rb(NM, *g), 'maj_r1': rb(NM1, *g)} for (c, a, b), g in zip(CONTR, G)}
        print(ds, kind, 'done', flush=True)
pickle.dump(dict(res=res, check=check), open('out/perm_null.pkl', 'wb'))
print('saved')
