#!/bin/bash
# Genus classification of AmphiBac 2025.1 isolates (stored full sequences) and of their 120-bp / full-V4 515F fragments
# (frag/q_*_all.fasta from round-1 lt_01_fragments.py) with vsearch 2.32.0 SINTAX against the RDP 16S training set v18
# (https://www.drive5.com/sintax/rdp_16s_v18.fa.gz, 21,195 seqs, md5 5c19acf75020ec023fe4dd8f9c98fdec). Cutoff 0.8.
# Three single-threaded jobs run concurrently (CPU cap 3); --randseed 1 with --threads 1 is reproducible.
# vsearch strips 8 non-nucleotide characters (I,L,O) from the RDP file on load.
set -e; cd "$(dirname "$0")"; mkdir -p sintax
S="--db ref/rdp_16s_v18.fa --sintax_cutoff 0.8 --strand both --threads 1 --randseed 1 --minseqlength 1 --quiet"
vsearch --sintax db/FullDatabase_2025.1.fasta $S --tabbedout sintax/full.tsv &
vsearch --sintax frag/q_120_all.fasta $S --tabbedout sintax/frag_120.tsv &
vsearch --sintax frag/q_V4full_all.fasta $S --tabbedout sintax/frag_V4full.tsv &
wait; echo SINTAX_DONE
