"""Summarise out/perm_null.pkl: per-sample observed vs null, and contrast null distributions. Run from r2/."""
import pickle, numpy as np, pandas as pd
from scipy import stats
res = pickle.load(open('out/perm_null.pkl', 'rb'))['res']
rows = []; ps_rows = []
for ds in ('meta', 'bf'):
    r = res[ds]
    for met, obs in (('any', r['obs_any']), ('maj', r['obs_maj']), ('maj_r1', r['obs_maj_r1'])):
        for kind in ('global', 'genus', 'study'):
            N = r['null'][kind][met].astype(float)
            mu = N.mean(1); sd = N.std(1); p95 = np.percentile(N, 95, axis=1)
            lt = (N < obs[:, None] - 1e-12).sum(1); eq = (np.abs(N - obs[:, None]) <= 1e-12).sum(1)
            pct = (lt + 0.5 * eq) / N.shape[1]; pup = (1 + (N >= obs[:, None] - 1e-12).sum(1)) / (N.shape[1] + 1)
            with np.errstate(all='ignore'): z = (obs - mu) / sd
            has = (N.max(1) > 0) | (obs > 0)
            q = stats.false_discovery_control(pup)
            rows.append(dict(dataset=ds, metric=met, shuffle=kind, n_samples=len(obs), n_samples_nonzero=int(has.sum()),
                obs_median=np.median(obs), null_mean_median=np.median(mu),
                pct_samples_obs_gt_null95=100 * np.mean(obs > p95 + 1e-12), pct_nonzero_samples_obs_gt_null95=100 * np.mean((obs > p95 + 1e-12)[has]),
                pct_samples_obs_lt_null5=100 * np.mean(obs < np.percentile(N, 5, axis=1) - 1e-12),
                pct_samples_upper_p_lt_005=100 * np.mean(pup < 0.05), pct_samples_BH_q_lt_005=100 * np.mean(q < 0.05),
                median_percentile=np.median(pct[has]), median_z=np.nanmedian(z[has]),
                spearman_obs_vs_nullmean=stats.spearmanr(obs, mu)[0], pearson_obs_vs_nullmean=np.corrcoef(obs, mu)[0, 1],
                spearman_nullmean_vs_FullProportion=stats.spearmanr(mu, r['obs_full'])[0],
                median_obs_minus_nullmean=np.median((obs - mu)[has])))
            for i, s in enumerate(r['samples']):
                ps_rows.append(dict(dataset=ds, SampleID=s, metric=met, shuffle=kind, observed=obs[i], null_mean=mu[i], null_sd=sd[i],
                                    null_p95=p95[i], percentile=pct[i], z=z[i], p_upper=pup[i]))
S = pd.DataFrame(rows); S.to_csv('out/null_per_sample_summary.csv', index=False)
pd.DataFrame(ps_rows).to_csv('out/null_per_sample_long.csv.gz', index=False)
r = res['meta']; crow = []
for c, ob in r['contrast_obs'].items():
    na, nb = r['contrast_n'][c]
    for met in ('any', 'maj', 'maj_r1'):
        ro, po = [float(np.ravel(x)[0]) for x in ob[met]]
        for kind in ('global', 'genus', 'study'):
            rn, pn = r['null'][kind]['contrast'][c][met]
            crow.append(dict(contrast=c, n_a=na, n_b=nb, metric=met, shuffle=kind, r_obs=ro, p_obs=po,
                null_r_median=np.median(rn), null_r_lo=np.percentile(rn, 2.5), null_r_hi=np.percentile(rn, 97.5),
                pct_null_p_lt_005=100 * np.mean(pn < 0.05), pct_null_sig_same_dir=100 * np.mean((pn < 0.05) & (np.sign(rn) == np.sign(ro))),
                p_perm_abs=(1 + np.sum(np.abs(rn - np.median(rn)) >= abs(ro - np.median(rn)))) / (len(rn) + 1),
                p_perm_abs_r=(1 + np.sum(np.abs(rn) >= abs(ro))) / (len(rn) + 1), pct_null_r_ge_obs_dir=100 * np.mean(np.sign(ro) * rn >= abs(ro))))
    ro, po = [float(np.ravel(x)[0]) for x in ob['pipeline']]
    crow.append(dict(contrast=c, n_a=na, n_b=nb, metric='pipeline_observed', shuffle='none', r_obs=ro, p_obs=po))
pd.DataFrame(crow).to_csv('out/null_contrasts.csv', index=False)
print(S.round(3).to_string())
