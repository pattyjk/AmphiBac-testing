"""Round 2: genus-only baseline vs round-1 99%-identity rules.
Genus: vsearch SINTAX (RDP v18, cutoff 0.8) of each isolate's stored full sequence (genus_full) and of its own
515F fragment (genus_frag, for 120 bp and full V4).
Prediction for a held-out isolate: majority Func among tested (Inhibitory/NoEffect/Facilitating) isolates of the same
genus, excluding itself ('self') or excluding all isolates from its study ('study'); Inhibitory iff frac_inh > 0.5;
no genus / no other genus members -> non-inhibitory (basis 'all', as round 1).
Query sets = round-1 pred_per_query rows (fragment 120 and V4full, threshold 0.99, IUPAC-free), so R1/R2/R4 are scored on
identical isolates and the same study-cluster bootstrap weights (B=1000, 28 / 26 studies).
Run from r2/: python g02_genus_baseline.py <pred_per_query.csv.gz> <r1 lt_metrics_long.csv>"""
import sys, re, numpy as np, pandas as pd
PRED, R1MET = sys.argv[1:3]; B = 1000
TESTED = ['Inhibitory', 'NoEffect', 'Facilitating']
aud = pd.read_csv('db/audit_per_sequence.csv', index_col=0)

def parse_sintax(path):
    t = pd.read_csv(path, sep='\t', header=None, names=['id', 'raw', 'strand', 'tax'], dtype=str)
    t['id'] = t.id.str.split().str[0]
    def rank(s, r):
        if not isinstance(s, str): return np.nan
        m = re.search(rf'(?:^|,){r}:([^,]+)', s); return m.group(1) if m else np.nan
    def rawconf(s, r):
        if not isinstance(s, str): return np.nan
        m = re.search(rf'(?:^|,){r}:([^,(]+)\(([0-9.]+)\)', s); return (m.group(1), float(m.group(2))) if m else (np.nan, np.nan)
    out = pd.DataFrame({'id': t.id})
    for r, nm in [('p', 'phylum'), ('f', 'family'), ('g', 'genus')]:
        out[nm] = t.tax.map(lambda s: rank(s, r))
    rc = t.raw.map(lambda s: rawconf(s, 'g'))
    out['genus_raw_best'] = [x[0] if isinstance(x, tuple) else np.nan for x in rc]
    out['genus_raw_conf'] = [x[1] if isinstance(x, tuple) else np.nan for x in rc]
    return out.set_index('id')

full = parse_sintax('sintax/full.tsv')
G = aud[['length', 'Func', 'Bd_label', 'score', 'Reference', 'strand_in_db']].join(
    full.rename(columns=lambda c: c + ('_full' if c in ('phylum', 'family', 'genus') else '_full')))
for f in ('120', 'V4full'):
    fr = parse_sintax(f'sintax/frag_{f}.tsv')
    G[f'genus_frag{f}'] = fr.genus.reindex(G.index); G[f'genus_frag{f}_conf'] = fr.genus_raw_conf.reindex(G.index)
G.index.name = 'FastaID'; G.to_csv('out/genus_assignments.csv')
print('isolates', len(G), 'genus-assigned (full, 0.8):', int(G.genus_full.notna().sum()),
      'tested & assigned', int((G.genus_full.notna() & G.Func.isin(TESTED)).sum()), flush=True)
for f in ('120', 'V4full'):
    ok = G[f'genus_frag{f}'].notna() & G.genus_full.notna()
    print(f, 'frag assigned', int(G[f'genus_frag{f}'].notna().sum()), 'agree with full where both', float((G.loc[ok, f'genus_frag{f}'] == G.loc[ok, 'genus_full']).mean()))

# ---- heterogeneity in 20 largest genera (tested isolates)
T = G[G.Func.isin(TESTED) & G.genus_full.notna()]
het = T.groupby('genus_full').agg(n=('Func', 'size'), n_studies=('Reference', 'nunique'),
        n_inhibitory=('Func', lambda s: (s == 'Inhibitory').sum()), n_noeffect=('Func', lambda s: (s == 'NoEffect').sum()),
        n_facilitating=('Func', lambda s: (s == 'Facilitating').sum()), median_score=('score', 'median'),
        iqr_score=('score', lambda s: s.quantile(.75) - s.quantile(.25)))
het['pct_inhibitory'] = 100 * het.n_inhibitory / het.n; het['pct_facilitating'] = 100 * het.n_facilitating / het.n
het['majority_label'] = het[['n_inhibitory', 'n_noeffect', 'n_facilitating']].idxmax(axis=1).str[2:]
# per-study % inhibitory spread within genus (studies with >=5 isolates of the genus)
def study_spread(d):
    s = d.groupby('Reference').Func.agg(lambda x: 100 * (x == 'Inhibitory').mean())[d.groupby('Reference').size() >= 5]
    return pd.Series({'n_studies_ge5': len(s), 'study_pct_inh_min': s.min() if len(s) else np.nan, 'study_pct_inh_max': s.max() if len(s) else np.nan})
het = het.join(T.groupby('genus_full').apply(study_spread, include_groups=False))
het = het.sort_values('n', ascending=False); het.to_csv('out/genus_heterogeneity_all.csv')
top20 = het.head(20); top20.to_csv('out/genus_heterogeneity_top20.csv'); print(top20[['n', 'n_studies', 'pct_inhibitory', 'pct_facilitating']].round(1).to_string())

# ---- genus-majority prediction
def genus_pred(Q, gcol_query, excl):
    """Q: query rows (FastaID, Reference). Reference pool: tested isolates with genus_full."""
    pool = G[G.Func.isin(TESTED) & G.genus_full.notna()]
    cnt = pool.groupby('genus_full').Func.agg(n='size', ninh=lambda s: (s == 'Inhibitory').sum())
    cst = pool.groupby(['genus_full', 'Reference']).Func.agg(n='size', ninh=lambda s: (s == 'Inhibitory').sum())
    g = G.loc[Q.FastaID, gcol_query].values; ref = Q.Reference.values
    selfin = G.loc[Q.FastaID].Func.isin(TESTED).values & G.loc[Q.FastaID].genus_full.notna().values & (G.loc[Q.FastaID].genus_full.values == g)
    selfinh = (G.loc[Q.FastaID].Func.values == 'Inhibitory') & selfin
    n = np.array([cnt.n.get(x, 0) if isinstance(x, str) else 0 for x in g], float)
    k = np.array([cnt.ninh.get(x, 0) if isinstance(x, str) else 0 for x in g], float)
    if excl == 'self': n -= selfin; k -= selfinh
    else:
        idx = list(zip(g, ref))
        n -= np.array([cst.n.get(t, 0) if isinstance(t[0], str) else 0 for t in idx]); k -= np.array([cst.ninh.get(t, 0) if isinstance(t[0], str) else 0 for t in idx])
    with np.errstate(invalid='ignore', divide='ignore'): fr = k / n
    return np.nan_to_num(fr) > 0.5, n > 0, fr

def bin_stats(TP, FP, TN, FN):
    n = TP + FP + TN + FN
    with np.errstate(all='ignore'):
        se = TP / (TP + FN); spc = TN / (TN + FP); pe = ((TP + FP) * (TP + FN) + (FN + TN) * (FP + TN)) / n**2; acc = (TP + TN) / n
        return dict(n_scored=n, accuracy=acc, sensitivity=se, specificity=spc, PPV=TP / (TP + FP), NPV=TN / (TN + FN),
                    balanced_accuracy=(se + spc) / 2, kappa=(acc - pe) / (1 - pe), pred_inhibitory_rate=(TP + FP) / n)

P = pd.read_csv(PRED, low_memory=False); P['iupac'] = P.iupac.astype(bool)
P = P[(P.t == 0.99) & P.frag.isin(['120', 'V4full']) & ~P.iupac]
rows = []; per_iso = []; rng = np.random.default_rng(2026)
for f in ('120', 'V4full'):
    studies = None
    for excl in ('self', 'study'):
        D = P[(P.frag == f) & (P.excl == excl)].copy().reset_index(drop=True)
        if studies is None:
            studies = np.array(sorted(D.Reference.unique())); S = len(studies); W = rng.multinomial(S, np.ones(S) / S, size=B)
        si = pd.Categorical(D.Reference, categories=studies).codes
        y = (D.Func == 'Inhibitory').values
        rules = {'R1_tophit': ((D.R1_3 == 'Inhibitory').values, D.R1_hit.notna().values),
                 'R2_Inhibitory_subset': (D.R2.astype(bool).values, D.R2.astype(bool).values),
                 'R4_majority99': (D.R4_bin.astype(bool).values, D.R4_has.astype(bool).values)}
        for gq in ('genus_full', f'genus_frag{f}'):
            p, has, fr = genus_pred(D, gq, excl)
            nm = 'G_genus_majority_fullseq' if gq == 'genus_full' else 'G_genus_majority_fragment'
            rules[nm] = (p, has); D[nm] = p; D[nm + '_frac'] = fr; D[nm + '_has'] = has
        D['R1_bin'] = rules['R1_tophit'][0]
        per_iso.append(D[['FastaID', 'frag', 'excl', 'Func', 'Reference', 'R1_bin', 'R2', 'R4_bin'] + [c for c in D.columns if c.startswith('G_')]])
        for rule, (pred, has) in rules.items():
            cnt = np.zeros((S, 4))
            for j, v in enumerate([y & pred, ~y & pred, ~y & ~pred, y & ~pred]): np.add.at(cnt[:, j], si, v)
            pt = bin_stats(*cnt.sum(0)); bs = bin_stats(*(W @ cnt).T)
            for m, v in pt.items():
                lo, hi = (np.nanpercentile(bs[m], [2.5, 97.5]) if m != 'n_scored' else (np.nan, np.nan))
                rows.append(dict(fragment=f, exclusion=excl, rule=rule, metric=m, value=float(v), ci_lo=lo, ci_hi=hi,
                                 n_queries=len(D), n_studies=S, match_rate=float(has.mean())))
        # paired bootstrap: kappa(genus fullseq) - kappa(R4), kappa(genus) - kappa(R1)
        def kap(pred):
            cnt = np.zeros((S, 4))
            for j, v in enumerate([y & pred, ~y & pred, ~y & ~pred, y & ~pred]): np.add.at(cnt[:, j], si, v)
            return bin_stats(*cnt.sum(0))['kappa'], bin_stats(*(W @ cnt).T)['kappa']
        kg, kgb = kap(rules['G_genus_majority_fullseq'][0])
        for other in ('R1_tophit', 'R4_majority99', 'R2_Inhibitory_subset'):
            ko, kob = kap(rules[other][0]); d = kgb - kob
            rows.append(dict(fragment=f, exclusion=excl, rule=f'diff_G_fullseq_minus_{other}', metric='kappa_diff', value=kg - ko,
                             ci_lo=np.nanpercentile(d, 2.5), ci_hi=np.nanpercentile(d, 97.5), n_queries=len(D), n_studies=S,
                             match_rate=float(np.mean(d > 0))))
M = pd.DataFrame(rows); M.to_csv('out/genus_baseline_metrics_long.csv', index=False)
pd.concat(per_iso).to_csv('out/genus_baseline_per_isolate.csv.gz', index=False)
# check round-1 point estimates reproduced
r1 = pd.read_csv(R1MET); r1 = r1[(r1.threshold == 0.99) & (r1.iupac == 'clean') & (r1.truth == 'Func') & (r1.classes == 'binary') & (r1.basis == 'all') & r1.fragment.isin(['120', 'V4full'])]
chk = M[M.rule.isin(['R1_tophit', 'R4_majority99', 'R2_Inhibitory_subset'])].replace({'R4_majority99': 'R4_majority', 'R2_Inhibitory_subset': 'R2_Inhibitory'}).merge(
    r1, left_on=['fragment', 'exclusion', 'rule', 'metric'], right_on=['fragment', 'exclusion', 'rule', 'metric'], suffixes=('', '_r1'))
print('round-1 point estimates reproduced (max abs diff):', float((chk.value - chk.value_r1).abs().max()), 'n compared', len(chk))
W_ = M[M.metric.isin(['kappa', 'sensitivity', 'specificity', 'PPV', 'balanced_accuracy'])].pivot_table(index=['fragment', 'exclusion', 'rule'], columns='metric', values='value')
print(W_.round(3).to_string())
print(M[M.metric == 'kappa_diff'][['fragment', 'exclusion', 'rule', 'value', 'ci_lo', 'ci_hi']].round(3).to_string())
