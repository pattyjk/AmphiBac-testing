"""Round 3 prospective figure: kappa (basis 'all') by window, rows = cohort (added after 2020.6 / 2023.2), cols = isolate set.
Error bars = isolate-bootstrap 95% CI (study clusters are only 1-5 per cell, so study CIs are not drawn). Windows with n < 30 omitted.
Usage: python p3_04_figure.py <threshold> <out.png>   (kernel must provide apply_figure_style; run via exec in the figure-style kernel)"""
import sys, pandas as pd, numpy as np, matplotlib.pyplot as plt
TH, OUT = sys.argv[1], sys.argv[2]
WIN = ['V4_254','V3V4_429','V3V4_500','V2V3_410','V2V4_600','V1V4_700','V4V5_374','V5V6_281','V6V8_431','V2V8_1100']
RULES = [('R1_tophit','R1 default top hit','#1B9E77','o'), ('R2_Inhibitory','R2 hit to Inhibitory','#D95F02','s'),
         ('R3_InhibitoryStrict','R3 hit to InhibitoryStrict','#7570B3','D'), ('R4_majority_fullcov','R4 majority, full-coverage hits','#E7298A','^'),
         ('Genus_majority','Genus majority (older release)','#555555','v')]
M = pd.read_csv('prosp/p3_metrics_long.csv', dtype={'threshold': str})
K = M[(M.metric == 'kappa') & (M.basis == 'all') & (M.threshold == TH)]
fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.0), sharey=True, gridspec_kw=dict(width_ratios=[7, 6], wspace=0.06, hspace=0.55))
for i, coh in enumerate(['new_vs_2020.6', 'new_vs_2023.2']):
    for j, pan in enumerate(['all_available', 'added_panel6']):
        ax = axes[i, j]; d = K[(K.cohort == coh) & (K.panel == pan) & (K.n_queries >= 30)]
        ws = [w for w in WIN if w in set(d.window)]
        for r, (rule, lab, col, mk) in enumerate(RULES):
            e = d[d.rule == rule].set_index('window').reindex(ws)
            if e.value.isna().all(): continue
            x = np.arange(len(ws)) + (r - 2) * 0.14
            ax.errorbar(x, e.value, yerr=[e.value - e.ci_lo_isolate, e.ci_hi_isolate - e.value], fmt=mk, color=col, ms=4, lw=0.8, capsize=0,
                        mfc=col if rule != 'Genus_majority' else 'white', label=lab)
        ax.axhline(0, color='0.6', lw=0.6, zorder=0)
        nn = d.drop_duplicates('window').set_index('window')
        ax.set_xticks(range(len(ws))); ax.set_xticklabels([f"{w.split('_')[0]}\n{w.split('_')[1]} bp\nn={nn.n_queries[w]}\n{nn.n_studies[w]} stud." for w in ws])
        ax.set_xlim(-0.6, len(ws) - 0.4)
        ttl = {'all_available': 'All added isolates with this window', 'added_panel6': 'Same added isolates in all six windows'}[pan]
        ax.set_title(f"{ttl}\n(added after {coh.split('_')[-1]})", loc='left')
        if j == 0: ax.set_ylabel("Cohen's κ vs 2025.1 label")
axes[0, 0].set_ylim(-0.55, 0.6)
hl = {}
for a in axes.flat:
    for hh, ll in zip(*a.get_legend_handles_labels()): hl.setdefault(ll, hh)
l = [r[1] for r in RULES if r[1] in hl]; h = [hl[x] for x in l]
fig.legend(h, l, loc='lower center', ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.01))
fig.subplots_adjust(bottom=0.22, top=0.9, left=0.09, right=0.99)
fig.suptitle(f'Prospective prediction from the older release stays near chance in every window ({float(TH)*100:.0f}% identity)', x=0.01, ha='left')
fig.savefig(OUT, dpi=300, bbox_inches='tight')
