#!/bin/bash
# Round 3 prospective: exact pipeline call per older-release subset at id 0.99 and 1.00 (defaults maxaccepts 1 / maxrejects 32),
# plus one exhaustive search (maxaccepts 0 / maxrejects 0, id 0.99) vs older Full for R4. 3 threads total.
set -e; cd "$(dirname "$0")/.."; mkdir -p prosp/uc
F="query+target+id+mism+gaps+alnlen+ids+ql+tl+qilo+qihi+tilo+tihi+qstrand"
for coh in 2020.6 2023.2; do q=prosp/q_new${coh}.fasta
  for db in reldb/${coh}_*.fasta; do b=$(basename $db .fasta); b=${b#${coh}_}
    for t in 0.99 1.00; do
      vsearch --usearch_global $q --id $t --db $db --uc prosp/uc/${coh}_${b}_${t}.uc --strand both --qmask none \
        --notmatched prosp/uc/${coh}_${b}_${t}_nm.fasta --threads 3 --minseqlength 1 --fasta_width 0 --quiet
    done
  done
  vsearch --usearch_global $q --id 0.99 --db reldb/${coh}_FullDatabase.fasta --userout prosp/uc/${coh}_exh.tsv --userfields $F \
    --strand both --qmask none --maxaccepts 0 --maxrejects 0 --threads 3 --minseqlength 1 --quiet
done; echo DONE
