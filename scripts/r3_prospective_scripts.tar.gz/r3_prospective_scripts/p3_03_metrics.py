"""Round 3 prospective, step 3: score per-window predictions of added isolates from the older release.
Rules (round-1/2 definitions): R1 = older-release Func of the q2-default top hit (maxaccepts 1/maxrejects 32) in older Full;
R2 = any default hit in older Inhibitory (2023.2 only); R3 = any default hit in older InhibitoryStrict;
R4_fullcov = majority over all exhaustive hits with 100*ids/alnlen >= 100*t AND alignment spanning the whole query (qilo=1, qihi=ql),
tested refs only (Inh > NoEff+Facil; tie -> non-inh); R4_anycov = same without the coverage requirement (round-1/2 definition);
Genus = majority older-release label among older-release tested isolates of the query's genus (RDP v18 SINTAX of stored full sequence,
cutoff 0.8; round-2 genus_full), > 0.5 -> Inhibitory; window- and threshold-independent apart from the query set.
Truth = 2025.1 Func == Inhibitory. Basis 'all': no call -> non-inhibitory; 'matched': queries with a call only.
CIs: percentile bootstrap B=1000, study clusters (Reference | Researchers) and isolates.
Cohort sets: 'all_available' = every added isolate with a fragment in that window; 'added_panel6' = added isolates present in all six
windows V4_254, V3V4_429, V3V4_500, V2V3_410, V2V4_600, V1V4_700 (the round-3 fixed 1,397-isolate panel contains no added isolates)."""
import pandas as pd, numpy as np
WIN = ['V4_254','V3V4_429','V3V4_500','V2V3_410','V2V4_600','V1V4_700','V4V5_374','V5V6_281','V6V8_431','V2V8_1100']
P6 = WIN[:6]; CL = ['Inhibitory','NoEffect','Facilitating']; B = 1000; TH = ['0.99','1.00']
GEN = '/Users/p.kearns/.claude-science/orgs/02812373-138d-4a58-874b-33e46fa50871/artifacts/proj_16c61e02b61f/64b0299e-4dff-495e-84de-7e427b5d9ecc/v5f91e1d1_genus_assignments.csv'
T = pd.read_csv('isolate_release_table.csv', index_col=0)
m5 = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', dtype=str, encoding='latin1').set_index('FastaID')
T['study'] = T.Reference.fillna('NA') + ' | ' + m5.Researchers.fillna('NA').reindex(T.index)
G = pd.read_csv(GEN, index_col=0).genus_full
ID20 = dict(zip(m5['FastaID.2020'].str.lstrip('>'), m5.index))
OLDLAB = {'2020.6': T['label_2020.6'].dropna().to_dict(), '2023.2': T['label_2023.2'].dropna().to_dict()}
idx = pd.read_csv('frags/fragment_index.csv')
def tr(coh, r): return ID20.get(r, r) if coh == '2020.6' else r
def read_uc(p, coh):
    u = pd.read_csv(p, sep='\t', header=None, usecols=[0, 3, 8, 9], names=['t', 'id', 'q', 'h'], dtype=str); u = u[u.t == 'H']
    return pd.DataFrame({'hit': [tr(coh, h) for h in u.h], 'id': u.id.astype(float).values}, index=u.q.values)
def bin_stats(TP, FP, TN, FN, M, N):
    n = TP + FP + TN + FN
    with np.errstate(all='ignore'):
        se = TP / (TP + FN); sp = TN / (TN + FP); acc = (TP + TN) / n; pe = ((TP + FP) * (TP + FN) + (FN + TN) * (FP + TN)) / n**2
        return dict(match_rate=M / N, n_scored=n, accuracy=acc, sensitivity=se, specificity=sp, PPV=TP / (TP + FP), NPV=TN / (TN + FN),
                    balanced_accuracy=(se + sp) / 2, kappa=(acc - pe) / (1 - pe))
rng = np.random.default_rng(1); preds, rows, diag = [], [], []
for coh in ['2020.6', '2023.2']:
    old = T[T[f'in_{coh}']]; lab = OLDLAB[coh]
    pool = pd.DataFrame({'lab': pd.Series(lab).reindex(old.index), 'g': G.reindex(old.index)})
    pool = pool[pool.lab.isin(CL) & pool.g.notna()]
    gc = pool.groupby('g').lab.agg(n='size', ninh=lambda s: (s == 'Inhibitory').sum())
    new = set(T.index[T[f'new_vs_{coh}'] & T.Func_2025.isin(CL)])
    wi = idx[idx.FastaID.isin(new)]; pan6 = set.intersection(*[set(wi.FastaID[wi.window == w]) for w in P6])
    e = pd.read_csv(f'prosp/uc/{coh}_exh.tsv', sep='\t', names='q t id mism gaps alnlen ids ql tl qilo qihi tilo tihi qstrand'.split())
    e['t'] = [tr(coh, x) for x in e.t]; e['idx'] = 100 * e.ids / e.alnlen
    e['fullcov'] = (e.qilo == 1) & (e.qihi == e.ql); e['lab'] = e.t.map(lab)
    e = e.sort_values(['fullcov', 'idx'], ascending=False).drop_duplicates(['q', 't'])
    for t in TH:
        R1 = read_uc(f'prosp/uc/{coh}_FullDatabase_{t}.uc', coh)
        subs = {'R3': read_uc(f'prosp/uc/{coh}_InhibitoryStrict_{t}.uc', coh)}
        if coh == '2023.2': subs['R2'] = read_uc(f'prosp/uc/{coh}_Inhibitory_{t}.uc', coh)
        E = e[e.idx >= 100 * float(t)]
        for w in WIN:
            ids = sorted(set(wi.FastaID[wi.window == w]))
            if not ids: continue
            D = pd.DataFrame(index=ids); D['q'] = [f'{i}|{w}' for i in ids]
            D['study'] = T.study.reindex(ids); D['truth'] = T.Func_2025.reindex(ids); D['panel6'] = D.index.isin(pan6)
            D['new_study'] = T[f'new_study_vs_{coh}'].reindex(ids)
            h = R1.reindex(D.q); D['R1_hit'] = h.hit.values; D['R1_id'] = h.id.values
            D['R1_label'] = D.R1_hit.map(lab); D['R1_has'] = D.R1_hit.notna(); D['R1'] = D.R1_label.eq('Inhibitory')
            D['R1_untested'] = D.R1_has & ~D.R1_label.isin(CL)
            ee = E.set_index(['q', 't'])
            cov = e.set_index(['q', 't']).fullcov.reindex(list(zip(D.q, D.R1_hit)))
            D['R1_partialcov'] = np.where(D.R1_has, ~cov.fillna(False).astype(bool).values, np.nan)
            for r, s in subs.items(): D[r] = D.q.isin(s.index); D[f'{r}_has'] = D[r]
            for nm, sel in [('R4_fullcov', E.fullcov), ('R4_anycov', np.ones(len(E), bool))]:
                Q = E[sel & E.lab.isin(CL)]
                vc = Q.groupby(['q', 'lab']).size().unstack(fill_value=0).reindex(columns=CL, fill_value=0).reindex(D.q).fillna(0)
                D[f'{nm}_has'] = (vc.sum(1) > 0).values; D[nm] = (vc.Inhibitory > vc.NoEffect + vc.Facilitating).values
                D[f'{nm}_nqual'] = vc.sum(1).values
            g = G.reindex(ids); n = gc.n.reindex(g).fillna(0).values; k = gc.ninh.reindex(g).fillna(0).values
            D['genus'] = g.values; D['Genus_has'] = n > 0
            with np.errstate(all='ignore'): D['Genus'] = np.nan_to_num(k / n) > 0.5
            D['cohort'] = f'new_vs_{coh}'; D['threshold'] = t; D['window'] = w
            preds.append(D.reset_index().rename(columns={'index': 'FastaID'}))
            rules = [('R1_tophit', 'R1'), ('R2_Inhibitory', 'R2'), ('R3_InhibitoryStrict', 'R3'), ('R4_majority_fullcov', 'R4_fullcov'),
                     ('R4_majority_anycov', 'R4_anycov'), ('Genus_majority', 'Genus')]
            for pset in ['all_available', 'added_panel6']:
                DD = D if pset == 'all_available' else D[D.panel6]
                if len(DD) == 0: continue
                diag.append(dict(cohort=f'new_vs_{coh}', threshold=t, window=w, panel=pset, n=len(DD), n_inh=int(DD.truth.eq('Inhibitory').sum()),
                    n_studies=DD.study.nunique(), R1_match=DD.R1_has.mean(), R1_hit_untested=DD.R1_untested.mean(),
                    R1_hit_partial_query_cov=pd.to_numeric(DD.R1_partialcov, errors='coerce').mean(),
                    R4_fullcov_has=DD.R4_fullcov_has.mean(), R4_anycov_has=DD.R4_anycov_has.mean(), genus_in_pool=DD.Genus_has.mean()))
                y = DD.truth.eq('Inhibitory').values; studies = np.array(sorted(DD.study.unique())); S = len(studies)
                si = pd.Categorical(DD.study, categories=studies).codes
                Ws = rng.multinomial(S, np.ones(S) / S, size=B); Wi = rng.multinomial(len(DD), np.ones(len(DD)) / len(DD), size=B)
                for name, pc in rules:
                    if pc not in DD: continue
                    pred = DD[pc].astype(bool).values; has = DD[f'{pc}_has'].astype(bool).values
                    for basis in (['all', 'matched'] if pc in ('R1', 'R4_fullcov', 'R4_anycov', 'Genus') else ['all']):
                        kk = np.ones(len(y), bool) if basis == 'all' else has
                        cnt = np.zeros((len(y), 6)); cnt[:, 0] = y & pred & kk; cnt[:, 1] = ~y & pred & kk; cnt[:, 2] = ~y & ~pred & kk
                        cnt[:, 3] = y & ~pred & kk; cnt[:, 4] = has; cnt[:, 5] = 1
                        cs = np.zeros((S, 6)); np.add.at(cs, si, cnt)
                        pt = bin_stats(*cnt.sum(0)); bs = bin_stats(*(Ws @ cs).T); bi = bin_stats(*(Wi @ cnt).T)
                        for m, v in pt.items():
                            ok = m != 'n_scored' and S > 1
                            lo, hi = np.nanpercentile(bs[m], [2.5, 97.5]) if ok else (np.nan, np.nan)
                            ilo, ihi = np.nanpercentile(bi[m], [2.5, 97.5]) if m != 'n_scored' else (np.nan, np.nan)
                            rows.append(dict(cohort=f'new_vs_{coh}', older_release=coh, window=w, panel=pset, threshold=t, rule=name, basis=basis,
                                metric=m, value=v, ci_lo_study=lo, ci_hi_study=hi, ci_lo_isolate=ilo, ci_hi_isolate=ihi, n_queries=len(y),
                                n_inhibitory_truth=int(y.sum()), n_studies=S, TP=int(cnt[:, 0].sum()), FP=int(cnt[:, 1].sum()),
                                TN=int(cnt[:, 2].sum()), FN=int(cnt[:, 3].sum()), low_n_flag=len(y) < 30 or S < 3))
    print(coh, 'added_panel6 size', len(pan6), flush=True)
pd.concat(preds, ignore_index=True).to_csv('prosp/p3_predictions_per_isolate.csv.gz', index=False)
M = pd.DataFrame(rows); M.to_csv('prosp/p3_metrics_long.csv', index=False); Dg = pd.DataFrame(diag); Dg.to_csv('prosp/p3_diagnostics.csv', index=False)
pd.set_option('display.width', 250)
k = M[(M.metric == 'kappa') & (M.basis == 'all') & (M.threshold == '0.99')]
print(k.pivot_table(index=['cohort', 'panel', 'window'], columns='rule', values='value').round(3).to_string())
print(Dg[Dg.threshold == '0.99'].round(3).to_string())
