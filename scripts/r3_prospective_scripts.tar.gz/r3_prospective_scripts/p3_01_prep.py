"""Round 3 prospective, step 1: per-window query FASTAs of isolates added after 2020.6 / 2023.2.
Added-isolate flags and older-release labels are taken from the round-2 isolate_release_table.csv (2020.6 -> 2025.1 via FastaID.2020;
2023.2 FastaIDs identical). Queries = window fragments from the round-3 bundle (tested isolates only, IUPAC-free, E. coli orientation)
of isolates new vs the cohort's older release. Query header = FastaID|window."""
import pandas as pd
from Bio import SeqIO
WIN = ['V4_254','V3V4_429','V3V4_500','V2V3_410','V2V4_600','V1V4_700','V4V5_374','V5V6_281','V6V8_431','V2V8_1100']
CL = ['Inhibitory','NoEffect','Facilitating']
T = pd.read_csv('isolate_release_table.csv', index_col=0)
idx = pd.read_csv('frags/fragment_index.csv')
rows = []
for coh in ['2020.6','2023.2']:
    new = set(T.index[T[f'new_vs_{coh}'] & T.Func_2025.isin(CL)])
    with open(f'prosp/q_new{coh}.fasta','w') as h:
        for w in WIN:
            n = 0
            for r in SeqIO.parse(f'frags/{w}.fasta','fasta'):
                if r.id in new: h.write(f'>{r.id}|{w}\n{str(r.seq).upper()}\n'); n += 1
            p = idx[(idx.window==w) & idx.FastaID.isin(new)]
            rows.append(dict(cohort=f'new_vs_{coh}', window=w, n_new_tested=len(new), n_in_window=n, n_panel_all10=int(p.panel_all10.sum())))
R = pd.DataFrame(rows); R.to_csv('prosp/query_counts.csv', index=False); print(R.to_string())
