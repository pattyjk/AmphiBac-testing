#!/bin/bash
# 300 shuffled-Full runs per dataset (seeds 1-300) + 100 shuffled-Inhibitory runs (seeds 1-100); P parallel single-thread jobs
P=${1:-4}
{
for s in $(seq 1 25 276); do e=$((s+25)); echo "bf FullDatabase $s $e work/bf_query.fasta"; echo "serdp FullDatabase $s $e work/serdp_query.fasta"; echo "meta FullDatabase $s $e work/metahit_query.fasta"; done
for s in $(seq 1 25 76); do e=$((s+25)); echo "bf Inhibitory $s $e work/bf_query.fasta"; echo "serdp Inhibitory $s $e work/serdp_query.fasta"; echo "meta Inhibitory $s $e work/metahit_query.fasta"; done
echo "bf Inhibitory 0 1 work/bf_query.fasta"; echo "serdp Inhibitory 0 1 work/serdp_query.fasta"; echo "meta Inhibitory 0 1 work/metahit_query.fasta"; echo "meta FullDatabase 0 1 work/metahit_query.fasta"
} | xargs -P $P -L 1 python scripts/p03_realruns.py
