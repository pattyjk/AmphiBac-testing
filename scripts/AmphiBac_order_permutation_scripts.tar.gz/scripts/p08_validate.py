"""Validate emulators against real vsearch runs on shuffled reference FASTAs (seed -> order identical in both)."""
import sys, glob, json, numpy as np, pandas as pd, scipy.sparse as sp, scipy.stats as st
sys.path.insert(0, 'scripts'); from emu import read_fa; from permsim import perm_pos, EXH_COLS
A = pd.read_csv('in/db/audit_per_sequence.csv', index_col=0)
rnF, _ = read_fa('in/db/FullDatabase_2025.1.fasta'); rnI, _ = read_fa('in/db/Inhibitory_2025.1.fasta')
inhF = A.Func.reindex(rnF).values == 'Inhibitory'
depths = json.load(open('work/depths.json')); V = []; FEAT = []; SAMP = []
for ds in ['meta', 'bf', 'serdp']:
    qn, _ = read_fa(f'work/{ds}_query.fasta'); qidx = {q: i for i, q in enumerate(qn)}
    tag = 'metahit_query' if ds == 'meta' else f'{ds}_query'
    rq, _ = read_fa(f'work/{tag}.fasta'); rmap = np.array([qidx[q] for q in rq])
    Sm = np.load(f'work/sim_{ds}.npz')
    F = pd.read_csv(f'work/{ds}_feats.csv'); R = sp.load_npz(f'work/{ds}_R.npz').tocsr(); frow = pd.Series(range(len(F)), index=F.fid).loc[qn].values
    for db, keys in [('FullDatabase', ['full_k', 'full_u']), ('Inhibitory', ['inh_k'])]:
        files = sorted(glob.glob(f'runs/{tag}_{db}/s*.npy'), key=lambda f: int(f.split('/s')[-1][:-4]))
        seeds = np.array([int(f.split('/s')[-1][:-4]) for f in files])
        real = np.full((len(seeds), len(qn)), -1, np.int64)
        for i, f in enumerate(files): real[i, rmap] = np.load(f)
        for key in keys:
            E = np.full((Sm[key].shape[0], len(qn)), -1, np.int64); E[:, Sm[key + '_q']] = Sm[key]
            Es = E[seeds]  # same seeds
            same = (Es == real); m_any = (real >= 0).any(0) | (E >= 0).any(0)
            V.append(dict(dataset=ds, db=db, emulator={'k': 'k-mer ranking (vsearch model)', 'u': 'uniform among max-identity full-coverage ties'}[key[-1]],
                          n_real_runs=len(seeds), seeds=f'{seeds.min()}-{seeds.max()}', n_features_ever_matched=int(m_any.sum()),
                          pct_feature_assignments_identical_same_seed=100 * same[:, m_any].mean(), pct_runs_fully_identical=100 * same[:, m_any].all(1).mean(),
                          pct_features_matchstatus_identical=100 * ((Es >= 0) == (real >= 0))[:, m_any].mean()))
            if db == 'Inhibitory': continue
            # per-feature frequency comparison: real (300 seeds) vs emulator over 10,000 orders (seeds 1..10000)
            P = E[1:]; tv = []; pchi = []; nref_real = []
            for j in np.nonzero(m_any)[0]:
                rv = real[seeds > 0, j]; ev = P[:, j]
                cats = np.union1d(np.unique(rv), np.unique(ev))
                rc = np.array([(rv == c).sum() for c in cats], float); ec = np.array([(ev == c).sum() for c in cats], float)
                tv.append(0.5 * np.abs(rc / rc.sum() - ec / ec.sum()).sum())
                if len(cats) > 1:
                    exp = (ec + 0.5) / (ec + 0.5).sum() * rc.sum()
                    pchi.append(st.chisquare(rc, exp).pvalue if (rc.sum() > 0) else np.nan)
                else: pchi.append(np.nan)
                FEAT.append(dict(dataset=ds, emulator=key, feature=qn[j], reads=int(F.rare_total.values[frow[j]]), n_categories=len(cats), TVD=tv[-1], chisq_p=pchi[-1]))
            tv = np.array(tv); pchi = np.array(pchi); multi = ~np.isnan(pchi)
            V[-1].update(median_TVD=np.median(tv[multi]) if multi.any() else 0, p95_TVD=np.quantile(tv[multi], .95) if multi.any() else 0,
                         n_features_multi_ref=int(multi.sum()), pct_multi_ref_features_chisq_p_lt_0_05=100 * np.mean(pchi[multi] < 0.05) if multi.any() else np.nan)
            # per-sample tophit-label inhibitory proportion distributions
            X = R[frow].toarray().astype(float); dpt = depths[ds]
            def tinh(Aa):
                m = Aa >= 0; return ((m & inhF[np.where(m, Aa, 0)]).astype(float) @ X) / dpt
            rr = tinh(real[seeds > 0]); ee = tinh(P)
            for nm, f in [('mean', lambda a: a.mean(0)), ('q025', lambda a: np.quantile(a, .025, 0)), ('q975', lambda a: np.quantile(a, .975, 0))]:
                a, b = f(rr), f(ee); V[-1][f'per_sample_{nm}_max_abs_diff'] = np.abs(a - b).max(); V[-1][f'per_sample_{nm}_median_abs_diff'] = np.median(np.abs(a - b))
                V[-1][f'per_sample_{nm}_r'] = np.corrcoef(a, b)[0, 1] if a.std() > 0 and b.std() > 0 else np.nan
            if key == 'full_k':
                SAMP.append(pd.DataFrame({'dataset': ds, 'sample': pd.read_csv(f'work/{ds}_samples.csv', header=None)[0], 'real_mean': rr.mean(0), 'real_q025': np.quantile(rr, .025, 0), 'real_q975': np.quantile(rr, .975, 0),
                                          'kmer_mean': ee.mean(0), 'kmer_q025': np.quantile(ee, .025, 0), 'kmer_q975': np.quantile(ee, .975, 0)}))
            else:
                SAMP[-1]['uniform_mean'] = ee.mean(0); SAMP[-1]['uniform_q025'] = np.quantile(ee, .025, 0); SAMP[-1]['uniform_q975'] = np.quantile(ee, .975, 0)
        if db == 'Inhibitory':
            X = R[frow].toarray().astype(float); ip = ((real >= 0).astype(float) @ X) / depths[ds]
            V[-1]['real_runs_inhibitory_mode_proportion_max_range_across_runs'] = float((ip.max(0) - ip.min(0)).max())
            V[-1]['real_runs_inhibitory_mode_richness_pct_samples_varying'] = None
            # maxrejects effect: features with a >=99% full-coverage Inhibitory hit in the exhaustive search but never matched
            Ex = pd.read_csv(f'exh/{ds}_Inhibitory.tsv', sep='\t', header=None, names=EXH_COLS)
            fc = set(Ex.loc[(Ex.qilo == 1) & (Ex.qihi == Ex.ql), 'query']); anyh = set(Ex['query'])
            matched = set(np.array(qn)[(real >= 0).any(0)])
            w = pd.Series(F.rare_total.values[frow], index=qn); tot = R.sum()
            V[-1].update(n_features_fullcov_inhib_hit=len(fc), n_fullcov_never_matched=len(fc - matched), reads_frac_fullcov_never_matched=float(w[list(fc - matched)].sum() / tot),
                         n_features_matched_without_fullcov_hit=len(matched - fc), reads_frac_matched_without_fullcov=float(w[list(matched - fc)].sum() / tot),
                         n_features_any_partial_hit_only_unmatched=len(anyh - fc - matched))
V = pd.DataFrame(V); V.to_csv('out/emulator_validation.csv', index=False)
pd.DataFrame(FEAT).to_csv('out/emulator_validation_per_feature.csv', index=False); pd.concat(SAMP).to_csv('out/emulator_validation_per_sample.csv', index=False)
pd.set_option('display.width', 250); print(V.T.to_string())
