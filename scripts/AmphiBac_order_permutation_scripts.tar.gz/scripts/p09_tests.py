"""Propagate order (tie-break) uncertainty into the downstream tests. Row 0 = original file order; rows 1..N = random orders."""
import sys, numpy as np, pandas as pd, warnings, scipy.stats as st
from statsmodels.discrete.conditional_models import ConditionalLogit
import statsmodels.api as sm
warnings.filterwarnings('ignore')
NLOGIT = int(sys.argv[1]) if len(sys.argv) > 1 else 10000
rows = []; dist = {}
def summ(ds, test, metric, est_name, est, p):
    e1, p1 = est[1:], p[1:]
    rows.append(dict(dataset=ds, test=test, metric=metric, estimate=est_name, default_order=est[0], default_order_p=p[0],
        perm_median=np.nanmedian(e1), perm_q025=np.nanquantile(e1, .025), perm_q975=np.nanquantile(e1, .975), perm_min=np.nanmin(e1), perm_max=np.nanmax(e1),
        frac_p_lt_0_05=np.nanmean(p1 < 0.05), p_median=np.nanmedian(p1), p_min=np.nanmin(p1), p_max=np.nanmax(p1),
        frac_sign_same_as_default=np.nanmean(np.sign(e1) == np.sign(est[0])) if 'OR' not in est_name else np.nanmean(np.sign(np.log(e1)) == np.sign(np.log(est[0]))), n_perm=len(e1)))
    dist[f'{ds}|{test}|{metric}|{est_name}'] = est; dist[f'{ds}|{test}|{metric}|p'] = p
# ---------------- meta-analysis contrasts (MWU, as round 1)
M = np.load('work/metrics_meta.npz'); smp = M['samples']
mp = pd.read_csv('in/meta_map.txt', sep='\t', dtype=str).set_index('#SampleID').loc[smp]
for col, a, b in [('lifestage', 'adult', 'larvae'), ('country', 'madagascar', 'usa'), ('host_scientific_name', 'anaxyrus boreas', 'lithobates catesbeianus')]:
    ia = (mp[col] == a).values; ib = (mp[col] == b).values
    for met in ['tophit_inh_prop', 'tophit_inh_over_full', 'inhmode_prop', 'full_rich', 'tophit_inh_rich']:
        X = M[met].astype(np.float64)
        xa, xb = X[:, ia], X[:, ib]
        if met == 'tophit_inh_over_full':
            U = np.full(len(X), np.nan); p = np.full(len(X), np.nan); diff = np.full(len(X), np.nan)
            for r in range(len(X)):
                u, pp = st.mannwhitneyu(xa[r][~np.isnan(xa[r])], xb[r][~np.isnan(xb[r])]); na_, nb_ = (~np.isnan(xa[r])).sum(), (~np.isnan(xb[r])).sum()
                U[r] = 2 * u / (na_ * nb_) - 1; p[r] = pp; diff[r] = np.nanmean(xa[r]) - np.nanmean(xb[r])
        else:
            u, p = st.mannwhitneyu(xa, xb, axis=1); U = 2 * u / (ia.sum() * ib.sum()) - 1; diff = xa.mean(1) - xb.mean(1)
        t = f'{col}: {a} (n={ia.sum()}) vs {b} (n={ib.sum()}), MWU'
        summ('meta', t, met, 'rank_biserial', U, p); summ('meta', t, met, 'mean_difference', diff, p)
# ---------------- SERDP: conditional logit within site x season strata; OLS load among infected with stratum FE
S = np.load('work/metrics_serdp.npz'); smp = S['samples']
D = pd.read_csv('in/serdp/serdp_meta.csv', index_col=0).loc[smp]
ok = D.groupby('stratum').Inf.transform(lambda s: 0 < s.sum() < len(s)).values
y = D.Inf.values[ok]; grp = D.stratum.values[ok]
inf = (D.Inf == 1).values; ly = D.logBd.values[inf]; gs = pd.get_dummies(D.stratum.values[inf]).values.astype(float)
H = gs @ np.linalg.pinv(gs); ry = ly - H @ ly; dfree = inf.sum() - gs.shape[1] - 1
for met in ['tophit_inh_prop', 'tophit_inh_over_full', 'inhmode_prop', 'full_rich', 'tophit_inh_rich', 'full_prop']:
    X = S[met].astype(np.float64); nr = min(len(X), NLOGIT + 1)
    OR = np.full(nr, np.nan); p = np.full(nr, np.nan)
    if met == 'inhmode_prop' or met == 'full_prop':
        same = np.allclose(X[:nr], X[0]); nr_fit = 1 if same else nr
    else: nr_fit = nr
    for r in range(nr_fit):
        x = X[r, ok]
        if met == 'tophit_inh_over_full': x = np.nan_to_num(x, nan=0.0)
        z = (x - x.mean()) / x.std(ddof=1)
        res = ConditionalLogit(y, z[:, None], groups=grp).fit(disp=0); OR[r] = np.exp(res.params[0]); p[r] = res.pvalues[0]
    if nr_fit == 1: OR[:] = OR[0]; p[:] = p[0]
    summ('serdp', f'infection ~ metric, conditional logit by site x season (n={ok.sum()}, {len(np.unique(grp))} strata)', met, 'OR_per_SD', OR, p)
    # load
    xm = X[:, inf]
    if met == 'tophit_inh_over_full': xm = np.nan_to_num(xm, nan=0.0)
    zm = (xm - xm.mean(1, keepdims=True)) / xm.std(1, ddof=1, keepdims=True); rx = zm - zm @ H.T
    beta = (rx * ry).sum(1) / (rx ** 2).sum(1); res_ = ry - beta[:, None] * rx; se = np.sqrt((res_ ** 2).sum(1) / dfree / (rx ** 2).sum(1))
    pb = 2 * st.t.sf(np.abs(beta / se), dfree)
    summ('serdp', f'log10 Bd among infected ~ metric + stratum, OLS (n={inf.sum()})', met, 'beta_per_SD', beta, pb)
# ---------------- bullfrog: pond-mean association with Type; within-treatment Spearman
B = np.load('work/metrics_bf.npz'); smp = B['samples']
bm = pd.read_csv('in/bf_map.txt', sep='\t').set_index('SampleID').loc[smp]
ponds = np.asarray(bm.Pond.values, dtype=object).astype(str); up = np.unique(ponds); Pm = (ponds[None, :] == up[:, None]).astype(float); Pm /= Pm.sum(1, keepdims=True)
pond_type = np.asarray(bm.groupby("Pond").Type.first().loc[up].values, dtype=str); ylog = Pm @ bm.LogBd.values
for met in ['tophit_inh_prop', 'tophit_inh_over_full', 'inhmode_prop', 'full_rich', 'tophit_inh_rich']:
    X = np.nan_to_num(B[met].astype(np.float64), nan=0.0); xp = X @ Pm.T  # perms x ponds
    beta = np.full(len(X), np.nan); p = np.full(len(X), np.nan)
    Xd = np.column_stack([np.ones(len(up)), (pond_type == 'High N').astype(float)])
    for r in range(len(X)):
        z = (xp[r] - xp[r].mean()) / xp[r].std(ddof=1) if xp[r].std() > 0 else xp[r] * 0
        res = sm.OLS(ylog, np.column_stack([Xd, z])).fit(); beta[r] = res.params[2]; p[r] = res.pvalues[2]
    summ('bf', f'pond-mean log Bd ~ pond-mean metric + Type, OLS ({len(up)} ponds)', met, 'beta_per_SD', beta, p)
    for tp in ['Low N', 'High N']:
        k = (bm.Type == tp).values; xr = X[:, k]; yr = bm.LogBd.values[k]
        rho = np.full(len(X), np.nan); pr = np.full(len(X), np.nan)
        rx_ = st.rankdata(xr, axis=1); ryk = st.rankdata(yr)
        for r in range(len(X)):
            if np.ptp(xr[r]) > 0: rho[r], pr[r] = st.spearmanr(xr[r], yr)
        summ('bf', f'within {tp} frogs (n={k.sum()}), Spearman log Bd', met, 'rho', rho, pr)
T = pd.DataFrame(rows); T.to_csv('out/propagated_tests.csv', index=False)
np.savez_compressed('work/test_distributions.npz', **{k.replace('|', '__').replace(' ', '_')[:200]: v for k, v in dist.items()})
pd.to_pickle(dist, 'work/test_distributions.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print(T[T.metric.isin(['tophit_inh_prop', 'inhmode_prop'])][['dataset', 'test', 'metric', 'estimate', 'default_order', 'default_order_p', 'perm_q025', 'perm_median', 'perm_q975', 'frac_p_lt_0_05', 'p_min', 'p_max']].round(4).to_string())
