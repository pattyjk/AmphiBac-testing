#!/bin/bash
# Exhaustive 99% searches (all targets aligned) for Full and Inhibitory subsets; 6 threads.
set -e
for ds in bf serdp meta; do for db in FullDatabase Inhibitory; do
  [ -f exh/${ds}_${db}.done ] && continue
  vsearch --usearch_global work/${ds}_query.fasta --db in/db/${db}_2025.1.fasta --id 0.99 --strand both --qmask none \
    --minseqlength 1 --maxaccepts 0 --maxrejects 0 --threads 6 --quiet \
    --userout exh/${ds}_${db}.tsv --userfields query+target+id+alnlen+mism+gaps+ql+qilo+qihi+tl+qstrand
  touch exh/${ds}_${db}.done; echo "$ds $db done $(date)"
done; done
