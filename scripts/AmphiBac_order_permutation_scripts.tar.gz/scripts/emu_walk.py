"""Deterministic emulation of vsearch default choice for a given reference file order (pos[t] = position of ref t in file)."""
import numpy as np, pandas as pd
def emulate(C, pos, nq, maxrej=32, heap=33, tie_join='pos'):
    d = C.assign(pos=pos[C.t.values]).sort_values(['q', 'strand', 'count', 'tlen', 'pos'], ascending=[True, True, False, True, True])
    d['rk'] = d.groupby(['q', 'strand']).cumcount()
    d = d[d.rk < heap]
    d['rej_before'] = (~d.acc).astype(int).groupby([d.q, d.strand]).cumsum() - (~d.acc).astype(int)
    a = d[d.acc & (d.rej_before < maxrej)].groupby(['q', 'strand']).head(1)
    # join strands: higher id first, then earlier target
    a = a.sort_values(['q', 'id', 'pos'], ascending=[True, False, True]).groupby('q').head(1)
    out = np.full(nq, -1, np.int64); out[a.q.values] = a.t.values
    return out
