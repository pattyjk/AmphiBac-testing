"""Per-sample permutation intervals, widths, quartile/classification changes; host metadata + AmphiBac host coverage."""
import numpy as np, pandas as pd, json
A = pd.read_csv('in/db/audit_per_sequence.csv', index_col=0)
MD = pd.read_csv('in/db/AmphibBac_Metadata_2025.1.tsv', sep='\t', dtype=str, usecols=['FastaID', 'Host.Species', 'Country', 'State']).set_index('FastaID')
MD['Func'] = A.Func.reindex(MD.index)
h = MD['Host.Species'].fillna('').str.replace('.', ' ', regex=False).str.replace('_', ' ').str.strip().str.lower()
for a, b in [('gephryomantis', 'gephyromantis'), ('ischconemia', 'ischnocnema'), ('hypsiboas', 'boana')]: h = h.str.replace(rf'^{a}\b', b, regex=True)
h = h.str.split().str[:2].str.join(' ')
MD['host'] = h; tested = MD[MD.Func.isin(['Inhibitory', 'NoEffect', 'Facilitating'])]
nt = tested.host.value_counts(); ninh = tested[tested.Func == 'Inhibitory'].host.value_counts()
def host_n(names):
    """tested isolates for a host, counting Rana/Lithobates synonyms"""
    out = []
    for n in names:
        n = str(n).lower(); alts = {n}
        if n.startswith('rana '): alts.add('lithobates ' + n[5:])
        if n.startswith('lithobates '): alts.add('rana ' + n[11:])
        out.append(int(sum(nt.get(x, 0) for x in alts)))
    return out
METS = ['tophit_inh_prop', 'tophit_inh_over_full', 'full_rich', 'tophit_inh_rich', 'full_prop', 'inhmode_prop', 'inhmode_rich']
PROP = {'tophit_inh_prop', 'tophit_inh_over_full', 'full_prop', 'inhmode_prop'}
def quart(X):  # X perms x samples -> quartile 1..4 within each perm (average ranks)
    from scipy.stats import rankdata
    r = rankdata(X, axis=1); return np.minimum(4, np.ceil(4 * r / X.shape[1])).astype(int)
summary = {}
for ds in ['meta', 'bf', 'serdp']:
    M = np.load(f'work/metrics_{ds}.npz'); smp = M['samples']; T = pd.DataFrame(index=pd.Index(smp, name='sample'))
    S = {}
    for m in METS:
        X = M[m].astype(np.float64); P = X[1:]
        if m == 'tophit_inh_over_full': P = np.where(np.isnan(P), np.nan, P)
        T[f'{m}_default_order'] = X[0]; T[f'{m}_mean'] = np.nanmean(P, 0); T[f'{m}_median'] = np.nanmedian(P, 0)
        T[f'{m}_q025'] = np.nanquantile(P, .025, 0); T[f'{m}_q975'] = np.nanquantile(P, .975, 0)
        T[f'{m}_width95'] = T[f'{m}_q975'] - T[f'{m}_q025']; T[f'{m}_min'] = np.nanmin(P, 0); T[f'{m}_max'] = np.nanmax(P, 0)
        Q = quart(np.nan_to_num(X, nan=-1)); dq = (Q[1:] != Q[0])
        T[f'{m}_frac_perms_quartile_differs_from_default'] = dq.mean(0)
        w = T[f'{m}_width95'].dropna()  # ratio undefined for samples with no Full match
        S[m] = dict(n_samples=len(w), median_width95=float(w.median()), max_width95=float(w.max()), mean_width95=float(w.mean()),
                    pct_width_gt_0_05=float(100 * (w > 0.05).mean()) if m in PROP else None, pct_width_gt_0_10=float(100 * (w > 0.10).mean()) if m in PROP else None,
                    pct_width_ge_1=float(100 * (w >= 1).mean()) if m not in PROP else None,
                    pct_quartile_change_any=float(100 * dq.any(0)[T[f'{m}_width95'].notna().values].mean()), pct_quartile_change_ge5pct_perms=float(100 * (dq.mean(0) >= 0.05)[T[f'{m}_width95'].notna().values].mean()),
                    pct_quartile_95pct_interval_spans_2plus=float(100 * (np.quantile(Q[1:], .975, 0) != np.quantile(Q[1:], .025, 0)).mean()),
                    pct_samples_any_change=float(100 * (T[f'{m}_max'] > T[f'{m}_min'])[T[f'{m}_width95'].notna()].mean()))
    r = M['tophit_inh_over_full'][1:].astype(float)
    cls = r > 0.5; c0 = M['tophit_inh_over_full'][0] > 0.5
    T['majority_inhibitory_tophit_default'] = c0; T['frac_perms_majority_inhibitory_tophit'] = np.nanmean(np.where(np.isnan(r), np.nan, cls), 0)
    fv = T.frac_perms_majority_inhibitory_tophit.dropna()
    S['majority_inhibitory_class'] = dict(n_samples=len(fv), definition='>50% of Full-matched reads have an Inhibitory top hit', pct_samples_class_flips_any=float(100 * ((fv > 0) & (fv < 1)).mean()), pct_samples_class_flips_ge5pct=float(100 * fv.between(0.05, 0.95).mean()))
    _unused = dict(pct_samples_class_flips_any=float(100 * ((T.frac_perms_majority_inhibitory_tophit > 0) & (T.frac_perms_majority_inhibitory_tophit < 1)).mean()),
                                          pct_samples_class_flips_ge5pct=float(100 * ((T.frac_perms_majority_inhibitory_tophit.between(0.05, 0.95)) ).mean()))
    if ds == 'meta':
        mp = pd.read_csv('in/meta_map.txt', sep='\t', dtype=str).set_index('#SampleID').loc[smp]
        meta = mp[['host_scientific_name', 'host_genus', 'country', 'lifestage', 'doi']].copy()
        meta['AmphiBac_tested_isolates_same_host'] = host_n(meta.host_scientific_name)
    elif ds == 'bf':
        mp = pd.read_csv('in/bf_map.txt', sep='\t').set_index('SampleID').loc[smp]
        meta = mp[['Type', 'Pond', 'LogBd']].copy(); meta.insert(0, 'host_scientific_name', 'lithobates catesbeianus'); meta.insert(1, 'location', 'Massachusetts, USA')
        meta['AmphiBac_tested_isolates_same_host'] = host_n(meta.host_scientific_name)
        meta['AmphiBac_tested_isolates_same_host_and_state'] = int(((tested.host == 'lithobates catesbeianus') & tested.State.isin(['MA', 'Massachusetts'])).sum())
    else:
        mp = pd.read_csv('in/serdp/serdp_meta.csv', index_col=0).loc[smp]
        meta = mp[['Species', 'Specis_Site', 'Season', 'stratum', 'Inf', 'logBd', 'seq_frac']].copy()
        hm = {'LIPI': 'lithobates pipiens', 'LISP': 'lithobates sphenocephalus', 'LIBL': 'lithobates blairi'}
        meta.insert(0, 'host_scientific_name', [('ngabe-bugle leopard frog (lithobates sp.)' if s.endswith('Panama') else hm[s[:4]]) for s in meta.Specis_Site])
        meta['AmphiBac_tested_isolates_same_host'] = host_n(meta.host_scientific_name)
    T = meta.join(T); T.to_csv(f'out/{ds}_per_sample_permutation_intervals.csv')
    summary[ds] = S
    print(ds, json.dumps({k: {kk: (round(vv, 3) if isinstance(vv, float) else vv) for kk, vv in v.items()} for k, v in S.items() if k in ('tophit_inh_prop', 'tophit_inh_over_full', 'full_rich', 'inhmode_prop', 'majority_inhibitory_class')}))
json.dump(summary, open('out/interval_summary.json', 'w'), indent=1)
