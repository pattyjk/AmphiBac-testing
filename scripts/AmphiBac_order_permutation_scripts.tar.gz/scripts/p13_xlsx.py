import json, pandas as pd
S = json.load(open('out/interval_summary.json'))
rows = [dict(dataset=ds, metric=m, **v) for ds, d in S.items() for m, v in d.items()]
readme = ['AmphiBac reference-order (tie-break) uncertainty, vsearch 2.32.0 emulating q2-vsearch closed-ref (--id 0.99 --strand both --qmask none, default maxaccepts 1 / maxrejects 32, dbmask dust default).',
 'Emulator: exact k-mer model of vsearch candidate ordering (unique 8-mer count desc, target length asc, file position asc; heap 33; first hit >=99% accepted; strands joined by higher exact identity). Reproduced 100% of feature assignments in 301 real Full runs and 101 real Inhibitory runs per dataset (same seeds).',
 'Uniform-among-max-identity-ties emulator is strongly biased (see emulator_validation) and was NOT used for intervals.',
 'Rows 1..10,000 = random orders (numpy default_rng(seed).permutation, seeds 1..10000); default_order = original distributed FASTA order (seed 0).',
 'Metrics: tophit_inh_prop = reads whose assigned Full-db reference has Func Inhibitory / depth; tophit_inh_over_full = that / Full proportion; full_rich = distinct Full references; tophit_inh_rich = distinct Inhibitory references among Full top hits; inhmode_prop / inhmode_rich = pipeline Inhibitory-subset mode.',
 'Intervals capture ONLY arbitrary tie-breaking by reference order; not label (assay) uncertainty, rarefaction, or sequence-identity-threshold uncertainty.',
 'Depths: meta 1,000 (2,411 samples, seed 1); bullfrog 1,883 (40 frogs, seed 1); SERDP 2,900 (372 frogs, pre-rarefied; 3,490 features without sequences count as unmatched).',
 'AmphiBac_tested_isolates_same_host = isolates with Func Inhibitory/NoEffect/Facilitating from the same host species (Rana/Lithobates synonyms pooled).']
with pd.ExcelWriter('out/AmphiBac_order_permutation_results.xlsx') as w:
    pd.DataFrame({'note': readme}).to_excel(w, sheet_name='README', index=False)
    pd.read_csv('out/emulator_validation.csv').to_excel(w, sheet_name='emulator_validation', index=False)
    pd.read_csv('out/tie_mechanics.csv').to_excel(w, sheet_name='tie_mechanics', index=False)
    pd.DataFrame(rows).to_excel(w, sheet_name='interval_summary', index=False)
    pd.read_csv('out/propagated_tests.csv').to_excel(w, sheet_name='propagated_tests', index=False)
    for ds in ['meta', 'bf', 'serdp']:
        pd.read_csv(f'out/{ds}_per_sample_permutation_intervals.csv').to_excel(w, sheet_name=f'{ds}_per_sample', index=False)
        pd.read_csv(f'out/{ds}_per_feature_call_probability.csv').to_excel(w, sheet_name=f'{ds}_per_feature', index=False)
print('ok')
