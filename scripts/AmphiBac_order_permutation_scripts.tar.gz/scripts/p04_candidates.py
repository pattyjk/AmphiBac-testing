"""Build per-query candidate frontier (k-mer ranked, dust-masked db index) per strand, joined with exhaustive acceptance.
usage: p04_candidates.py DS DB  -> work/cand_{DS}_{DB}.pkl (q, t, strand, count, tlen, acc, id)"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, 'scripts'); from emu import *
ds, db = sys.argv[1], sys.argv[2]
qn, qs = read_fa(f'work/{ds}_query.fasta')
rn, rs = read_fa(f'in/db/{db}_2025.1.fasta')
mn, masks = dust_masks_from_fasta('work/Full_dustmasked.fasta'); md = dict(zip(mn, masks))
rm = [md[n] for n in rn]
out = []
for strand, qq in [('+', qs), ('-', [revcomp(s) for s in qs])]:
    c = candidate_table(qq, rs, rm); c['strand'] = strand; out.append(c)
C = pd.concat(out, ignore_index=True)
C['tlen'] = np.array([len(s) for s in rs])[C.t.values]
E = pd.read_csv(f'exh/{ds}_{db}.tsv', sep='\t', header=None, names='query target id alnlen mism gaps ql qilo qihi tl qstrand'.split())
qi = {q: i for i, q in enumerate(qn)}; ri = {r: i for i, r in enumerate(rn)}
E = pd.DataFrame({'q': E['query'].map(qi), 't': E.target.map(ri), 'strand': E.qstrand, 'id': E.id, 'alnlen': E.alnlen})
C = C.merge(E, on=['q', 't', 'strand'], how='left'); C['acc'] = C.id.notna()
miss = E.merge(C[['q', 't', 'strand']], how='left', indicator=True); 
print(ds, db, 'cand rows', len(C), 'queries', C.q.nunique(), 'exh hits', len(E), 'exh hits outside k-mer frontier', (miss._merge == 'left_only').sum())
C.to_pickle(f'work/cand_{ds}_{db}.pkl')
