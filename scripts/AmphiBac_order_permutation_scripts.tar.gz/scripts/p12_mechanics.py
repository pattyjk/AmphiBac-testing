"""Tie mechanics: max-identity tie sets vs references actually reachable under random order (k-mer model)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, 'scripts'); from emu import read_fa; from permsim import load_cand, EXH_COLS
rn, _ = read_fa('in/db/FullDatabase_2025.1.fasta'); rows = []
for ds in ['meta', 'bf', 'serdp']:
    qn, _ = read_fa(f'work/{ds}_query.fasta'); F = pd.read_csv(f'work/{ds}_feats.csv').set_index('fid')
    C, E = load_cand(ds, 'FullDatabase', qn, rn); S = np.load(f'work/sim_{ds}.npz'); A = S['full_k'][1:]; q = S['full_k_q']
    Ef = E[E['cov'] >= 0.999]; mx = Ef.groupby('q').idp.max(); ties = Ef[np.isclose(Ef.idp, Ef.q.map(mx))].groupby('q').size()
    idl = E.set_index(['q', 't']).idp; idl = idl[~idl.index.duplicated()]
    w = F.rare_total.reindex(np.array(qn)[q]).values.astype(float)
    nposs = np.array([len(np.unique(c[c >= 0])) for c in A.T])
    # chosen identity < max identity (any coverage hit chosen at lower identity, or partial-coverage hit chosen)
    sub = np.zeros(len(q)); partial = np.zeros(len(q))
    covl = E.set_index(['q', 't'])['cov']; covl = covl[~covl.index.duplicated()]
    for j, qq in enumerate(q):
        c = A[:, j]; u, cnt = np.unique(c[c >= 0], return_counts=True)
        best = mx.get(qq, np.nan)
        ids = np.array([idl.get((qq, t), np.nan) for t in u]); cv = np.array([covl.get((qq, t), np.nan) for t in u])
        sub[j] = (cnt[ids < best - 1e-12].sum() / len(c)) if not np.isnan(best) else 0
        partial[j] = cnt[cv < 0.999].sum() / len(c)
    nt = ties.reindex(q).fillna(0).values
    rows.append(dict(dataset=ds, matched_features=len(q), matched_reads_frac=w.sum() / F.rare_total.sum(),
        pct_features_maxid_tie_gt1=100 * np.mean(nt > 1), pct_reads_maxid_tie_gt1=100 * w[nt > 1].sum() / w.sum(),
        median_maxid_tie_size_among_tied=float(np.median(nt[nt > 1])) if (nt > 1).any() else 0, max_maxid_tie_size=int(nt.max()),
        pct_features_order_dependent=100 * np.mean(nposs > 1), pct_reads_order_dependent=100 * w[nposs > 1].sum() / w.sum(),
        median_reachable_refs_among_order_dependent=float(np.median(nposs[nposs > 1])), max_reachable_refs=int(nposs.max()),
        pct_features_reachable_lt_maxid_ties=100 * np.mean(nposs < nt), 
        pct_features_sometimes_suboptimal_identity=100 * np.mean(sub > 0), pct_reads_sometimes_suboptimal=100 * w[sub > 0].sum() / w.sum(),
        pct_features_always_suboptimal_identity=100 * np.mean(sub >= 1), pct_features_partial_coverage_hit_chosen=100 * np.mean(partial > 0)))
M = pd.DataFrame(rows); M.to_csv('out/tie_mechanics.csv', index=False); print(M.T.to_string())
