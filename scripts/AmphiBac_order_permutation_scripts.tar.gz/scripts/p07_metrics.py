"""Per-sample metrics across simulated orders. usage: p07_metrics.py DS
Row 0 = original file order; rows 1..10000 = random orders (seeds 1..10000)."""
import sys, json, numpy as np, pandas as pd, scipy.sparse as sp
sys.path.insert(0, 'scripts'); from emu import read_fa
ds = sys.argv[1]; depth = json.load(open('work/depths.json'))[ds]
F = pd.read_csv(f'work/{ds}_feats.csv'); samples = pd.read_csv(f'work/{ds}_samples.csv', header=None)[0].tolist()
R = sp.load_npz(f'work/{ds}_R.npz').tocsr()
qn, _ = read_fa(f'work/{ds}_query.fasta'); frow = pd.Series(range(len(F)), index=F.fid).loc[qn].values  # query idx -> R row
A = pd.read_csv('in/db/audit_per_sequence.csv', index_col=0)
S = np.load(f'work/sim_{ds}.npz'); out = {}
def lab(db):
    rn, _ = read_fa(f'in/db/{db}_2025.1.fasta'); return np.array(rn), (A.Func.reindex(rn).values == 'Inhibitory')
def prop_rich(key, inhlab):
    Aq = S[key].astype(np.int64); q = S[key + '_q']; X = R[frow[q]].toarray().astype(np.float64)  # nq x S
    m = Aq >= 0; inh = m & inhlab[np.where(m, Aq, 0)]
    prop = (m.astype(np.float64) @ X) / depth; iprop = (inh.astype(np.float64) @ X) / depth
    qi, si = np.nonzero(X > 0); nref = len(inhlab) + 1
    rich = np.zeros((len(Aq), X.shape[1]), np.int32); irich = np.zeros_like(rich)
    for p in range(len(Aq)):
        c = Aq[p, qi]; ok = c >= 0
        u = np.unique(si[ok] * nref + c[ok]); rich[p] = np.bincount(u // nref, minlength=X.shape[1])
        ok2 = ok & inhlab[np.where(ok, c, 0)]
        u = np.unique(si[ok2] * nref + c[ok2]); irich[p] = np.bincount(u // nref, minlength=X.shape[1])
    return prop.astype(np.float32), iprop.astype(np.float32), rich, irich, Aq, q, inh
rnF, inhF = lab('FullDatabase'); rnI, inhI = lab('Inhibitory')
out['full_prop'], out['tophit_inh_prop'], out['full_rich'], out['tophit_inh_rich'], AF, qF, inhq = prop_rich('full_k', inhF)
with np.errstate(invalid='ignore', divide='ignore'): out['tophit_inh_over_full'] = (out['tophit_inh_prop'] / out['full_prop']).astype(np.float32)
out['full_prop_u'], out['tophit_inh_prop_u'], out['full_rich_u'], _, AU, qU, inhqU = prop_rich('full_u', inhF)
out['inhmode_prop'], _, out['inhmode_rich'], _, AI, qI, _ = prop_rich('inh_k', np.ones(len(rnI), bool))
np.savez_compressed(f'work/metrics_{ds}.npz', samples=np.array(samples), **out)
# per-feature table
fid = np.array(qn)
def feat(Aq, q, inhq, pre):
    P = Aq[1:]; d = {}
    d[f'{pre}P_matched'] = (P >= 0).mean(0); d[f'{pre}P_inhibitory_call'] = inhq[1:].mean(0)
    d[f'{pre}n_distinct_refs'] = [len(np.unique(c[c >= 0])) for c in P.T]
    mode = [np.bincount(c[c >= 0]).argmax() if (c >= 0).any() else -1 for c in P.T]
    d[f'{pre}modal_ref_freq'] = [np.mean(c == m_) for c, m_ in zip(P.T, mode)]
    d[f'{pre}default_order_ref'] = np.where(Aq[0] >= 0, rnF[np.maximum(Aq[0], 0)] if pre != 'inhmode_' else rnI[np.maximum(Aq[0], 0)], '')
    return pd.DataFrame(d, index=fid[q])
T = feat(AF, qF, inhq, 'full_').join(feat(AU, qU, inhqU, 'uniform_'), how='outer').join(feat(AI, qI, np.zeros_like(AI, bool), 'inhmode_')[['inhmode_P_matched', 'inhmode_n_distinct_refs', 'inhmode_default_order_ref']], how='outer')
T['default_order_call_inhibitory'] = [ (A.Func.get(r) == 'Inhibitory') if isinstance(r, str) and r else False for r in T.full_default_order_ref]
T.insert(0, 'rarefied_reads', F.set_index('fid').rare_total.reindex(T.index).values)
T.insert(1, 'sequence', F.set_index('fid').seq.reindex(T.index).values)
T.index.name = 'feature_id'; T.sort_values('rarefied_reads', ascending=False).to_csv(f'out/{ds}_per_feature_call_probability.csv')
pi = T.full_P_inhibitory_call; w = T.rarefied_reads
print(ds, 'features ever matched', len(T), '| Full-k features with 0<P(inh)<1:', int(((pi > 0) & (pi < 1)).sum()), f'reads {w[(pi>0)&(pi<1)].sum()/w[T.full_P_matched>0].sum():.3f} of matched',
      '| P(matched) not 0/1:', int(((T.full_P_matched > 0) & (T.full_P_matched < 1)).sum()), '| inhmode P(matched) not 0/1:', int(((T.inhmode_P_matched > 0) & (T.inhmode_P_matched < 1)).sum()),
      '| >1 ref:', int((T.full_n_distinct_refs > 1).sum()))
