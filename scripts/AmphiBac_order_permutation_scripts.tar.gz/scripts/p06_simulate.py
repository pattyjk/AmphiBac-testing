"""Simulate 10,000 reference orders (seeds 1..10000; same seed->order mapping as the real shuffled runs) with the
k-mer emulator (Full and Inhibitory) and the uniform-tie emulator (Full). usage: p06_simulate.py DS [NPERM]
-> work/sim_{DS}.npz : full_k, full_u, inh_k (perm x query, int16 ref index, -1 none) + query lists."""
import sys, time, numpy as np
sys.path.insert(0, 'scripts'); from emu import read_fa; from permsim import *
ds = sys.argv[1]; NP = int(sys.argv[2]) if len(sys.argv) > 2 else 10000
qn, _ = read_fa(f'work/{ds}_query.fasta')
res = {}
for db in ['FullDatabase', 'Inhibitory']:
    rn, _ = read_fa(f'in/db/{db}_2025.1.fasta'); nr = len(rn)
    C, E = load_cand(ds, db, qn, rn)
    K = KmerSim(C, nr); sims = [('k', K)]
    if db == 'FullDatabase': sims.append(('u', UniformSim(E, nr)))
    for tag, S in sims:
        t0 = time.time(); A = np.empty((NP + 1, len(S.queries)), np.int16)
        for p in range(NP + 1):           # row 0 = original file order (seed 0)
            A[p] = S.run(perm_pos(p, nr))
        key = ('full_' if db == 'FullDatabase' else 'inh_') + tag
        res[key] = A; res[key + '_q'] = S.queries
        print(ds, db, tag, 'queries', len(S.queries), 'secs', round(time.time() - t0, 1), flush=True)
np.savez_compressed(f'work/sim_{ds}.npz', **res)
