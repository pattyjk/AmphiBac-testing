"""Real vsearch runs on shuffled reference FASTAs, exactly the q2-vsearch closed-ref call.
usage: p03_realruns.py DS DB SEED_START SEED_END [QUERY_FASTA]
Seeds: reference order = numpy default_rng(seed).permutation(n_ref). seed 0 = original file order (no shuffle).
Writes runs/{DS}_{DB}/s{seed}.npy : int32 array over query order (work/{DS}_query.fasta or QUERY_FASTA), ref index in ORIGINAL file (0-based), -1 unmatched."""
import sys, os, subprocess, numpy as np, tempfile
ds, db, s0, s1 = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
qfa = sys.argv[5] if len(sys.argv) > 5 else f'work/{ds}_query.fasta'
tag = os.path.basename(qfa).replace('.fasta', '')
out = f'runs/{tag}_{db}'; os.makedirs(out, exist_ok=True)
recs = []; k = None
for l in open(f'in/db/{db}_2025.1.fasta'):
    l = l.rstrip('\n')
    if l.startswith('>'): recs.append([l[1:].split()[0], []])
    else: recs[-1][1].append(l)
names = [r[0] for r in recs]; seqs = [''.join(r[1]) for r in recs]; ri = {n: i for i, n in enumerate(names)}
qids = [l[1:].strip().split()[0] for l in open(qfa) if l.startswith('>')]; qi = {q: i for i, q in enumerate(qids)}
tmp = tempfile.mkdtemp(dir='runs')
for seed in range(s0, s1):
    fn = f'{out}/s{seed}.npy'
    if os.path.exists(fn): continue
    order = np.arange(len(names)) if seed == 0 else np.random.default_rng(seed).permutation(len(names))
    dbf = f'{tmp}/db.fasta'; uc = f'{tmp}/out.uc'
    with open(dbf, 'w') as f:
        for i in order: f.write(f'>{names[i]}\n{seqs[i]}\n')
    subprocess.run(['vsearch', '--usearch_global', qfa, '--id', '0.99', '--db', dbf, '--uc', uc, '--strand', 'both', '--qmask', 'none',
                    '--notmatched', f'{tmp}/nm.fasta', '--threads', '1', '--minseqlength', '1', '--fasta_width', '0', '--quiet'], check=True)
    a = np.full(len(qids), -1, np.int32)
    for l in open(uc):
        if l[0] == 'H':
            p = l.rstrip('\n').split('\t'); a[qi[p[8].split()[0]]] = ri[p[9].split()[0]]
    np.save(fn, a)
