"""Order-permutation track, step 0: parse/rarefy tables (same semantics as round-1 rd01/rd03), write query FASTAs.
Outputs perm/work/{ds}_R.npz (features x samples rarefied counts), {ds}_feats.csv, {ds}_samples.csv, {ds}_query.fasta, depth."""
import numpy as np, pandas as pd, scipy.sparse as sp, re, os, json
os.makedirs('work', exist_ok=True)
def rarefy(M, depth, seed):
    rng = np.random.default_rng(seed); M = M.tocsc(); rows, cols, vals = [], [], []
    for j in range(M.shape[1]):
        s, e = M.indptr[j], M.indptr[j+1]; idx, c = M.indices[s:e], M.data[s:e].astype(np.int64)
        if c.sum() < depth: continue
        d = rng.multivariate_hypergeometric(c, depth); k = d > 0
        rows.append(idx[k]); cols.append(np.full(k.sum(), j)); vals.append(d[k])
    return sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=M.shape)
def write(ds, R, seqs, samples, depth, ids):
    R = R.tocsr(); tot = np.asarray(R.sum(1)).ravel(); keep = tot > 0
    R = R[keep]; seqs = [s for s, k in zip(seqs, keep) if k]; ids = [s for s, k in zip(ids, keep) if k]; tot = tot[keep]
    hasseq = np.array([s is not None for s in seqs])
    sp.save_npz(f'work/{ds}_R.npz', R.tocsr())
    pd.DataFrame({'fid': ids, 'seq': seqs, 'rare_total': tot, 'has_seq': hasseq}).to_csv(f'work/{ds}_feats.csv', index=False)
    pd.Series(samples).to_csv(f'work/{ds}_samples.csv', index=False, header=False)
    with open(f'work/{ds}_query.fasta', 'w') as f:
        for i in np.argsort(-tot, kind='stable'):
            if hasseq[i]: f.write(f'>{ids[i]}\n{seqs[i]}\n')
    print(ds, 'samples', R.shape[1], 'depth', depth, 'features', R.shape[0], 'with seq', hasseq.sum(), 'reads w/o seq frac', round(tot[~hasseq].sum()/tot.sum(), 4))
    return depth
info = {}
# meta
with open('in/amphib_only_otu_table.txt') as f:
    samples = f.readline().rstrip('\n').split('\t'); ns = len(samples); ids, r, c, v = [], [], [], []; nb = nn = 0
    for line in f:
        p = line.rstrip('\n').split('\t')
        if len(p) != ns + 1: nb += 1; continue
        if re.fullmatch(r'\d+', p[0]): nn += 1; continue
        x = np.array(p[1:], dtype=float); nz = np.nonzero(x)[0]
        if len(nz) == 0: continue
        i = len(ids); ids.append(p[0]); r.extend([i]*len(nz)); c.extend(nz); v.extend(x[nz])
M = sp.csc_matrix((np.array(v).round().astype(np.int64), (r, c)), shape=(len(ids), ns))
dep = np.asarray(M.sum(0)).ravel(); keep = dep >= 1000
print('meta malformed', nb, 'numeric', nn, 'samples>=1000', keep.sum())
M = M[:, keep]; samples = [s for s, k in zip(samples, keep) if k]
R = rarefy(M, 1000, 1)
info['meta'] = write('meta', R, ids, samples, 1000, [f'm{i}' for i in range(len(ids))])
# bullfrog
skip = 1 if open('in/bf_asv_table.txt').readline().startswith('# Constructed') else 0
bf = pd.read_csv('in/bf_asv_table.txt', sep='\t', skiprows=skip, index_col=0)
bf = bf.loc[:, bf.sum(0) >= 10]; depth = int(bf.sum(0).min())
seqs = {}; k = None
for line in open('in/bf_seqs.fasta'):
    line = line.strip()
    if line.startswith('>'): k = line[1:].split()[0]; seqs[k] = ''
    else: seqs[k] += line
R = rarefy(sp.csc_matrix(bf.values.round().astype(np.int64)), depth, 1)
info['bf'] = write('bf', R, [seqs.get(x) for x in bf.index], bf.columns.tolist(), depth, bf.index.tolist())
# serdp
X = pd.read_csv('in/serdp/serdp_table_rare2900.csv', index_col=0)
seqs = {}; k = None
for line in open('in/serdp/serdp_repseqs.fasta'):
    line = line.strip()
    if line.startswith('>'): k = line[1:].split()[0]; seqs[k] = ''
    else: seqs[k] += line
assert (X.sum(0) == 2900).all()
info['serdp'] = write('serdp', sp.csc_matrix(X.values.astype(np.int64)), [seqs.get(x) for x in X.index], X.columns.tolist(), 2900, X.index.tolist())
json.dump(info, open('work/depths.json', 'w'))
