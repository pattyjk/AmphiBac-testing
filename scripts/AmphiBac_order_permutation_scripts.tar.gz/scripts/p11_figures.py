"""Figures (run inside a kernel where apply_figure_style() from the figure-style skill is available, cwd = perm/)."""
import glob, sys, json, numpy as np, pandas as pd, matplotlib.pyplot as plt, scipy.sparse as sp
sys.path.insert(0, 'scripts'); from emu import read_fa
INH, NOE, FAC = '#2166AC', '#E08214', '#7B3294'; GREY = '#888888'
DSN = {'meta': 'Meta-analysis (90 bp, n=2,411 samples)', 'bf': 'Bullfrog, MA (120 bp, n=40 frogs)', 'serdp': 'SERDP leopard frogs (150 bp, n=372 frogs)'}
# ---------- Figure 1: emulator validation
fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.9))
for k, ds in enumerate(['meta', 'bf', 'serdp']):
    qn, _ = read_fa(f'work/{ds}_query.fasta'); qidx = {q: i for i, q in enumerate(qn)}
    tag = 'metahit_query' if ds == 'meta' else f'{ds}_query'; rq, _ = read_fa(f'work/{tag}.fasta'); rmap = np.array([qidx[q] for q in rq])
    files = [f for f in glob.glob(f'runs/{tag}_FullDatabase/s*.npy') if not f.endswith('/s0.npy')]
    real = np.full((len(files), len(qn)), -1, np.int64)
    for i, f in enumerate(files): real[i, rmap] = np.load(f)
    S = np.load(f'work/sim_{ds}.npz'); ax = axs[0, k]
    for key, col, lab in [('full_u', NOE, 'uniform among max-identity ties'), ('full_k', INH, 'k-mer ranking model')]:
        E = np.full((S[key].shape[0] - 1, len(qn)), -1, np.int64); E[:, S[key + '_q']] = S[key][1:]
        xs, ys = [], []
        for j in np.nonzero((E >= 0).any(0) | (real >= 0).any(0))[0]:
            cats = np.union1d(np.unique(E[:, j]), np.unique(real[:, j]))
            if len(cats) < 2: continue
            for c in cats: xs.append((E[:, j] == c).mean()); ys.append((real[:, j] == c).mean())
        ax.scatter(xs, ys, s=5, color=col, alpha=0.45, lw=0, label=lab, rasterized=True)
    ax.plot([0, 1], [0, 1], color='k', lw=0.6, ls='--'); ax.set_xlim(-0.03, 1.03); ax.set_ylim(-0.03, 1.03)
    ax.set_title(DSN[ds].split(' (')[0], loc='left'); ax.set_xlabel('Emulator P(reference chosen)')
    if k == 0: ax.set_ylabel(f'Real runs: frequency\n(n={len(files)} shuffled FASTAs)'); ax.legend(loc='center left', bbox_to_anchor=(0.0, 0.78), frameon=False, handletextpad=0.2, markerscale=2.5)
    V = pd.read_csv('out/emulator_validation_per_sample.csv'); V = V[V.dataset == ds]; ax = axs[1, k]
    for pre, col, mk in [('uniform', NOE, 'o'), ('kmer', INH, 'o')]:
        for st_, a in [('q025', 0.6), ('mean', 1.0), ('q975', 0.6)]:
            ax.scatter(V[f'{pre}_{st_}'], V[f'real_{st_}'], s=6 if ds != 'bf' else 12, color=col, alpha=0.5 * a, lw=0, rasterized=True)
    lim = max(V.filter(like='q975').max().max(), 0.05) * 1.05
    ax.plot([0, lim], [0, lim], color='k', lw=0.6, ls='--'); ax.set_xlim(-0.02 * lim, lim); ax.set_ylim(-0.02 * lim, lim)
    ax.set_xlabel('Emulator per-sample value'); 
    if k == 0: ax.set_ylabel('Real runs per-sample value\n(mean, 2.5th, 97.5th pct)')
axs[1, 0].text(0.03, 0.97, 'top-hit inhibitory proportion', transform=axs[1, 0].transAxes, va='top', fontsize=6)
for a, l in zip(axs[:, 0], 'ab'): panel_letter(a, l)
fig.tight_layout(); fig.savefig('out/fig_emulator_validation.png', dpi=300); plt.close(fig)
# ---------- Figure 2: per-sample intervals sorted by median
fig, axs = plt.subplots(3, 1, figsize=(7.2, 6.6))
for ax, ds in zip(axs, ['meta', 'bf', 'serdp']):
    T = pd.read_csv(f'out/{ds}_per_sample_permutation_intervals.csv', index_col=0).sort_values(['tophit_inh_prop_median', 'tophit_inh_prop_q975'])
    x = np.arange(len(T))
    ax.vlines(x, T.tophit_inh_prop_q025, T.tophit_inh_prop_q975, color=INH, alpha=0.35, lw=0.6 if ds == 'meta' else 2.0, label='95% interval over 10,000 orders')
    ax.scatter(x, T.tophit_inh_prop_median, s=1.5 if ds == 'meta' else 8, color=INH, lw=0, label='median', zorder=3)
    ax.scatter(x, T.tophit_inh_prop_default_order, s=1.5 if ds == 'meta' else 8, color='k', marker='x' if ds != 'meta' else 'o', lw=0.6 if ds != 'meta' else 0, label='distributed file order', zorder=4)
    ax.scatter(x, T.inhmode_prop_default_order, s=1.5 if ds == 'meta' else 8, color=GREY, lw=0, label='Inhibitory-subset mode (order-invariant)', zorder=2)
    js = json.load(open('out/interval_summary.json'))[ds]['tophit_inh_prop']
    ax.set_title(f"{DSN[ds]}: median 95% width {js['median_width95']:.2f}; width >0.10 in {js['pct_width_gt_0_10']:.0f}% of samples", loc='left')
    ax.set_ylabel('Top-hit inhibitory\nproportion'); ax.set_xlim(-1, len(T)); ax.set_ylim(-0.02, 1.02)
    ax.set_xticks([])
h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, loc='lower center', ncol=4, frameon=False, markerscale=4, bbox_to_anchor=(0.5, 0.0))
axs[-1].set_xlabel('Samples, sorted by median across orders')
for a, l in zip(axs, 'abc'): panel_letter(a, l)
fig.tight_layout(rect=(0, 0.04, 1, 1)); fig.savefig('out/fig_per_sample_intervals.png', dpi=300); plt.close(fig)
# ---------- Figure 3: propagated test distributions
D = pd.read_pickle('work/test_distributions.pkl'); P = pd.read_csv('out/propagated_tests.csv')
panels = [('meta', 'lifestage', 'rank_biserial', 'Adult vs larvae\n(rank-biserial)'), ('meta', 'country', 'rank_biserial', 'Madagascar vs USA\n(rank-biserial)'),
          ('meta', 'host_scientific_name', 'rank_biserial', 'A. boreas vs L. catesbeianus\n(rank-biserial)'),
          ('serdp', 'infection', 'OR_per_SD', 'SERDP infection, cond. logit\n(OR per SD)'), ('serdp', 'log10 Bd', 'beta_per_SD', 'SERDP log Bd among infected\n(beta per SD)'),
          ('bf', 'pond-mean', 'beta_per_SD', 'Bullfrog pond-mean log Bd\n(beta per SD, 10 ponds)')]
fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.6))
for ax, (ds, tkey, est, lab) in zip(axs.ravel(), panels):
    row = P[(P.dataset == ds) & P.test.str.startswith(tkey) & (P.metric == 'tophit_inh_prop') & (P.estimate == est)].iloc[0]
    rinv = P[(P.dataset == ds) & P.test.str.startswith(tkey) & (P.metric == 'inhmode_prop') & (P.estimate == est)].iloc[0]
    v = D[f'{ds}|{row.test}|tophit_inh_prop|{est}'][1:]; pv = D[f'{ds}|{row.test}|tophit_inh_prop|p'][1:]
    bins = np.linspace(min(v.min(), rinv.default_order, row.default_order), max(v.max(), rinv.default_order, row.default_order), 50)
    ax.hist(v[pv >= 0.05], bins=bins, color=INH, alpha=0.4, label='p >= 0.05'); ax.hist(v[pv < 0.05], bins=bins, color=INH, alpha=0.9, label='p < 0.05')
    ax.axvline(row.default_order, color='k', lw=1, label='distributed file order'); ax.axvline(rinv.default_order, color=GREY, lw=1, ls='--', label='Inhibitory-subset mode')
    nullv = 1.0 if 'OR' in est else 0.0
    ax.axvline(nullv, color='k', lw=0.5, ls=':')
    ax.set_xlabel(lab); fr = row.frac_p_lt_0_05; ftxt = '>99.9%' if 0.999 <= fr < 1 else ('<0.1%' if 0 < fr < 0.001 else f'{100*fr:.0f}%'); ax.set_title(f'{ftxt} of 10,000 orders p<0.05', loc='left')
axs[0, 0].set_ylabel('Orders'); axs[1, 0].set_ylabel('Orders'); h, l = axs[0, 0].get_legend_handles_labels(); fig.legend(h, l, loc='lower center', ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.0))
for a, l in zip(axs.ravel(), 'abcdef'): panel_letter(a, l)
fig.tight_layout(rect=(0, 0.05, 1, 1)); fig.savefig('out/fig_propagated_tests.png', dpi=300); plt.close(fig)
print('figures done')
