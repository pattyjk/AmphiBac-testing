"""Fast simulation of vsearch default choice under random reference file orders.
Two emulators share the same global permutation per replicate:
  kmer    : exact model of vsearch 2.32 candidate ordering (k-mer count desc, target length asc, file position asc;
            heap 33; first target with id>=0.99 accepted; stop after 32 rejects; strands joined by higher exact identity, then earlier file position)
  uniform : uniform choice among references tied at the maximum exact identity (matches/alignment columns, iddef 2)."""
import numpy as np, pandas as pd
EXH_COLS = 'query target id alnlen mism gaps ql qilo qihi tl qstrand'.split()
def load_cand(ds, db, qnames, rnames):
    C = pd.read_pickle(f'work/cand_{ds}_{db}.pkl')
    E = pd.read_csv(f'exh/{ds}_{db}.tsv', sep='\t', header=None, names=EXH_COLS)
    qi = {q: i for i, q in enumerate(qnames)}; ri = {r: i for i, r in enumerate(rnames)}
    E = pd.DataFrame({'q': E['query'].map(qi), 't': E.target.map(ri), 'strand': E.qstrand,
                      'idp': (E.alnlen - E.mism - E.gaps) / E.alnlen, 'cov': (E.qihi - E.qilo + 1) / E.ql})
    C = C.drop(columns=['id', 'alnlen']).merge(E, on=['q', 't', 'strand'], how='left')
    return C, E
class KmerSim:
    def __init__(self, C, nref, heap=33, maxrej=32):
        d = C.sort_values(['q', 'strand', 'count', 'tlen', 't'], ascending=[True, True, False, True, True]).reset_index(drop=True)
        d['g'] = d.groupby(['q', 'strand'], sort=False).ngroup()
        d['blk'] = d.groupby(['g', 'count', 'tlen'], sort=False).ngroup()
        B = d.groupby('blk', sort=False).agg(g=('g', 'first'), n=('acc', 'size'), nacc=('acc', 'sum'))
        B['nrej'] = B.n - B.nacc
        B['bs'] = B.groupby('g').n.cumsum() - B.n
        B['rb'] = B.groupby('g').nrej.cumsum() - B.nrej
        stop = (B.nacc > 0) & (B.rb + B.nrej < maxrej)
        B['stopped_before'] = stop.astype(int).groupby(B.g).cumsum() - stop.astype(int)
        keep = (B.bs < heap) & (B.stopped_before == 0) & (B.rb < maxrej)
        d = d[d.blk.isin(B.index[keep])]
        gacc = d.groupby('g').acc.any(); d = d[d.g.isin(gacc.index[gacc])].reset_index(drop=True)
        d['g'] = d.groupby('g', sort=False).ngroup(); d['blk'] = d.groupby('blk', sort=False).ngroup()
        self.d = d; self.heap, self.maxrej = heap, maxrej
        self.blk = d.blk.values.astype(np.int64); self.t = d.t.values; self.acc = d.acc.values; self.g = d.g.values
        self.gstart = np.r_[0, np.nonzero(np.diff(self.g))[0] + 1]
        G = d.groupby('g').agg(q=('q', 'first'))
        self.gq = G.q.values; self.nref = nref
        self.idp = np.where(d.acc.values, d.idp.fillna(0).values, -1.0)
        self.queries = np.unique(self.gq)
        self.qpos = np.searchsorted(self.queries, self.gq)
    def run(self, pos):
        """pos: array (nref,) file position of each reference. Returns assigned ref per self.queries (-1 none)."""
        key = self.blk * self.nref + pos[self.t]
        o = np.argsort(key, kind='stable')
        acc = self.acc[o]; g = self.g[o]
        n = len(o); idx = np.arange(n)
        rk = idx - self.gstart[g]
        rej = (~acc).astype(np.int64); rc = np.cumsum(rej); rbefore = rc - rej - (rc - rej)[self.gstart][g]
        valid = acc & (rbefore < self.maxrej) & (rk < self.heap)
        first = np.minimum.reduceat(np.where(valid, idx, n), self.gstart)
        ok = first < n
        gi = np.nonzero(ok)[0]; rows = o[first[ok]]
        # join strands per query: max idp then min pos
        tq = self.qpos[gi]; tt = self.t[rows]; ti = self.idp[rows]; tp = pos[tt]
        s = np.lexsort((tp, -ti, tq)); tq, tt = tq[s], tt[s]
        firstq = np.r_[True, tq[1:] != tq[:-1]]
        out = np.full(len(self.queries), -1, np.int64); out[tq[firstq]] = tt[firstq]
        return out
    def run_full(self, pos, nq):
        o = np.full(nq, -1, np.int64); o[self.queries] = self.run(pos); return o
class UniformSim:
    def __init__(self, E, nref, queries=None, full_cov=True):
        E = E[E['cov'] >= 0.999].copy() if full_cov else E.copy(); mx = E.groupby('q').idp.transform('max'); T = E[np.isclose(E.idp, mx, atol=1e-12)].sort_values('q')
        T = T.drop_duplicates(['q', 't'])
        self.queries = np.unique(E.q.values) if queries is None else np.asarray(queries); self.t = T.t.values
        qs = T.q.values; self.start = np.r_[0, np.nonzero(np.diff(qs))[0] + 1]; self.uq = qs[self.start]
        self.map = np.searchsorted(self.queries, self.uq); assert (self.queries[self.map] == self.uq).all()
        self.nref = nref
    def run(self, pos):
        p = pos[self.t]; m = np.minimum.reduceat(p, self.start)
        # recover argmin target: position -> ref via inverse permutation
        inv = np.empty(self.nref, np.int64); inv[pos] = np.arange(self.nref)
        out = np.full(len(self.queries), -1, np.int64); out[self.map] = inv[m]
        return out
    def run_full(self, pos, nq):
        o = np.full(nq, -1, np.int64); o[self.queries] = self.run(pos); return o
def perm_pos(seed, nref):
    """file position of each ref for the shuffled FASTA written by p03_realruns.py with this seed."""
    if seed == 0: return np.arange(nref)
    order = np.random.default_rng(seed).permutation(nref); pos = np.empty(nref, np.int64); pos[order] = np.arange(nref); return pos
