"""Emulator of vsearch --usearch_global default target choice (maxaccepts 1, maxrejects 32, wordlength 8).
Model (from vsearch source: minheap elem_smaller + search loop):
  candidates = targets sharing >= min(12, n_unique_query_kmers) unique 8-mers with the query;
  heap keeps the top 33 ordered by (shared k-mer count desc, target length asc, target file position asc);
  they are aligned in that order; first target with identity >= 0.99 is accepted; stop after 32 rejects (-> unmatched).
Under a random reference order only the file-position tie-break changes.
Acceptance (identity >= 0.99) comes from the exhaustive --maxaccepts 0 --maxrejects 0 table.
Optional dust masking of the database (vsearch default --dbmask dust) is applied to the reference k-mer index."""
import numpy as np, scipy.sparse as sp, pandas as pd
K = 8; ENC = np.full(256, -1, np.int64)
for c, v in zip(b'ACGTacgt', [0, 1, 2, 3, 0, 1, 2, 3]): ENC[c] = v
def kmers(seq, mask=None):
    """unique 8-mer codes of seq (skip k-mers with non-ACGT or, if mask given, masked positions)."""
    a = ENC[np.frombuffer(seq.encode(), np.uint8)]
    if len(a) < K: return np.empty(0, np.int64)
    bad = (a < 0) if mask is None else ((a < 0) | mask)
    a = np.where(a < 0, 0, a)
    w = np.lib.stride_tricks.sliding_window_view(a, K)
    code = (w * (4 ** np.arange(K - 1, -1, -1))).sum(1)
    okw = ~np.lib.stride_tricks.sliding_window_view(bad, K).any(1)
    return np.unique(code[okw])
def read_fa(p):
    n, s = [], []
    for l in open(p):
        l = l.rstrip('\n')
        if l.startswith('>'): n.append(l[1:].split()[0]); s.append([])
        else: s[-1].append(l)
    return n, [''.join(x) for x in s]
def kmer_matrix(seqs, masks=None):
    rows, cols = [], []
    for i, s in enumerate(seqs):
        k = kmers(s, None if masks is None else masks[i]); rows.append(np.full(len(k), i)); cols.append(k)
    r = np.concatenate(rows); c = np.concatenate(cols)
    return sp.csr_matrix((np.ones(len(r), np.int32), (r, c)), shape=(len(seqs), 4 ** K))
def revcomp(s):
    return s.translate(str.maketrans('ACGTacgtNRYKMSWBDHV', 'TGCAtgcaNYRMKSWVHDB'))[::-1]

def candidate_table(qseqs, rseqs, rmasks=None, chunk=2000, strand_both=False):
    """For each query: all targets in the top-33 frontier (count >= count of 33rd-ranked), with shared count.
    Returns DataFrame q, t, count (q,t indices)."""
    R = kmer_matrix(rseqs, rmasks).T.tocsc().astype(np.int32)
    out = []
    for s0 in range(0, len(qseqs), chunk):
        Q = kmer_matrix(qseqs[s0:s0 + chunk]); nk = np.asarray(Q.sum(1)).ravel()
        C = (Q @ R).toarray()
        minm = np.minimum(12, nk)[:, None]
        C[C < minm] = 0
        # threshold: count of 33rd largest
        part = -np.partition(-C, 32, axis=1)[:, 32] if C.shape[1] > 33 else np.zeros(len(C))
        thr = np.maximum(part, 1)[:, None]
        qi, ti = np.nonzero(C >= thr)
        out.append(pd.DataFrame({'q': qi + s0, 't': ti, 'count': C[qi, ti]}))
    return pd.concat(out, ignore_index=True)

def dust_masks_from_fasta(path):
    """bool masks from lowercase positions of vsearch --maskfasta output (default dust)."""
    n, s = read_fa(path); return n, [np.frombuffer(x.encode(), np.uint8) >= 97 for x in s]
