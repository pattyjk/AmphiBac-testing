#!/bin/bash
# Uniform V4 R1 ASV processing (primer-free reads starting after 515F).
# usage: 01_asv_v4.sh STUDY MODE(pooled|persample) [stream_cmd]
set -euo pipefail
S=$1; MODE=$2; T=${THREADS:-4}; L=150
W=out/$S; mkdir -p $W
VS="vsearch --fastq_qmax 45 --quiet"
if [ "$MODE" = pooled ]; then
  # stdin = fastq stream
  vsearch --fastq_qmax 45 --fastq_filter - --fastq_trunclen $L --fastq_maxee 1 --fastq_maxns 0 \
     --relabel pool. --fastaout - --threads 1 2> $W/filter.log \
   | vsearch --derep_fulllength - --sizeout --relabel pool. --output $W/sample_derep.fa 2> $W/derep1.log
else
  : > $W/sample_derep.fa; : > $W/filter_counts.tsv
  for f in $S/reads/*.fastq.gz; do r=$(basename $f .fastq.gz)
    vsearch --fastq_qmax 45 --fastq_filter $f --fastq_trunclen $L --fastq_maxee 1 --fastq_maxns 0 --fastaout - 2> $W/tmp.log \
      | vsearch --derep_fulllength - --sizeout --relabel $r. --output - 2>/dev/null >> $W/sample_derep.fa
    echo -e "$r\t$(grep -E 'sequences kept' $W/tmp.log | head -1)" >> $W/filter_counts.tsv
  done; rm -f $W/tmp.log
fi
vsearch --derep_fulllength $W/sample_derep.fa --sizein --sizeout --output $W/derep.fa 2> $W/derep2.log
vsearch --cluster_unoise $W/derep.fa --minsize 8 --centroids $W/unoise.fa --threads $T 2> $W/unoise.log
vsearch --uchime3_denovo $W/unoise.fa --nonchimeras $W/nochim.fa 2> $W/uchime.log
vsearch --fastx_filter $W/nochim.fa --relabel ${S}_ASV --xsize --fastaout $W/asvs.fa 2> /dev/null
vsearch --usearch_global $W/sample_derep.fa --db $W/asvs.fa --id 0.97 --strand plus --sizein --threads $T \
   --otutabout $W/asv_table.tsv 2> $W/map.log
echo done $S
