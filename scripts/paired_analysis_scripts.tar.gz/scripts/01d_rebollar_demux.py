"""Rebollar 2019: demultiplex by the 8-nt index read SRR8570212 (no public mapping file).
Step A (mode 'barcodes'): tabulate barcodes among spots whose 8 index bases are all Q>=30; keep barcodes above the
largest abundance break of the ranked counts (log10 drop); exact match only (1-mismatch variants are NOT merged
or kept separately; such spots stay unassigned). Names R01.. by descending read count.
Step B (mode 'r1'): read R1 fastq on stdin, emit only assigned spots with header @Rxx.spot."""
import sys, gzip, collections, numpy as np, pandas as pd
mode=sys.argv[1]
if mode=='barcodes':
    cnt=collections.Counter(); allc=collections.Counter(); spots=[]; bcs=[]
    with gzip.open('rebollar2019/reads/SRR8570212.fastq.gz','rt') as f:
        while True:
            h=f.readline()
            if not h: break
            s=f.readline().strip(); f.readline(); q=f.readline().strip()
            allc[s]+=1
            if min(q)>='?': cnt[s]+=1; spots.append(int(h[1:].split('.')[1].split()[0])); bcs.append(s)
    v=np.array([c for _,c in cnt.most_common()]); lr=np.log10(v[:500]+1); d=lr[:-1]-lr[1:]; k=int(np.argmax(d))+1
    keep=[b for b,_ in cnt.most_common(k)]
    tab=pd.DataFrame({'barcode':keep,'name':[f'R{i:02d}' for i in range(1,k+1)],'reads_index_Q30_exact':[cnt[b] for b in keep]})
    tab['reads_all_quality_exact']=[allc[b] for b in keep]
    tab.to_csv('out/rebollar2019/barcode_table.tsv',sep='\t',index=False)
    nm=dict(zip(tab.barcode,range(1,k+1))); n=max(spots)+1; arr=np.zeros(n+1,dtype=np.int16)
    for sp,b in zip(spots,bcs):
        if b in nm: arr[sp]=nm[b]
    np.save('out/rebollar2019/spot_sample.npy',arr)
    ranked=pd.DataFrame(cnt.most_common(500),columns=['barcode','reads_index_Q30']); ranked.to_csv('out/rebollar2019/barcode_ranked_top500.tsv',sep='\t',index=False)
    print('total spots',sum(allc.values()),'Q30 spots',sum(cnt.values()),'unique Q30 barcodes',len(cnt),'kept',k,
          'break between',v[k-1],'and',v[k],'assigned spots',int((arr>0).sum()))
else:
    arr=np.load('out/rebollar2019/spot_sample.npy'); out=sys.stdout; inp=sys.stdin
    while True:
        h=inp.readline()
        if not h: break
        s=inp.readline(); p=inp.readline(); q=inp.readline()
        sp=int(h[1:].split('.')[1].split()[0])
        if sp<len(arr) and arr[sp]>0: out.write(f'@R{arr[sp]:02d}.{sp}\n{s}+\n{q}')
