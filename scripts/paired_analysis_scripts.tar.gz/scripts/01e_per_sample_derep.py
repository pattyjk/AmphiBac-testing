"""Per-sample dereplication of a FASTA whose headers are SAMPLE.readid (stdin) -> SAMPLE.k;size=n"""
import sys, collections
per=collections.defaultdict(collections.Counter); h=None
for l in sys.stdin:
    if l[0]=='>': h=l[1:].split('.')[0]
    else: per[h][l.strip()]+=1
with open(sys.argv[1],'w') as o:
    for s,c in per.items():
        for k,(w,n) in enumerate(c.most_common(),1): o.write(f'>{s}.{k};size={n}\n{w}\n')
for s,c in sorted(per.items()): print(s,sum(c.values()),sep='\t')
