"""Assemble paired_asv_agreement.xlsx and per-study inventory."""
import pandas as pd, numpy as np
ST=['walke2015','rebollar2019','bletz2018','molecol2019']
info={s:pd.to_numeric(pd.read_csv(f'out/{s}/step23_info.tsv',sep='\t',header=None,index_col=0)[1].drop('study')) for s in ST}
R=pd.read_csv('out/final/per_asv_calls_all.tsv',sep='\t',low_memory=False)
raw={'walke2015':'SRR2162774 single pooled R1 file; 9,087,189 reads; quality-trimmed by submitter; no sample IDs or barcodes (checked: Walke2015_BullfrogExptBFE_mapping_file barcodes occur at read starts at below-chance frequency, 26/200,000 reads; the mapping file describes the BFE bullfrog Bd experiment run, 153 samples, not the field survey)',
 'rebollar2019':'SRR8570210 R1 (250 nt) + SRR8570212 index (8 nt); 15,789,745 spots; demultiplexed here by index read (61 barcodes R01-R61; 8,908,591 spots assigned = 56.4%); R2 (SRR8570211) not used',
 'bletz2018':'266 SRA runs, R1 only (250-251 nt), primer-free',
 'molecol2019':'Dryad split_libraries FASTA, no qualities; 16,175,406 sequences, 131 sample prefixes; only merged ~465-nt reads used (4,397,902 kept)'}
filt={'walke2015':'8,681,669 kept / 405,520 discarded (trunclen 150, maxee 1, maxns 0)','rebollar2019':'8,602,356 kept / 306,235 discarded (of assigned spots)',
 'bletz2018':'4,432,409 kept / 836,750 discarded','molecol2019':'no qualities: 515F-anchored 150-nt window, no N; 4,397,902 kept; 11,594,116 reverse/short reads dropped; 183,388 merged reads without exact 515F'}
samples={'walke2015':'1 (pooled; 64 animals, 4 species per paper)','rebollar2019':'61 barcode groups (no host labels; may include non-study samples)','bletz2018':'266 (242 wild + 24 Exp1)','molecol2019':'131 sample prefixes (130 in mapping file)'}
bd={'walke2015':'population-level prevalence only; not assessed','rebollar2019':'none per individual; not assessed','bletz2018':'no per-swab Bd/Bsal loads; Exp1 Bsal-exposed vs sham control (6+6 individuals, before/after)','molecol2019':'per-sample Bd status (113) and ZE'}
assay={'walke2015':'AmphiBac (Walke 2017) CFS score=(1-PG_Bd)*100; 719 scored','rebollar2019':'AmphiBac CFS score; 355 scored (4 PossibleContamination excluded)','bletz2018':'Dryad mean PG for Bd and Bsal (694 isolates, 14 retested averaged); Bd score>80 in only 3 isolates','molecol2019':'score DERIVED from raw OD (provisional); 47 assayed, 43 with sequence'}
inv=[]
for s in ST:
    i=info[s]; r=R[R.study==s]
    inv.append({'study':s,'reads_source':raw[s],'quality_filter':filt[s],'samples':samples[s],'ASVs':int(i.n_asvs),
      'reads_mapped_to_ASVs':int(i.reads_total),'own_isolate_assays':assay[s],'own_isolates_scored_with_sequence':int(i.n_own_scored_isolates_with_seq),
      'ASVs_with_own_100pct_match':int(i.n_asv_own_match),'own_label_counts':r.own_label.value_counts().to_dict().__str__(),
      'reads_in_own_matched_ASVs':int(i.reads_own_match),'share_reads_own_matched':round(i.reads_own_match/i.reads_total,4),
      'amphibac_records_removed':int(i.n_amphibac_removed),'full_db_heldout':int(i.n_full_heldout),'inhibitory_db_heldout':int(i.n_inhib_heldout),
      'ASVs_hit99_heldout':int(i.n_asv_hit99_heldout),'share_reads_hit99_heldout':round(i.reads_hit99_heldout/i.reads_total,4),
      'share_reads_hit99_included':round(i.reads_hit99_included/i.reads_total,4),'Bd_data':bd[s]})
INV=pd.DataFrame(inv); INV.to_csv('out/final/inventory.tsv',sep='\t',index=False)
README=open('scripts/README_paired.txt').read().splitlines()
keep=R[R.own_label.notna()|R.amphibac_hit99_heldout.astype(bool)|R.amphibac_hit99_included.astype(bool)].drop(columns=['own_bin','ownB_bin'])
with pd.ExcelWriter('out/final/paired_asv_agreement.xlsx') as xw:
    pd.DataFrame({'README':README}).to_excel(xw,sheet_name='README',index=False)
    INV.to_excel(xw,sheet_name='inventory',index=False)
    keep.to_excel(xw,sheet_name='per_ASV_calls',index=False)
    pd.read_csv('out/final/agreement_summary.tsv',sep='\t').to_excel(xw,sheet_name='agreement_summary',index=False)
    pd.read_csv('out/final/per_sample_metrics.tsv',sep='\t').to_excel(xw,sheet_name='per_sample_metrics',index=False)
    pd.read_csv('out/final/per_sample_correlations.tsv',sep='\t').to_excel(xw,sheet_name='per_sample_correlations',index=False)
    pd.read_csv('out/final/bd_tests.tsv',sep='\t').to_excel(xw,sheet_name='Bd_tests',index=False)
    pd.read_csv('out/rebollar2019/barcode_table.tsv',sep='\t').to_excel(xw,sheet_name='rebollar_barcodes',index=False)
print(INV.T.to_string())
