"""Step 4: ASV-level agreement (pipeline call vs own-isolate label), per-sample metrics, Bd/Bsal tests.
Binary target: own-isolate majority Inhibitory (share of own 100%-matched isolates with score>80 is >0.5) vs not.
Pipeline calls: Inhibitory vs everything else (NoEffect, Facilitating, NotTested, PossibleContamination top hits = not Inhibitory)."""
import pandas as pd, numpy as np, os, warnings
from scipy import stats
import statsmodels.formula.api as smf
warnings.filterwarnings('ignore')
rng=np.random.default_rng(1); B=2000; MINOWN=100
ST=['walke2015','rebollar2019','bletz2018','molecol2019']
R=pd.concat([pd.read_csv(f'out/{s}/per_asv_calls.tsv',sep='\t') for s in ST],ignore_index=True)
R['own_bin']=np.where(R.own_label.isna(),np.nan,(R.own_label=='Inhibitory').astype(float))
R['ownB_bin']=np.where(R['own_Bsal_label'].isna(),np.nan,(R['own_Bsal_label']=='Inhibitory').astype(float))
inh=lambda c:np.where(R[c].isna(),np.nan,(R[c]=='Inhibitory').astype(float))
ALL=pd.Series(True,index=R.index)
RULES={ # rule: (call vector, evaluable mask beyond having an own label)
 'subset_heldout':(inh('subset_heldout'),R.amphibac_hit99_heldout.astype(bool)),
 'subset_heldout_allASVs':(inh('subset_heldout'),ALL),
 'tophit_heldout':(inh('tophit_heldout'),R.tophit_heldout.notna()),
 'exhaustive_majority_heldout':(inh('exhaustive_majority'),R.exhaustive_majority.notna()),
 'genus_majority_heldout':(inh('genus_majority'),R.genus_majority.notna()),
 'subset_included':(inh('subset_included'),R.amphibac_hit99_included.astype(bool)),
 'tophit_included':(inh('tophit_included'),R.tophit_included.notna())}
def met(y,p,w):
    y=np.asarray(y,bool); p=np.asarray(p,bool); w=np.asarray(w,float); n=len(y)
    tp=(y&p).sum(); tn=(~y&~p).sum(); fp=(~y&p).sum(); fn=(y&~p).sum()
    po=(tp+tn)/n; pe=((tp+fp)*(tp+fn)+(tn+fn)*(tn+fp))/n**2
    k=(po-pe)/(1-pe) if pe<1 else np.nan
    return dict(kappa=k,sens=tp/(tp+fn) if tp+fn else np.nan,spec=tn/(tn+fp) if tn+fp else np.nan,
        ppv=tp/(tp+fp) if tp+fp else np.nan,prev_own=y.mean(),prev_call=p.mean(),pct_agree=po,
        read_weighted_agreement=(w*(y==p)).sum()/w.sum() if w.sum()>0 else np.nan,tp=int(tp),fp=int(fp),tn=int(tn),fn=int(fn))
def boot(df,strat=None):
    ks=[]
    for b in range(B):
        if strat is None: d=df.iloc[rng.integers(0,len(df),len(df))]
        else: d=pd.concat([g.iloc[rng.integers(0,len(g),len(g))] for _,g in df.groupby(strat)])
        ks.append(met(d.y,d.p,d.w.values)['kappa'])
    ks=np.array(ks); ks=ks[~np.isnan(ks)]
    return f'{np.percentile(ks,2.5):.3f} to {np.percentile(ks,97.5):.3f}' if len(ks) else 'NA'
rows=[]
for target,ycol in [('Bd','own_bin'),('Bsal','ownB_bin')]:
    for rule,(call,mask) in RULES.items():
        for s in (ST+['pooled'] if target=='Bd' else ['bletz2018']):
            sel=R[ycol].notna()&mask&~np.isnan(call)
            if s!='pooled': sel&=(R.study==s)
            d=pd.DataFrame({'y':R.loc[sel,ycol].astype(bool),'p':call[sel].astype(bool),'w':R.loc[sel,'reads_total'],'study':R.loc[sel,'study']})
            if len(d)<5: rows.append(dict(target=target,study=s,rule=rule,n_asvs=len(d),note='fewer than 5 ASVs; not assessed')); continue
            r=dict(target=target,study=s,rule=rule,n_asvs=len(d),**met(d.y,d.p,d.w.values))
            r['kappa_ci']=boot(d,'study' if s=='pooled' else None); r['n_studies']=d.study.nunique()
            r['ci_note']='bootstrap over ASVs'+(' stratified by study' if s=='pooled' else '')
            rows.append(r)
AG=pd.DataFrame(rows)
# ---------------- per-sample metrics (walke2015 = one pooled 'sample', coverage only)
smp=[]
for s in ST:
    tab=pd.read_csv(f'out/{s}/asv_table.tsv',sep='\t',index_col=0)
    r=R[R.study==s].set_index('asv').reindex(tab.index); tot=tab.sum()
    own=r.own_label.notna().values; owninh=(r.own_label=='Inhibitory').values; oc=tab[own].sum().values
    d=pd.DataFrame({'study':s,'sample':tab.columns,'reads':tot.values,
      'pipeline_inhib_prop_heldout':tab[(r.subset_heldout=='Inhibitory').values].sum().values/tot.values,
      'pipeline_inhib_prop_included':tab[(r.subset_included=='Inhibitory').values].sum().values/tot.values,
      'reads_own_covered':oc,'share_reads_own_match':oc/tot.values,
      'share_reads_amphibac99_heldout':tab[r.amphibac_hit99_heldout.fillna(False).values.astype(bool)].sum().values/tot.values,
      'share_reads_amphibac99_included':tab[r.amphibac_hit99_included.fillna(False).values.astype(bool)].sum().values/tot.values})
    d['own_inhib_prop']=np.where(oc>0,tab[owninh].sum().values/np.maximum(oc,1),np.nan)
    sc=r.own_mean_score.fillna(0).values
    d['own_mean_score_wtd']=np.where(oc>0,tab.mul(sc,axis=0)[own].sum().values/np.maximum(oc,1),np.nan)
    if s=='bletz2018':
        ob=r.own_Bsal_label.notna().values; obi=(r.own_Bsal_label=='Inhibitory').values; obc=tab[ob].sum().values
        d['own_Bsal_inhib_prop']=np.where(obc>0,tab[obi].sum().values/np.maximum(obc,1),np.nan)
    smp.append(d)
SM=pd.concat(smp,ignore_index=True)
cor=[]
for s,g in SM.groupby('study'):
    g2=g[g.reads_own_covered>=MINOWN]
    cor.append(dict(study=s,x='coverage',n_samples=len(g),median_share_own=g.share_reads_own_match.median(),
       median_share_amphibac99_heldout=g.share_reads_amphibac99_heldout.median(),median_share_amphibac99_included=g.share_reads_amphibac99_included.median(),
       n_samples_own_ge100=len(g2)))
    if len(g2)<5: continue
    for col in ['pipeline_inhib_prop_heldout','pipeline_inhib_prop_included']:
        rho,p=stats.spearmanr(g2[col],g2.own_inhib_prop)
        cor.append(dict(study=s,x=col,y='own_inhib_prop',n_samples=len(g2),rho=rho,p=p))
    if s=='bletz2018':
        rho,p=stats.spearmanr(g2.pipeline_inhib_prop_heldout,g2.own_Bsal_inhib_prop,nan_policy='omit')
        cor.append(dict(study=s,x='pipeline_inhib_prop_heldout',y='own_Bsal_inhib_prop',n_samples=int(g2.own_Bsal_inhib_prop.notna().sum()),rho=rho,p=p))
COR=pd.DataFrame(cor)
# ---------------- Bd tests molecol2019
BD=[]
ms=pd.read_csv('molecol2019/samples.csv'); g=SM[SM.study=='molecol2019'].merge(ms,left_on='sample',right_on='sample_id')
g=g[g.life_stage.isin(['adult','juvenile','tadpole'])&g.bd_status.isin(['Positive','Negative'])&(g.reads_own_covered>=MINOWN)].copy()
g['bd']=(g.bd_status=='Positive').astype(int); g['logZE']=np.log10(g.bd_load.where(g.bd_load>0))
for col in ['pipeline_inhib_prop_heldout','own_inhib_prop','own_mean_score_wtd']:
    g['x']=(g[col]-g[col].mean())/g[col].std()
    for form,lab in [('bd ~ x','logit, unadjusted'),('bd ~ x + C(site) + C(life_stage)','logit + site + life stage')]:
        try:
            f=smf.logit(form,g).fit(disp=0); ci=f.conf_int().loc['x']
            BD.append(dict(study='molecol2019',test=lab,outcome='Bd status (Positive vs Negative)',metric=col,n=int(f.nobs),n_pos=int(g.bd.sum()),
               coef_per_SD=f.params['x'],OR_per_SD=np.exp(f.params['x']),p=f.pvalues['x'],ci95=f'{np.exp(ci[0]):.3f} to {np.exp(ci[1]):.3f} (OR)'))
        except Exception as e: BD.append(dict(study='molecol2019',test=lab,metric=col,note=f'fit failed: {e}'))
    gi=g[g.logZE.notna()]
    for form,lab in [('logZE ~ x','OLS log10 ZE among infected, unadjusted'),('logZE ~ x + C(site) + C(life_stage)','OLS log10 ZE among infected + site + life stage')]:
        f=smf.ols(form,gi).fit(); ci=f.conf_int().loc['x']
        BD.append(dict(study='molecol2019',test=lab,outcome='log10 ZE (infected)',metric=col,n=int(f.nobs),coef_per_SD=f.params['x'],p=f.pvalues['x'],ci95=f'{ci[0]:.3f} to {ci[1]:.3f}'))
    rho,p=stats.spearmanr(gi[col],gi.logZE); BD.append(dict(study='molecol2019',test='Spearman, infected',outcome='log10 ZE',metric=col,n=len(gi),rho=rho,p=p))
# ---------------- Bletz Exp1 Bsal exposure
bs=pd.read_csv('bletz2018/samples.csv'); b=SM[SM.study=='bletz2018'].merge(bs,left_on='sample',right_on='run_accession')
e=b[b.treatment.str.startswith('Exp1')].copy()
e['grp']=np.where(e.treatment.str.contains('Inf.ind'),'Bsal-exposed','control'); e['time']=np.where(e.treatment.str.contains('After'),'After','Before')
e['ind']=e.sample_id.astype(str).str.extract(r'(\d+)')[0]
for col in ['pipeline_inhib_prop_heldout','own_inhib_prop','own_mean_score_wtd','own_Bsal_inhib_prop']:
    a_=e[e.time=='After']; x=a_[a_.grp=='Bsal-exposed'][col].dropna(); y=a_[a_.grp=='control'][col].dropna()
    u,p=stats.mannwhitneyu(x,y); BD.append(dict(study='bletz2018',test='Mann-Whitney, after exposure: exposed vs control',outcome='Exp1 group',metric=col,n=len(x)+len(y),
       median_exposed=x.median(),median_control=y.median(),U=u,p=p))
    w=e.pivot_table(index=['ind','grp'],columns='time',values=col).dropna().reset_index()
    if len(w) and w.grp.nunique()==2:
        w['delta']=w.After-w.Before; x=w[w.grp=='Bsal-exposed'].delta; y=w[w.grp=='control'].delta; u,p=stats.mannwhitneyu(x,y)
        BD.append(dict(study='bletz2018',test='Mann-Whitney on change (after - before): exposed vs control',outcome='Exp1 group',metric=col,n=len(w),
          median_exposed=x.median(),median_control=y.median(),U=u,p=p,note=f'individuals with both timepoints: {len(w)} (individual = digits of sample_id)'))
BDT=pd.DataFrame(BD)
os.makedirs('out/final',exist_ok=True)
AG.to_csv('out/final/agreement_summary.tsv',sep='\t',index=False); SM.to_csv('out/final/per_sample_metrics.tsv',sep='\t',index=False)
COR.to_csv('out/final/per_sample_correlations.tsv',sep='\t',index=False); BDT.to_csv('out/final/bd_tests.tsv',sep='\t',index=False)
R.to_csv('out/final/per_asv_calls_all.tsv',sep='\t',index=False)
pd.set_option('display.width',250)
print(AG[['target','study','rule','n_asvs','kappa','kappa_ci','sens','spec','ppv','prev_own','read_weighted_agreement']].round(3).to_string())
print(COR.round(3).to_string()); print(BDT.drop(columns=[c for c in ['note','outcome'] if c in BDT]).round(4).to_string())
