"""MolEcol2019 (Ellison 2019) deposited split_libraries FASTA (no qualities, V3-V4 341F/805R, mixed read types).
Choice (revised after inspection): only MERGED amplicon reads (length >= 400 nt; 4,581,290 of 16,175,406 = 28.3% of sequences; README estimate of ~19% from the first 200k records was low) are used. The 300-nt reverse
reads were dropped: their V4 start lies in the error-prone 3' tail and only 6.6% retain an intact 515F site (no qualities
to filter errors). Merged reads are oriented so that the 515F site reads forward; locate the 515F
site (GTGCCAGCMGCCGCGGTAA, exact), keep the 150 nt immediately downstream (= same V4 window as the V4-R1 studies,
and within the region the isolate Sanger sequences cover). Reads without a full 515F site or <150 nt after it, or
with any N, are dropped. Output: per-sample dereplicated uniques with ;size= (label SAMPLE.k)."""
import gzip, re, collections, sys
L=150
comp=str.maketrans('ACGTN','TGCAN'); rc=lambda s:s.translate(comp)[::-1]
F515=re.compile('GTGCCAGC[AC]GCCGCGGTAA')
R805=re.compile('^GACTAC[ACT][ACG]GGGTATCTAATCC')
F341=re.compile('^CCTACGG[ACGT]GGC[AT]GCAG')
stats=collections.Counter(); per=collections.defaultdict(collections.Counter)
def handle(h,s):
    samp=h[1:].split()[0].rsplit('_',1)[0]
    if len(s)<400: stats['reverse_or_short_dropped']+=1; return
    m=F515.search(s)
    if not m:
        s=rc(s); m=F515.search(s)
    if not m: stats['merged_no515']+=1; return
    w=s[m.end():m.end()+L]
    if len(w)<L: stats['merged_short']+=1; return
    if 'N' in w: stats['merged_N']+=1; return
    stats['merged_kept']+=1; per[samp][w]+=1
h=None; buf=[]
with gzip.open(sys.argv[1],'rt') as f:
    for l in f:
        if l[0]=='>':
            if h: handle(h,''.join(buf))
            h=l; buf=[]
        else: buf.append(l.strip().upper())
    if h: handle(h,''.join(buf))
with open(sys.argv[2],'w') as o:
    for samp,c in per.items():
        for k,(w,n) in enumerate(c.most_common(),1): o.write(f'>{samp}.{k};size={n}\n{w}\n')
with open(sys.argv[3],'w') as o:
    for k,v in sorted(stats.items()): o.write(f'{k}\t{v}\n')
    for samp,c in sorted(per.items()): o.write(f'sample\t{samp}\t{sum(c.values())}\n')
