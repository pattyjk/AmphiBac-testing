"""Step 2 (own-isolate truth) and step 3 (AmphiBac 2025.1 pipeline calls, study held out) for one study.
usage: python 02_truth_and_calls.py STUDY"""
import sys, os, subprocess, pandas as pd, numpy as np
S=sys.argv[1]; W=f'out/{S}'; T=os.environ.get('THREADS','8')
REF={'walke2015':'AEM.01486-15','rebollar2019':'s41396-019-0388-x','bletz2018':'rspb.2018.0758','molecol2019':'mec.14964'}
def lab(sc):
    return np.where(sc>80,'Inhibitory',np.where(sc<=-20,'Facilitating','NoEffect'))
def readfa(f):
    d={};k=None
    for l in open(f):
        l=l.rstrip()
        if l.startswith('>'): k=l[1:]; d[k]=[]
        else: d[k].append(l)
    return {k:''.join(v) for k,v in d.items()}
def writefa(d,f):
    with open(f,'w') as o:
        for k,v in d.items(): o.write(f'>{k}\n{v}\n')
def vs(args): subprocess.run(['vsearch','--quiet','--threads',T]+args,check=True,stderr=subprocess.DEVNULL)
UF='query+target+id+qcov+tcov+alnlen+mism+opens'
def userout(f):
    if os.path.getsize(f)==0: return pd.DataFrame(columns=UF.split('+'))
    d=pd.read_csv(f,sep='\t',header=None,names=UF.split('+')); return d
# ---------- own isolates: header -> isolate id, score
a=pd.read_csv(f'{S}/isolate_assays.csv')
iso=readfa(f'{S}/isolates.fasta')
if S=='bletz2018':
    a=a.groupby('isolate_id',as_index=False).agg(score=('score','mean'),score_Bsal=('score_Bsal','mean'),n_assay_rows=('score','size'))
    key={h:h.split('|')[0] for h in iso}
elif S=='molecol2019':
    key={h:(h[:-1] if h.endswith('F') and h[:-1] in set(a.isolate_id) else h) for h in iso}
else:
    a['acc']=a.accession.astype(str)
    a=a[~a.label.isin(['PossibleContamination'])]   # excluded, as in AmphiBac subsets
    m1=dict(zip(a.acc,a.isolate_id)); ids=set(a.isolate_id)
    key={}
    for h in iso:
        t=h.split()[0]; key[h]=m1.get(t,t if t in ids else None)
a=a[a.score.notna()].copy(); a['own_label']=lab(a.score.values)
sc=dict(zip(a.isolate_id,a.score)); scb=dict(zip(a.isolate_id,a.score_Bsal)) if 'score_Bsal' in a else {}
own={f'own{i}':iso[h] for i,h in enumerate(iso) if key.get(h) in sc}
ownmap={f'own{i}':key[h] for i,h in enumerate(iso) if key.get(h) in sc}
writefa(own,f'{W}/own_isolates_scored.fa')
asv=readfa(f'{W}/asvs.fa')
vs(['--usearch_global',f'{W}/asvs.fa','--db',f'{W}/own_isolates_scored.fa','--id','1.0','--query_cov','1.0',
    '--maxaccepts','0','--maxrejects','0','--strand','both','--qmask','none','--minseqlength','1','--userfields',UF,'--userout',f'{W}/own_hits.tsv'])
h=userout(f'{W}/own_hits.tsv'); h=h[(h.id>=100)&(h.qcov>=100)&(h.mism==0)&(h.opens==0)]
h['iso']=h.target.map(ownmap); h=h.drop_duplicates(['query','iso'])
h['score']=h.iso.map(sc); h['lab']=lab(h.score.values)
g=h.groupby('query')
own_t=pd.DataFrame({'own_n_isolates':g.size(),'own_share_inhib':g.lab.apply(lambda x:(x=='Inhibitory').mean()),
    'own_share_fac':g.lab.apply(lambda x:(x=='Facilitating').mean()),'own_mean_score':g.score.mean(),
    'own_isolates':g.iso.apply(lambda x:';'.join(sorted(x)))})
own_t['own_label']=np.where(own_t.own_share_inhib>0.5,'Inhibitory',np.where(own_t.own_share_fac>0.5,'Facilitating','NoEffect'))
# within-ASV conflict: 1 - share of the most common 3-class label
own_t['own_conflict_rate']=g.lab.apply(lambda x:1-x.value_counts(normalize=True).iloc[0])
own_t['own_label_tie']=g.lab.apply(lambda x:(x=='Inhibitory').mean()==0.5)
if scb:
    h['score_Bsal']=h.iso.map(scb); h['labB']=lab(h.score_Bsal.values)
    gb=h[h.score_Bsal.notna()].groupby('query')
    own_t['own_Bsal_n']=gb.size(); own_t['own_Bsal_share_inhib']=gb.labB.apply(lambda x:(x=='Inhibitory').mean())
    own_t['own_Bsal_mean_score']=gb.score_Bsal.mean()
    own_t['own_Bsal_label']=np.where(own_t.own_Bsal_share_inhib>0.5,'Inhibitory',np.where(own_t.own_Bsal_n>0,'NotInhibitory',None))
# ---------- AmphiBac held out
m=pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv',sep='\t',low_memory=False)
gen=pd.read_csv('genus_assignments.csv'); gmap=dict(zip(gen.FastaID,gen.genus_full))
labA=dict(zip(m.FastaID,m['AntiFungal.Function.with.AP.function']))
aa=pd.read_csv(f'{S}/isolate_assays.csv')
idc=[c for c in aa.columns if c.lower()=='amphibac_fastaid']
rm=set(m.FastaID[m.Reference.astype(str).str.contains(REF[S],regex=False)])
rm|=set(aa[idc[0]].dropna()) if idc else set()
rm|=set(m.FastaID[m['Isolate.ID'].astype(str).isin(set(aa.isolate_id.astype(str)))])
accs=set(aa.accession.dropna().astype(str).str.split('.').str[0])
rm|=set(m.FastaID[m['GenBank.Accession'].astype(str).str.split('.').str[0].isin(accs)])
full=readfa('db/FullDatabase_2025.1.fasta'); inh=readfa('db/Inhibitory_2025.1.fasta')
writefa({k:v for k,v in full.items() if k not in rm},f'{W}/full_heldout.fa')
writefa({k:v for k,v in inh.items() if k not in rm},f'{W}/inhib_heldout.fa')
Q=['--usearch_global',f'{W}/asvs.fa','--strand','both','--qmask','none','--minseqlength','1','--userfields',UF]
def run(db,tag,ident='0.99',extra=[]):
    vs(Q+['--db',db,'--id',ident,'--userout',f'{W}/pipe_{tag}.tsv']+extra); return userout(f'{W}/pipe_{tag}.tsv')
sub_ho=run(f'{W}/inhib_heldout.fa','subset_heldout'); sub_in=run('db/Inhibitory_2025.1.fasta','subset_included')
top_ho=run(f'{W}/full_heldout.fa','top_heldout'); top_in=run('db/FullDatabase_2025.1.fasta','top_included')
exh=run(f'{W}/full_heldout.fa','exhaustive_heldout',extra=['--maxaccepts','0','--maxrejects','0','--query_cov','1.0'])
g97=run(f'{W}/full_heldout.fa','genus97_heldout',ident='0.97')
R=pd.DataFrame(index=list(asv))
R['amphibac_hit99_heldout']=R.index.isin(top_ho['query']); R['amphibac_hit99_included']=R.index.isin(top_in['query'])
R['subset_heldout']=np.where(R.index.isin(sub_ho['query']),'Inhibitory','NotInhibitory')
R['subset_included']=np.where(R.index.isin(sub_in['query']),'Inhibitory','NotInhibitory')
t=top_ho.drop_duplicates('query').set_index('query'); R['tophit_heldout_id']=t.target; R['tophit_heldout']=t.target.map(labA)
t=top_in.drop_duplicates('query').set_index('query'); R['tophit_included_id']=t.target; R['tophit_included']=t.target.map(labA)
e=exh[(exh.qcov>=100)].copy(); e['lab']=e.target.map(labA); R['exh_n_hits99']=e.groupby('query').size()
el=e[e.lab.isin(['Inhibitory','NoEffect','Facilitating'])]; ge=el.groupby('query')
R['exh_n_labelled']=ge.size(); R['exh_share_inhib']=ge.lab.apply(lambda x:(x=='Inhibitory').mean())
R['exhaustive_majority']=np.where(R.exh_share_inhib.isna(),None,np.where(R.exh_share_inhib>0.5,'Inhibitory','NotInhibitory'))
# genus baseline: genus of best held-out hit at >=97%; genus label = majority of labelled held-out isolates of that genus
mh=m[~m.FastaID.isin(rm)].copy(); mh['genus']=mh.FastaID.map(gmap); mh['lab']=mh['AntiFungal.Function.with.AP.function']
mh=mh[mh.lab.isin(['Inhibitory','NoEffect','Facilitating'])&mh.genus.notna()]
gshare=mh.groupby('genus').lab.apply(lambda x:(x=='Inhibitory').mean())
t=g97.drop_duplicates('query').set_index('query'); R['genus97_heldout']=t.target.map(gmap)
R['genus_share_inhib']=R.genus97_heldout.map(gshare)
R['genus_majority']=np.where(R.genus_share_inhib.isna(),None,np.where(R.genus_share_inhib>0.5,'Inhibitory','NotInhibitory'))
R=R.join(own_t)
tab=pd.read_csv(f'{W}/asv_table.tsv',sep='\t',index_col=0)
R['reads_total']=tab.sum(axis=1).reindex(R.index).fillna(0).astype(int)
R.insert(0,'study',S); R.index.name='asv'; R['sequence']=pd.Series(asv)
R.to_csv(f'{W}/per_asv_calls.tsv',sep='\t')
info=dict(study=S,n_asvs=len(R),n_own_scored_isolates_with_seq=len(own),n_assayed_scored=int(a.shape[0]),
  n_amphibac_removed=len(rm),n_full_heldout=len(full)-len(rm & set(full)),n_inhib_heldout=len(inh)-len(rm & set(inh)),
  n_asv_own_match=int(R.own_n_isolates.notna().sum()),n_asv_hit99_heldout=int(R.amphibac_hit99_heldout.sum()),
  reads_total=int(R.reads_total.sum()),reads_own_match=int(R.reads_total[R.own_n_isolates.notna()].sum()),
  reads_hit99_heldout=int(R.reads_total[R.amphibac_hit99_heldout].sum()),reads_hit99_included=int(R.reads_total[R.amphibac_hit99_included].sum()))
pd.Series(info).to_csv(f'{W}/step23_info.tsv',sep='\t',header=False); print(info)
