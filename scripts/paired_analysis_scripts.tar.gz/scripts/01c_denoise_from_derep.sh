#!/bin/bash
# Denoise from an existing per-sample dereplicated file out/STUDY/sample_derep.fa (labels SAMPLE.k;size=n)
set -euo pipefail
S=$1; T=${THREADS:-8}; W=out/$S
vsearch --derep_fulllength $W/sample_derep.fa --sizein --sizeout --output $W/derep.fa 2> $W/derep2.log
vsearch --cluster_unoise $W/derep.fa --minsize 8 --centroids $W/unoise.fa --threads $T 2> $W/unoise.log
vsearch --uchime3_denovo $W/unoise.fa --nonchimeras $W/nochim.fa 2> $W/uchime.log
vsearch --fastx_filter $W/nochim.fa --relabel ${S}_ASV --xsize --fastaout $W/asvs.fa 2> /dev/null
vsearch --usearch_global $W/sample_derep.fa --db $W/asvs.fa --id 0.97 --strand plus --sizein --threads $T --otutabout $W/asv_table.tsv 2> $W/map.log
echo done $S
