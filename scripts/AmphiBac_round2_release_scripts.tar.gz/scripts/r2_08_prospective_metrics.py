"""Round 2, test 2: prospective prediction of isolates added after 2020.6 / 2023.2 from the older release (id 0.99).
Rules (round-1 definitions): R1 Func of q2-default top hit in older Full (older-release labels); R1c same hit but 2025.1 labels
(isolates relabelling from new-reference effects); R2 default hit in older Inhibitory subset (2023.2 only); R3 default hit in older
InhibitoryStrict; R4 majority over all exhaustive hits with 100*ids/alnlen >= 99 among tested refs (Inh > NoEff+Facil; tie -> non-inh).
Truth: 2025.1 Func == Inhibitory. Queries: 3-class tested (Inhibitory/NoEffect/Facilitating) new isolates, IUPAC-free fragments.
Basis 'all': no call -> non-inhibitory; 'matched': only queries with a call. CIs: study-cluster bootstrap (Reference|Researchers), B=1000;
isolate bootstrap also given. Comparator: round-1 leave-self-out predictions within 2025.1 for the same isolates (argv[1])."""
import pandas as pd, numpy as np, sys, glob
CL = ['Inhibitory', 'NoEffect', 'Facilitating']; B = 1000
T = pd.read_csv('prosp/isolate_release_table.csv', index_col=0)
m5 = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', dtype=str, encoding='latin1').set_index('FastaID')
T['study'] = T.Reference.fillna('NA') + ' | ' + m5.Researchers.fillna('NA').reindex(T.index)
ID20 = dict(zip(m5['FastaID.2020'].str.lstrip('>'), m5.index))
OLDLAB = {'2020.6': T['label_2020.6'].dropna().to_dict(), '2023.2': T['label_2023.2'].dropna().to_dict()}
def tr(coh, r): return ID20.get(r, r) if coh == '2020.6' else r
def read_uc(p, coh):
    u = pd.read_csv(p, sep='\t', header=None, usecols=[0, 8, 9], names=['t', 'q', 'h'], dtype=str); u = u[u.t == 'H']
    return pd.Series([tr(coh, h) for h in u.h], index=u.q)
def bin_stats(TP, FP, TN, FN, M, N):
    n = TP + FP + TN + FN
    with np.errstate(all='ignore'):
        se = TP / (TP + FN); sp = TN / (TN + FP); acc = (TP + TN) / n; pe = ((TP + FP) * (TP + FN) + (FN + TN) * (FP + TN)) / n**2
        return dict(match_rate=M / N, n_scored=n, accuracy=acc, sensitivity=se, specificity=sp, PPV=TP / (TP + FP), NPV=TN / (TN + FN),
                    balanced_accuracy=(se + sp) / 2, kappa=(acc - pe) / (1 - pe))
r1 = pd.read_csv(sys.argv[1], low_memory=False); r1 = r1[(r1.excl == 'self') & (r1.t == 0.99)]
preds, rows = [], []; rng = np.random.default_rng(1)
for coh in ['2020.6', '2023.2']:
    for f in ['120', 'V4full']:
        q = T[T[f'new_vs_{coh}'] & T.Func_2025.isin(CL) & T[f'has_{f}'] & ~T[f'iupac_{f}']].copy()
        D = pd.DataFrame(index=q.index); D['study'] = q.study; D['truth'] = q.Func_2025
        D['new_study'] = q[f'new_study_vs_{coh}']
        h = read_uc(f'prosp/uc/{coh}_{f}_FullDatabase.uc', coh); D['R1_hit'] = h.reindex(D.index)
        D['R1_label'] = D.R1_hit.map(OLDLAB[coh]); D['R1c_label'] = D.R1_hit.map(T.Func_2025)
        for sub, rule in [('Inhibitory', 'R2'), ('InhibitoryStrict', 'R3')]:
            p = f'prosp/uc/{coh}_{f}_{sub}.uc'
            D[rule] = D.index.isin(read_uc(p, coh).index) if glob.glob(p) else np.nan
        e = pd.read_csv(f'prosp/uc/{coh}_{f}_exh.tsv', sep='\t', names='q t id mism gaps alnlen ids ql tl qilo qihi'.split())
        e['t'] = [tr(coh, x) for x in e.t]; e['idx'] = 100 * e.ids / e.alnlen
        e = e[e.idx >= 99].sort_values('idx', ascending=False).drop_duplicates(['q', 't']); e['lab'] = e.t.map(OLDLAB[coh])
        vc = e[e.lab.isin(CL)].groupby(['q', 'lab']).size().unstack(fill_value=0).reindex(columns=CL, fill_value=0).reindex(D.index).fillna(0)
        D['n_qual'] = e.groupby('q').size().reindex(D.index).fillna(0).astype(int)
        D['R4_has'] = vc.sum(1) > 0; D['R4'] = vc.Inhibitory > (vc.NoEffect + vc.Facilitating)
        D['R1_has'] = D.R1_hit.notna(); D['R1'] = D.R1_label.eq('Inhibitory'); D['R1c'] = D.R1c_label.eq('Inhibitory')
        D['R1_untested_hit'] = D.R1_has & ~D.R1_label.isin(CL)
        rr = r1[r1.frag == f].set_index('FastaID').reindex(D.index)
        D['LOO2025_R1'] = rr.R1_3.eq('Inhibitory'); D['LOO2025_R1_has'] = rr.R1_hit.notna(); D['LOO2025_R4'] = rr.R4_bin.astype(str).eq('True')
        D['LOO2025_R4_has'] = rr.R4_has.astype(str).eq('True'); D['LOO2025_R3'] = rr.R3.astype(str).eq('True'); D['LOO2025_R2'] = rr.R2.astype(str).eq('True')
        D['cohort'] = f'new_vs_{coh}'; D['frag'] = f; preds.append(D.reset_index().rename(columns={'index': 'FastaID'}))
        y = D.truth.eq('Inhibitory').values; studies = np.array(sorted(D.study.unique())); S = len(studies)
        si = pd.Categorical(D.study, categories=studies).codes
        Ws = rng.multinomial(S, np.ones(S) / S, size=B); Wi = rng.multinomial(len(D), np.ones(len(D)) / len(D), size=B)
        rules = [('R1_tophit', 'R1', 'R1_has'), ('R1_tophit_2025labels', 'R1c', 'R1_has'), ('R2_Inhibitory', 'R2', 'R2'),
                 ('R3_InhibitoryStrict', 'R3', 'R3'), ('R4_majority', 'R4', 'R4_has'),
                 ('LOO2025_R1_tophit', 'LOO2025_R1', 'LOO2025_R1_has'), ('LOO2025_R2_Inhibitory', 'LOO2025_R2', 'LOO2025_R2'),
                 ('LOO2025_R3_InhibitoryStrict', 'LOO2025_R3', 'LOO2025_R3'), ('LOO2025_R4_majority', 'LOO2025_R4', 'LOO2025_R4_has')]
        for name, pc, hc in rules:
            if D[pc].isna().all(): continue
            pred = D[pc].astype(bool).values; has = D[hc].astype(bool).values
            for basis in (['all', 'matched'] if pc in ('R1', 'R1c', 'R4', 'LOO2025_R1', 'LOO2025_R4') else ['all']):
                k = np.ones(len(y), bool) if basis == 'all' else has
                cnt = np.zeros((len(y), 6)); cnt[:, 0] = y & pred & k; cnt[:, 1] = ~y & pred & k; cnt[:, 2] = ~y & ~pred & k; cnt[:, 3] = y & ~pred & k
                cnt[:, 4] = has; cnt[:, 5] = 1
                cs = np.zeros((S, 6)); np.add.at(cs, si, cnt)
                pt = bin_stats(*cnt.sum(0)); bs = bin_stats(*(Ws @ cs).T); bi = bin_stats(*(Wi @ cnt).T)
                for m, v in pt.items():
                    lo, hi = np.nanpercentile(bs[m], [2.5, 97.5]) if m != 'n_scored' else (np.nan, np.nan)
                    ilo, ihi = np.nanpercentile(bi[m], [2.5, 97.5]) if m != 'n_scored' else (np.nan, np.nan)
                    rows.append(dict(cohort=f'new_vs_{coh}', older_release=coh, fragment=f, rule=name, basis=basis, metric=m, value=v,
                                     ci_lo_study=lo, ci_hi_study=hi, ci_lo_isolate=ilo, ci_hi_isolate=ihi, n_queries=len(y),
                                     n_inhibitory_truth=int(y.sum()), n_studies=S))
P = pd.concat(preds, ignore_index=True); P.to_csv('prosp/prospective_predictions_per_isolate.csv', index=False)
M = pd.DataFrame(rows); M.to_csv('prosp/prospective_metrics_long.csv', index=False)
# per-study breakdown (point estimates)
ps = []
for (c, f, s), D in P.groupby(['cohort', 'frag', 'study']):
    y = D.truth.eq('Inhibitory')
    for name, pc, hc in [('R1_tophit', 'R1', 'R1_has'), ('R4_majority', 'R4', 'R4_has'), ('R3_InhibitoryStrict', 'R3', 'R3')]:
        p = D[pc].astype(bool); ps.append(dict(cohort=c, fragment=f, study=s, new_study=bool(D.new_study.iloc[0]), rule=name, n=len(D), n_inh=int(y.sum()),
            match_rate=D[hc].astype(bool).mean(), TP=int((y & p).sum()), FP=int((~y & p).sum()), TN=int((~y & ~p).sum()), FN=int((y & ~p).sum())))
pd.DataFrame(ps).to_csv('prosp/prospective_per_study.csv', index=False)
pd.set_option('display.width', 250)
W = M[M.metric.isin(['match_rate', 'kappa', 'sensitivity', 'specificity', 'PPV'])]
W = W.assign(txt=W.value.round(2).astype(str) + ' [' + W.ci_lo_study.round(2).astype(str) + ',' + W.ci_hi_study.round(2).astype(str) + ']')
print(W.pivot_table(index=['cohort', 'fragment', 'rule', 'basis'], columns='metric', values='txt', aggfunc='first').to_string())
print(M.groupby(['cohort', 'fragment']).agg(n=('n_queries', 'first'), ninh=('n_inhibitory_truth', 'first'), S=('n_studies', 'first')))
