"""Figure for test 2 (prospective prediction). Exec'd in a kernel with figure-style helpers."""
import pandas as pd, numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
apply_figure_style(sizes=(8,7,6))
M=pd.read_csv('prosp/prospective_metrics_long.csv',dtype={'older_release':str}); T=pd.read_csv('prosp/isolate_release_table.csv',index_col=0)
M=M[M.basis=='all']
rules=[('R1_tophit','R1 top hit'),('R2_Inhibitory','R2 Inhibitory subset'),('R3_InhibitoryStrict','R3 Strict subset'),('R4_majority','R4 majority')]
fig,axs=plt.subplots(1,3,figsize=(7.4,2.9),gridspec_kw=dict(width_ratios=[1.25,1.25,0.9],wspace=0.6))
combos=[('new_vs_2020.6','120'),('new_vs_2020.6','V4full'),('new_vs_2023.2','120'),('new_vs_2023.2','V4full')]
cc={('new_vs_2020.6','120'):'#6baed6',('new_vs_2020.6','V4full'):'#08519c',('new_vs_2023.2','120'):'#bdbdbd',('new_vs_2023.2','V4full'):'#525252'}
for ax,metric,ttl in [(axs[0],'kappa','No rule predicts new isolates'),(axs[1],'specificity','Specificity stays low')]:
    for i,(r,lab) in enumerate(rules):
        for j,c in enumerate(combos):
            for k,pref in enumerate(['', 'LOO2025_']):
                q=M[(M.cohort==c[0])&(M.fragment==c[1])&(M.rule==pref+r)&(M.metric==metric)]
                if q.empty: continue
                q=q.iloc[0]; y=i+(j-1.5)*0.18+(0.06 if pref else -0.06)
                ax.errorbar(q.value,y,xerr=[[q.value-q.ci_lo_study],[q.ci_hi_study-q.value]],fmt='o' if not pref else 'D',ms=3.2,
                            color=cc[c],mfc=cc[c] if not pref else 'white',lw=0.7,capsize=0)
    ax.set_yticks(range(4)); ax.set_yticklabels([l for _,l in rules] if metric=='kappa' else []); ax.invert_yaxis()
    ax.set_xlabel("Cohen's κ (binary inhibitory)" if metric=='kappa' else 'Specificity'); ax.set_title(ttl,loc='left',fontsize=7.5)
    if metric=='kappa': ax.axvline(0,color='0.5',lw=0.7); ax.set_xlim(-0.35,0.45)
    else: ax.set_xlim(0,1)
h=[Line2D([],[],marker='o',ls='',color=cc[c],label=f"{c[0].replace('new_vs_','after ')} · {'120 bp' if c[1]=='120' else 'full V4'}") for c in combos]
h+=[Line2D([],[],marker='o',ls='',color='0.3',label='predicted from older release'),Line2D([],[],marker='D',ls='',color='0.3',mfc='white',label='leave-self-out in 2025.1')]
fig.legend(handles=h,frameon=False,fontsize=6,loc='upper center',bbox_to_anchor=(0.36,0.0),ncol=3)
ax=axs[2]; CL=['Inhibitory','NoEffect','Facilitating']
steps=[]
for coh in ['2020.6','2023.2']:
    n=T[f'new_vs_{coh}']; t=n&T.Func_2025.isin(CL)
    steps.append((coh,[n.sum(),t.sum(),(t&T.has_V4full).sum(),(t&T.has_120).sum()]))
labs=['added isolates','tested (3 classes)','full V4 cut','120 bp cut']
for k,(coh,v) in enumerate(steps):
    ax.barh(np.arange(4)+(k-0.5)*0.38,v,height=0.36,color=['#08519c','#525252'][k],label=f'added after {coh}')
    for i,x in enumerate(v): ax.text(x+20,i+(k-0.5)*0.38,f'{x:,}',va='center',fontsize=6)
ax.set_yticks(range(4)); ax.set_yticklabels(labs); ax.invert_yaxis(); ax.set_xlabel('Isolates'); ax.set_xlim(0,1750)
ax.legend(frameon=False,fontsize=6,loc='upper center',bbox_to_anchor=(0.5,-0.2),ncol=1); ax.set_title('Half of new isolates lack V4',loc='left',fontsize=7.5)
for a,l in zip(axs,'abc'): panel_letter(a,l)
fig.savefig('fig_r2_prospective.png',dpi=300,bbox_inches='tight')
r_=fig.canvas.get_renderer(); Tx=[t for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
bb=[t.get_window_extent(r_) for t in Tx]; print('overlaps',[(Tx[i].get_text()[:20],Tx[j].get_text()[:20]) for i in range(len(Tx)) for j in range(i+1,len(Tx)) if bb[i].overlaps(bb[j])])
