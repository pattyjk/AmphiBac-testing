"""Round 2, test 1: per-sample pipeline outputs (Total/Proportion/Richness) per release x subset, release-to-release agreement,
and stability of the three meta-analysis contrasts. Run from r2rel/ after r2_01_prepare.py and r2_02_vsearch_releases.sh.
argv[1] = meta map file; argv[2] = round-1 meta_per_sample_methods.csv (sanity check)."""
import numpy as np, pandas as pd, scipy.sparse as sp, sys, os, itertools
from scipy import stats
MAP, R1 = sys.argv[1], sys.argv[2]; os.makedirs('out', exist_ok=True)
REL = {'2020.6': ['FullDatabase', 'InhibitoryStrict'], '2023.2': ['FullDatabase', 'Inhibitory', 'InhibitoryStrict', 'Facilitating'],
       '2025.1': ['FullDatabase', 'Inhibitory', 'InhibitoryStrict', 'Facilitating']}
def rarefy(M, depth, seed):
    rng = np.random.default_rng(seed); M = M.tocsc(); rows, cols, vals = [], [], []
    for j in range(M.shape[1]):
        s, e = M.indptr[j], M.indptr[j+1]; c = M.data[s:e].astype(np.int64)
        if c.sum() < depth: continue
        d = rng.multivariate_hypergeometric(c, depth); k = d > 0
        rows.append(M.indices[s:e][k]); cols.append(np.full(k.sum(), j)); vals.append(d[k])
    return sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=M.shape)
def read_uc(p):
    u = pd.read_csv(p, sep='\t', header=None, usecols=[0, 8, 9], names=['t', 'q', 'r']); u = u[u.t == 'H']
    return dict(zip(u.q.str.split(';').str[0], u.r.astype(str).str.split().str[0]))
def load(ds):
    if ds == 'meta':
        feats = pd.read_csv('work/meta_features.csv').fid.tolist(); samples = pd.read_csv('work/meta_samples.csv', header=None)[0].tolist()
        return feats, samples, 1000, sp.load_npz('work/meta_rare_s1.npz').tocsr()
    bf = pd.read_csv('work/bf_raw.csv', index_col=0); bf = bf.loc[:, bf.sum(axis=0) >= 10]; depth = int(bf.sum(axis=0).min())
    return bf.index.tolist(), bf.columns.tolist(), depth, rarefy(sp.csc_matrix(bf.values.round().astype(np.int64)), depth, 1).tocsr()
def outputs(R, feats, hit, depth):
    fi = {f: i for i, f in enumerate(feats)}; pairs = [(fi[q], r) for q, r in hit.items() if q in fi]
    refs = sorted({r for _, r in pairs}); ri = {r: i for i, r in enumerate(refs)}
    A = sp.csr_matrix((np.ones(len(pairs)), ([ri[r] for _, r in pairs], [i for i, _ in pairs])), shape=(len(refs), len(feats)))
    C = A @ R; tot = np.asarray(C.sum(0)).ravel()
    return tot, tot / depth, np.asarray((C > 0).sum(0)).ravel()
def quart(x):
    r = pd.Series(x).rank(method='average'); return np.clip(np.ceil(4 * r / r.notna().sum()), 1, 4)
rows, frows, all_df, LROWS = [], [], {}, []
m5 = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', dtype=str, encoding='latin1')
m3 = pd.read_csv('rel/AmphibBac_Metadata_2023.2.txt', sep='\t', dtype=str, encoding='latin1')
ID20 = dict(zip(m5['FastaID.2020'].str.lstrip('>'), m5.FastaID))
FUNC = 'AntiFungal.Function.with.AP.function'
def norm(x): return {'Pos.Contam': 'PossibleContamination', 'PosContam': 'PossibleContamination'}.get(x, x)
LAB = {'2025.1': {k: norm(v) for k, v in zip(m5.FastaID, m5[FUNC])}, '2023.2': {k: norm(v) for k, v in zip(m3.FastaID, m3[FUNC].fillna('NA'))},
       '2020.6': {ID20[k]: norm(k.split('.')[-1]) for k in ID20 if isinstance(k, str)}}
for ds in ('meta', 'bf'):
    feats, samples, depth, R = load(ds); S = {}; present = np.asarray(R.sum(1)).ravel() > 0
    H = {(rel, m): read_uc(f'work/ucrel/{ds}_{rel}_{m}.uc') for rel in REL for m in REL[rel]}
    # 2020.6 headers are descriptive names; translate to stable AmphiBac FastaIDs via 2025.1 FastaID.2020 (verified identical sequences)
    for m in REL['2020.6']: H[('2020.6', m)] = {q: ID20[r] for q, r in H[('2020.6', m)].items()}
    # per-feature R1 label (default top hit in Full subset) under each release's own labels
    lab = pd.DataFrame({rel: pd.Series({q: LAB[rel].get(r, 'NA') for q, r in H[(rel, 'FullDatabase')].items()}) for rel in REL}).reindex([f for f, k in zip(feats, present) if k])
    lab['reads_s1'] = np.asarray(R.sum(1)).ravel()[present]; lab.to_csv(f'out/{ds}_feature_R1_label_by_release.csv')
    for a, b in itertools.combinations(REL, 2):
        ok = lab[a].notna() & lab[b].notna(); ch = ok & (lab[a] != lab[b])
        LROWS.append(dict(dataset=ds, release_a=a, release_b=b, features_matched_both=int(ok.sum()), label_changed=int(ch.sum()),
                          pct_label_changed=100 * ch.sum() / ok.sum(), reads_label_changed_pct=100 * lab.reads_s1[ch].sum() / lab.reads_s1[ok].sum(),
                          transitions='; '.join(f'{k[0]}->{k[1]}:{v}' for k, v in lab[ch].groupby([a, b]).size().items())))
    for (rel, m), h in H.items():
        t, p, r = outputs(R, feats, h, depth)
        S[f'{rel}|{m}|Total'] = t; S[f'{rel}|{m}|Proportion'] = p; S[f'{rel}|{m}|Richness'] = r
    df = pd.DataFrame(S, index=pd.Index(samples, name='SampleID')); df.insert(0, 'rarefying_depth', depth); all_df[ds] = df
    df.to_csv(f'out/{ds}_per_sample_by_release.csv')
    pres_f = [f for f, k in zip(feats, present) if k]
    for m in ['FullDatabase', 'Inhibitory', 'InhibitoryStrict', 'Facilitating']:
        rels = [r for r in REL if m in REL[r]]
        for a, b in itertools.combinations(rels, 2):
            ha, hb = H[(a, m)], H[(b, m)]
            gained = sum(1 for f in pres_f if f not in ha and f in hb); lost = sum(1 for f in pres_f if f in ha and f not in hb)
            both = [f for f in pres_f if f in ha and f in hb]; chg = sum(ha[f] != hb[f] for f in both)
            frows.append(dict(dataset=ds, subset=m, release_a=a, release_b=b, features_in_rarefied=len(pres_f),
                              matched_a=sum(f in ha for f in pres_f), matched_b=sum(f in hb for f in pres_f), gained_b=gained, lost_b=lost,
                              matched_both=len(both), ref_changed=chg, pct_status_change=100 * (gained + lost) / len(pres_f)))
            for met in ('Proportion', 'Richness'):
                x, y = df[f'{a}|{m}|{met}'], df[f'{b}|{m}|{met}']; d = (y - x).abs()
                rho = stats.spearmanr(x, y)[0] if x.nunique() > 1 and y.nunique() > 1 else np.nan
                rows.append(dict(dataset=ds, subset=m, metric=met, release_a=a, release_b=b, n_samples=len(x), spearman_rho=rho,
                                 median_a=x.median(), median_b=y.median(), median_abs_delta=d.median(), p95_abs_delta=d.quantile(0.95),
                                 max_abs_delta=d.max(), pct_shift_gt_0_05=100 * (d > 0.05).mean() if met == 'Proportion' else np.nan,
                                 pct_increase=100 * (y > x).mean(), pct_decrease=100 * (y < x).mean(),
                                 pct_quartile_change=100 * (quart(x) != quart(y)).mean()))
    # cross-subset: what a 2020.6 user would have had for 'inhibitory' (only InhibitoryStrict exists) vs current Inhibitory
    for a, ma, b, mb in [('2020.6', 'InhibitoryStrict', '2025.1', 'Inhibitory'), ('2020.6', 'InhibitoryStrict', '2023.2', 'Inhibitory')]:
        x, y = df[f'{a}|{ma}|Proportion'], df[f'{b}|{mb}|Proportion']; d = (y - x).abs()
        rows.append(dict(dataset=ds, subset=f'{ma}->{mb}', metric='Proportion', release_a=a, release_b=b, n_samples=len(x),
                         spearman_rho=stats.spearmanr(x, y)[0], median_a=x.median(), median_b=y.median(), median_abs_delta=d.median(),
                         p95_abs_delta=d.quantile(0.95), max_abs_delta=d.max(), pct_shift_gt_0_05=100 * (d > 0.05).mean(),
                         pct_increase=100 * (y > x).mean(), pct_decrease=100 * (y < x).mean(), pct_quartile_change=100 * (quart(x) != quart(y)).mean()))
cmp = pd.DataFrame(rows); cmp.to_csv('out/release_comparison_per_sample.csv', index=False)
pd.DataFrame(frows).to_csv('out/release_comparison_features.csv', index=False); pd.DataFrame(LROWS).to_csv('out/release_R1_label_changes.csv', index=False)
print(pd.DataFrame(LROWS).round(2).to_string())
# sanity vs round 1
r1 = pd.read_csv(R1, index_col=0); m = all_df['meta']
print('sanity 2025.1 Inhibitory == round1:', np.allclose(m.loc[r1.index, '2025.1|Inhibitory|Proportion'], r1['Inhibitory_Proportion']),
      np.allclose(m.loc[r1.index, '2025.1|FullDatabase|Proportion'], r1['Full_Proportion']))
# contrasts
mp = pd.read_csv(MAP, sep='\t', dtype=str).set_index('#SampleID'); df = m.join(mp[['lifestage', 'country', 'host_scientific_name']])
crow = []
for col, a, b in [('lifestage', 'adult', 'larvae'), ('country', 'madagascar', 'usa'), ('host_scientific_name', 'anaxyrus boreas', 'lithobates catesbeianus')]:
    for c in [c for c in m.columns if c.endswith('Proportion')]:
        x = df.loc[df[col] == a, c].dropna(); y = df.loc[df[col] == b, c].dropna(); U, p = stats.mannwhitneyu(x, y, alternative='two-sided')
        rel, sub, _ = c.split('|')
        crow.append(dict(contrast=f'{col}: {a} vs {b}', release=rel, subset=sub, n_a=len(x), n_b=len(y), median_a=x.median(), median_b=y.median(),
                         mean_a=x.mean(), mean_b=y.mean(), rank_biserial=2 * U / (len(x) * len(y)) - 1, p_MWU=p))
C = pd.DataFrame(crow); C['sig_0.05'] = C.p_MWU < 0.05; C.to_csv('out/release_contrasts.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
print(cmp[cmp.metric == 'Proportion'].drop(columns=['metric', 'max_abs_delta']).round(4).to_string())
print(cmp[cmp.metric == 'Richness'][['dataset', 'subset', 'release_a', 'release_b', 'spearman_rho', 'median_a', 'median_b', 'median_abs_delta', 'p95_abs_delta', 'pct_quartile_change']].round(3).to_string())
print(pd.DataFrame(frows).round(2).to_string())
print(C[['contrast', 'release', 'subset', 'n_a', 'n_b', 'median_a', 'median_b', 'rank_biserial', 'p_MWU']].to_string())
