"""Round 2, test 2 prep: identify isolates new in 2025.1 relative to 2020.6 and to 2023.2, cut 120-bp and full-V4 fragments
after 515F (round-1 rules), write query FASTAs, and tabulate relabelling of shared isolates.
Matching: 2020.6 entries -> 2025.1 via the 2025.1 column FastaID.2020 (7,382/7,382 matched, identical sequences, no duplicates);
2023.2 -> 2025.1 via identical FastaID (7,927/7,927, identical sequences)."""
import re, glob, collections, pandas as pd, numpy as np, os
from Bio import SeqIO
from Bio.Seq import Seq
os.makedirs('prosp', exist_ok=True)
FUNC = 'AntiFungal.Function.with.AP.function'; CL = ['Inhibitory', 'NoEffect', 'Facilitating']
F515 = re.compile('GTG[CT]CAGC[AC]GCCGCGGTAA'); R806 = re.compile('ATTAGA[AT]ACCC[CGT][ACGT]GTAGTCC')
def rd(f): return {r.id: str(r.seq).upper() for r in SeqIO.parse(f, 'fasta')}
def norm(x): return {'Pos.Contam': 'PossibleContamination', 'PosContam': 'PossibleContamination'}.get(x, x)
F20 = rd('reldb/2020.6_FullDatabase.fasta'); S20 = set(rd('reldb/2020.6_InhibitoryStrict.fasta'))
F23 = rd('reldb/2023.2_FullDatabase.fasta'); F25 = rd('reldb/2025.1_FullDatabase.fasta')
sub23 = {m: set(rd(f'reldb/2023.2_{m}.fasta')) for m in ['Inhibitory', 'InhibitoryStrict', 'Facilitating']}
sub25 = {m: set(rd(f'reldb/2025.1_{m}.fasta')) for m in ['Inhibitory', 'InhibitoryStrict', 'Facilitating']}
m5 = pd.read_csv('db/AmphibBac_Metadata_2025.1.tsv', sep='\t', dtype=str, encoding='latin1').set_index('FastaID')
m3 = pd.read_csv('rel/AmphibBac_Metadata_2023.2.txt', sep='\t', dtype=str, encoding='latin1').set_index('FastaID')
m5['Reference'] = m5.Reference.fillna('NA'); m5['Func'] = m5[FUNC].map(norm)
id20 = m5['FastaID.2020'].str.lstrip('>'); in20 = id20.isin(set(F20))
T = pd.DataFrame(index=m5.index)
T['Reference'] = m5.Reference; T['Database.Iteration'] = m5['Database.Iteration']; T['Func_2025'] = m5.Func
T['in_2020.6'] = in20; T['in_2023.2'] = T.index.isin(set(F23))
T['label_2020.6'] = pd.Series({i: norm(j.split('.')[-1]) for i, j in id20[in20].items()})
T['label_2023.2'] = m3[FUNC].map(norm).reindex(T.index).where(T['in_2023.2'])
T['label_2023.2'] = T['label_2023.2'].where(~(T['in_2023.2'] & T['label_2023.2'].isna()), 'NA_in_2023.2')
T['in_strict_2020.6'] = id20.isin(S20)
for m in sub25: T[f'in_{m}_2023.2'] = T.index.isin(sub23[m]); T[f'in_{m}_2025.1'] = T.index.isin(sub25[m])
# exact-sequence duplicates already present in the older release (either orientation)
def seqset(d): return set(d.values()) | {str(Seq(s).reverse_complement()) for s in d.values()}
s20, s23 = seqset(F20), seqset(F23)
T['seq_in_2020.6'] = [F25[i] in s20 for i in T.index]; T['seq_in_2023.2'] = [F25[i] in s23 for i in T.index]
refs20 = set(T.Reference[T['in_2020.6']]); refs23 = set(T.Reference[T['in_2023.2']])
T['new_vs_2020.6'] = ~T['in_2020.6']; T['new_vs_2023.2'] = ~T['in_2023.2']
T['new_study_vs_2020.6'] = T['new_vs_2020.6'] & ~T.Reference.isin(refs20)
T['new_study_vs_2023.2'] = T['new_vs_2023.2'] & ~T.Reference.isin(refs23)
# fragments
fr = {}
for fid, s in F25.items():
    for strand, seq in (('+', s), ('-', str(Seq(s).reverse_complement()))):
        m = F515.search(seq)
        if not m: continue
        st = m.end(); r = R806.search(seq, st)
        if len(seq) - st >= 120: fr[(fid, '120')] = seq[st:st+120]
        if r: fr[(fid, 'V4full')] = seq[st:r.start()]
        break
T['has_120'] = [(i, '120') in fr for i in T.index]; T['has_V4full'] = [(i, 'V4full') in fr for i in T.index]
T['iupac_120'] = [bool(re.search('[^ACGT]', fr.get((i, '120'), ''))) for i in T.index]
T['iupac_V4full'] = [bool(re.search('[^ACGT]', fr.get((i, 'V4full'), ''))) for i in T.index]
T.to_csv('prosp/isolate_release_table.csv')
for coh in ['2020.6', '2023.2']:
    for f in ['120', 'V4full']:
        q = T[T[f'new_vs_{coh}'] & T.Func_2025.isin(CL) & T[f'has_{f}']]
        with open(f'prosp/q_new{coh}_{f}.fasta', 'w') as h:
            for i in q.index: h.write(f'>{i}\n{fr[(i, f)]}\n')
        print(coh, f, 'queries', len(q), 'with IUPAC', int(q[f'iupac_{f}'].sum()))
for coh in ['2020.6', '2023.2']:
    n = T[f'new_vs_{coh}']; print(f'new vs {coh}: {n.sum()} isolates; tested (3 classes) {T.Func_2025[n].isin(CL).sum()};',
        'iteration', T.loc[n, 'Database.Iteration'].value_counts().to_dict(), '; from new studies', int(T[f'new_study_vs_{coh}'].sum()),
        '; studies', T.Reference[n].nunique(), 'new studies', T.Reference[T[f'new_study_vs_{coh}']].nunique(),
        '; exact seq already in older', int(T[f'seq_in_{coh}'][n].sum()))
    print(T[n].groupby(['Reference', f'new_study_vs_{coh}']).Func_2025.value_counts().unstack(fill_value=0).to_string())
