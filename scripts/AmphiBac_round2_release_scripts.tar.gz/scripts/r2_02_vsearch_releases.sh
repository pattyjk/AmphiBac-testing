#!/bin/bash
# Pipeline-equivalent q2-vsearch closed-reference call (id 0.99) against every subset of each release. 3 threads max.
set -e; cd "$(dirname "$0")/.."; mkdir -p work/ucrel
for ds in meta bf; do for db in reldb/*.fasta; do b=$(basename $db .fasta)
 vsearch --usearch_global work/${ds}_query.fasta --id 0.99 --db $db --uc work/ucrel/${ds}_${b}.uc --strand both --qmask none \
   --notmatched work/ucrel/${ds}_${b}_unmatched.fasta --threads 3 --minseqlength 1 --fasta_width 0 --quiet
done; done; echo DONE
