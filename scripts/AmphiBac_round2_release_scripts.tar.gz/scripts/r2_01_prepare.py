"""Real-data track step 1a: parse tables, rarefy, write query FASTAs.
Run from rd/ . Outputs to rd/work/."""
import numpy as np, pandas as pd, scipy.sparse as sp, os, re, sys
META_TAB = sys.argv[1]; BF_TAB = sys.argv[2]; BF_FA = sys.argv[3]
os.makedirs('work', exist_ok=True)

def rarefy(M, depth, seed):
    """M: csc features x samples (int). Subsample without replacement to depth (QIIME/biom semantics)."""
    rng = np.random.default_rng(seed); M = M.tocsc()
    rows, cols, vals = [], [], []
    for j in range(M.shape[1]):
        s, e = M.indptr[j], M.indptr[j+1]
        idx, c = M.indices[s:e], M.data[s:e].astype(np.int64)
        if c.sum() < depth: continue
        d = rng.multivariate_hypergeometric(c, depth)
        k = d > 0; rows.append(idx[k]); cols.append(np.full(k.sum(), j)); vals.append(d[k])
    return sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=M.shape)

# ---- meta-analysis table
with open(META_TAB) as f:
    samples = f.readline().rstrip('\n').split('\t')
    ns = len(samples); ids, r, c, v = [], [], [], []
    n_bad = n_num = 0
    for line in f:
        p = line.rstrip('\n').split('\t')
        if len(p) != ns + 1: n_bad += 1; continue
        if re.fullmatch(r'\d+', p[0]): n_num += 1; continue
        x = np.array(p[1:], dtype=float); nz = np.nonzero(x)[0]
        if len(nz) == 0: continue
        i = len(ids); ids.append(p[0]); r.extend([i]*len(nz)); c.extend(nz); v.extend(x[nz])
M = sp.csc_matrix((np.array(v).round().astype(np.int64), (r, c)), shape=(len(ids), ns))
depth = np.asarray(M.sum(0)).ravel(); keep = depth >= 1000
print(f'meta: header samples {ns}; malformed rows skipped {n_bad}; numeric-ID rows skipped {n_num}; nonzero sOTUs {len(ids)}; samples>=1000 {keep.sum()}')
M = M[:, keep]; samples = [s for s, k in zip(samples, keep) if k]
assert all(set(s) <= set('ACGT') for s in ids[:50])
lens = pd.Series([len(s) for s in ids]).value_counts(); print('meta seq lengths', lens.head(3).to_dict(), 'non-ACGT', sum(1 for s in ids if set(s)-set('ACGT')))
fid = [f'm{i}' for i in range(len(ids))]
for seed in (1, 2):
    R = rarefy(M, 1000, seed); sp.save_npz(f'work/meta_rare_s{seed}.npz', R)
    print('seed', seed, 'samples rarefied', (np.asarray(R.sum(0)).ravel() == 1000).sum(), 'features retained', (np.asarray(R.sum(1)).ravel() > 0).sum())
sp.save_npz('work/meta_raw.npz', M)
pd.DataFrame({'fid': fid, 'seq': ids, 'raw_total': np.asarray(M.sum(1)).ravel()}).to_csv('work/meta_features.csv', index=False)
pd.Series(samples).to_csv('work/meta_samples.csv', index=False, header=False)
tot = np.asarray(M.sum(1)).ravel()
with open('work/meta_query.fasta', 'w') as f:
    for i in np.argsort(-tot, kind='stable'):
        if tot[i] > 0: f.write(f'>{fid[i]};size={tot[i]}\n{ids[i]}\n')

# ---- bullfrog
bf = pd.read_csv(BF_TAB, sep='\t', comment=None, skiprows=1 if open(BF_TAB).readline().startswith('# Constructed') else 0, index_col=0)
seqs = {}; k = None
for line in open(BF_FA):
    line = line.strip()
    if line.startswith('>'): k = line[1:].split()[0]; seqs[k] = ''
    else: seqs[k] += line
print('bullfrog table', bf.shape, 'fasta', len(seqs), 'IDs in table & fasta', len(set(bf.index) & set(seqs)), 'table-only', len(set(bf.index) - set(seqs)))
d = bf.sum(0).sort_values(); print('bullfrog lowest depths', d.head(8).to_dict())
bf.to_csv('work/bf_raw.csv')
with open('work/bf_query.fasta', 'w') as f:
    tot = bf.sum(1).sort_values(ascending=False)
    for k_, t in tot.items():
        if t > 0: f.write(f'>{k_};size={int(t)}\n{seqs[k_]}\n')
print('bf seq lengths', pd.Series([len(seqs[x]) for x in bf.index]).value_counts().head(3).to_dict())
