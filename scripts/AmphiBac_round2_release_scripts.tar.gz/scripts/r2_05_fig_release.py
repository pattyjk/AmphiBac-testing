"""Figure for test 1 (release stability). Exec'd in a kernel with figure-style helpers (apply_figure_style, panel_letter)."""
import pandas as pd, numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
apply_figure_style(sizes=(8,7,6))
df=pd.read_csv('out/meta_per_sample_by_release.csv',index_col=0)
cmp=pd.read_csv('out/release_comparison_per_sample.csv',dtype={'release_a':str,'release_b':str}); C=pd.read_csv('out/release_contrasts.csv',dtype={'release':str})
fig,axs=plt.subplots(1,3,figsize=(7.4,2.8),gridspec_kw=dict(width_ratios=[1,1.05,1.25],wspace=0.75))
ax=axs[0]; x=df['2020.6|InhibitoryStrict|Proportion']; y=df['2025.1|InhibitoryStrict|Proportion']
ax.scatter(x,y,s=3,alpha=0.35,color='#2166AC',lw=0,rasterized=True); ax.plot([0,1],[0,1],color='0.5',lw=0.7,ls='--')
ax.set_xlabel('2020.6 InhibitoryStrict proportion'); ax.set_ylabel('2025.1 InhibitoryStrict proportion')
r=cmp.query("dataset=='meta' and subset=='InhibitoryStrict' and release_a=='2020.6' and release_b=='2025.1' and metric=='Proportion'").iloc[0]
ax.text(0.03,0.97,f"ρ = {r.spearman_rho:.2f}\n{r.pct_shift_gt_0_05:.0f}% shift >0.05",transform=ax.transAxes,va='top',fontsize=7)
ax.set_title('Same samples, two releases',loc='left'); ax.margins(0.03)
ax=axs[1]
sel=cmp[(cmp.metric=='Proportion')&(cmp.dataset=='meta')].copy()
ab={'FullDatabase':'Full','InhibitoryStrict':'Strict','Inhibitory':'Inhib.','Facilitating':'Facil.','InhibitoryStrict->Inhibitory':'Strict→Inhib.'}
sel['lab']=sel.subset.map(ab)+' '+sel.release_a.str[2:]+'→'+sel.release_b.str[2:]
sel=sel.iloc[::-1]; yy=np.arange(len(sel))
ax.barh(yy-0.2,sel.pct_shift_gt_0_05,height=0.38,color='#2166AC',label='|Δ| > 0.05')
ax.barh(yy+0.2,sel.pct_quartile_change,height=0.38,color='0.65',label='quartile changed')
ax.set_yticks(yy); ax.set_yticklabels(sel.lab); ax.set_xlabel('% of samples (n = 2,411)')
ax.legend(frameon=False,loc='upper right',fontsize=6); ax.set_title('Per-sample shifts',loc='left')
ax=axs[2]
cons=['lifestage: adult vs larvae','country: madagascar vs usa','host_scientific_name: anaxyrus boreas vs lithobates catesbeianus']
names=['Adult vs larva','Madagascar vs USA','A. boreas vs\nL. catesbeianus']
combos=[('2020.6','InhibitoryStrict'),('2023.2','InhibitoryStrict'),('2025.1','InhibitoryStrict'),('2023.2','Inhibitory'),('2025.1','Inhibitory')]
cols={'2020.6':'#9ecae1','2023.2':'#4292c6','2025.1':'#08306b'}
for i,c in enumerate(cons):
    for j,(rel,sub) in enumerate(combos):
        q=C[(C.contrast==c)&(C.release==rel)&(C.subset==sub)].iloc[0]
        ax.scatter(q.rank_biserial,i+(j-2)*0.13,marker='o' if sub=='InhibitoryStrict' else 's',color=cols[rel],s=18,
                   edgecolor='k' if q.p_MWU<0.05 else 'none',lw=0.7,zorder=3)
ax.axvline(0,color='0.5',lw=0.7); ax.set_yticks(range(3)); ax.set_yticklabels(names); ax.invert_yaxis()
ax.set_xlabel('Rank-biserial r'); ax.set_title('Host contrast flips with 2020.6',loc='left'); ax.set_xlim(-0.45,0.85)
h=[Line2D([],[],marker='o',ls='',color=cols[k],label=k) for k in cols]+[Line2D([],[],marker='o',ls='',color='w',mec='0.3',label='Strict subset'),
   Line2D([],[],marker='s',ls='',color='w',mec='0.3',label='Inhibitory subset'),Line2D([],[],marker='o',ls='',color='0.8',mec='k',label='p < 0.05')]
ax.legend(handles=h,frameon=False,fontsize=6,loc='upper left',bbox_to_anchor=(0.0,1.0))
for a,l in zip(axs,'abc'): panel_letter(a,l)
fig.savefig('fig_r2_release_stability.png',dpi=300,bbox_inches='tight')
r_=fig.canvas.get_renderer(); T=[t for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
bb=[t.get_window_extent(r_) for t in T]; print('overlaps',[(T[i].get_text()[:20],T[j].get_text()[:20]) for i in range(len(T)) for j in range(i+1,len(T)) if bb[i].overlaps(bb[j])])
