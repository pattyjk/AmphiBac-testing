"""Round 2, test 2b: did the function label of the SAME isolate change between releases? Also subset-membership changes."""
import pandas as pd, numpy as np
T = pd.read_csv('prosp/isolate_release_table.csv', index_col=0); rows = []; xt = []
for old, col, inc in [('2020.6', 'label_2020.6', 'in_2020.6'), ('2023.2', 'label_2023.2', 'in_2023.2')]:
    D = T[T[inc]]; ct = pd.crosstab(D[col], D.Func_2025); ct.index.name = f'{old} label'; ct.columns.name = '2025.1 Func'
    xt.append((old, ct)); ch = D[col] != D.Func_2025
    rows.append(dict(older_release=old, comparison='label (Func)', n_shared=len(D), n_changed=int(ch.sum()), pct_changed=100 * ch.mean(),
                     n_changed_into_or_out_of_Inhibitory=int(((D[col] == 'Inhibitory') != (D.Func_2025 == 'Inhibitory')).sum()),
                     studies_with_changes=D.Reference[ch].nunique(), detail='; '.join(f'{a}->{b}:{n}' for (a, b), n in D[ch].groupby([col, 'Func_2025']).size().items())))
D = T[T['in_2020.6']]
for old_col, new_col, nm in [('in_strict_2020.6', 'in_InhibitoryStrict_2025.1', 'InhibitoryStrict membership 2020.6->2025.1'),
                             ('in_strict_2020.6', 'in_InhibitoryStrict_2023.2', 'InhibitoryStrict membership 2020.6->2023.2')]:
    a, b = D[old_col], D[new_col]
    rows.append(dict(older_release='2020.6', comparison=nm, n_shared=len(D), n_changed=int((a != b).sum()), pct_changed=100 * (a != b).mean(),
                     detail=f'added {int((~a & b).sum())}; removed {int((a & ~b).sum())}; 2020.6-Inhibitory-labelled but not in 2020.6 strict: {int(((D["label_2020.6"]=="Inhibitory") & ~a).sum())}'))
D = T[T['in_2023.2']]
for m in ['Inhibitory', 'InhibitoryStrict', 'Facilitating']:
    a, b = D[f'in_{m}_2023.2'], D[f'in_{m}_2025.1']
    rows.append(dict(older_release='2023.2', comparison=f'{m} membership 2023.2->2025.1', n_shared=len(D), n_changed=int((a != b).sum()),
                     pct_changed=100 * (a != b).mean(), detail=f'added {int((~a & b).sum())}; removed {int((a & ~b).sum())}'))
R = pd.DataFrame(rows); R.to_csv('prosp/relabelling_summary.csv', index=False)
with pd.ExcelWriter('prosp/relabelling_crosstabs.xlsx') as w:
    for old, ct in xt: ct.to_excel(w, sheet_name=f'{old}_vs_2025.1')
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 200); print(R.to_string())
for old, ct in xt: print(ct)
