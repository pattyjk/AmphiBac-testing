#!/bin/bash
# Predict new isolates from the OLDER release: pipeline-default call per subset (id 0.99) + exhaustive Full search for R4. 3 threads.
set -e; cd "$(dirname "$0")/.."; mkdir -p prosp/uc
F="query+target+id+mism+gaps+alnlen+ids+ql+tl+qilo+qihi"
for coh in 2020.6 2023.2; do for fr in 120 V4full; do q=prosp/q_new${coh}_${fr}.fasta
  for db in reldb/${coh}_*.fasta; do b=$(basename $db .fasta)
    vsearch --usearch_global $q --id 0.99 --db $db --uc prosp/uc/${coh}_${fr}_${b#${coh}_}.uc --strand both --qmask none \
      --notmatched /dev/null --threads 3 --minseqlength 1 --fasta_width 0 --quiet
  done
  vsearch --usearch_global $q --id 0.99 --db reldb/${coh}_FullDatabase.fasta --userout prosp/uc/${coh}_${fr}_exh.tsv --userfields $F \
    --strand both --qmask none --maxaccepts 0 --maxrejects 0 --threads 3 --minseqlength 1 --quiet
done; done; echo DONE
