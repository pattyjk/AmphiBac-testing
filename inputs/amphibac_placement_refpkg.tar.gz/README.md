# AmphiBac 2025.1 reference package for phylogenetic placement (EPA-ng)

## Contents
- ref/ref_msa.fasta — 7,279 tested isolates (Func in Inhibitory/NoEffect/Facilitating), E. coli/sense orientation,
  aligned with Infernal cmalign to Rfam RF00177 (SSU_rRNA_bacteria, CLEN 1533) with `--matchonly` -> 1,533 columns (U->T, '.'->'-').
- ref/RF00177.cm — the covariance model; queries aligned to it with the same command give the same 1,533-column frame.
- ref/fasttree.nwk (FastTreeMP -nt -gtr -gamma), ref/fasttree_binary.nwk (polytomies randomly resolved, 1e-6 branches),
  ref/ref_tree.nwk (= raxml-ng --evaluate GTR+G on that topology; branch lengths + model re-optimised), ref/ref_model.txt (= rax.raxml.bestModel).
- ref/tip_table.csv — all 7,873 tested isolates with in_tree flag/drop_reason, Func, score, Reference, Bd.Genotype, Assay.Method,
  Assay.Temperature.Bd, phylum/family/genus (RDP v18 SINTAX full-length), seq_length, ecoli_start/end (vsearch vs J01859), cm_from/cm_to,
  cm_bits(_per_nt), has_V4_254, has_V3V4_429, panel_all10.
- scripts/placement_lib.py — align_queries (cmalign), run_epa (epa-ng), parse_jplace (+NSTI), prune_reference, edge_tipsets.
- scripts/validate_placement.py — the validation run.  val/ — validation outputs.

## Filters (from 7,873 tested isolates)
len<300 bp: 233; >1% IUPAC: 160; E. coli identity <70% (vsearch): 190; no E. coli hit: 6; cmalign bits/nt <0.5 or <90% residues in match columns: 5. Kept 7,279.
Untested isolates were NOT added as scaffolds (tips = labelled set only, so HSP needs no missing-state handling).

## Commands
```
cmalign --cpu 10 --noprob --matchonly --outformat Pfam -o q.pfam --sfile q.sc ref/RF00177.cm queries.fasta   # (AFA output refused for >10k residues)
esl-reformat afa q.pfam > q.afa      # then U->T, '.'->'-'  (done in placement_lib.align_queries)
epa-ng --redo --tree ref/ref_tree.nwk --ref-msa ref/ref_msa.fasta --query q.afa --model ref/ref_model.txt --threads 10 --outdir out/
```
Notes: pass the raxml-ng bestModel FILE to --model (the string with FU/G4m and ", noname = 1-1533" fails to parse in EPA-ng 0.3.8).
raxml-ng rejects FastTree's multifurcating output (117 polytomies from identical sequences); resolve first.
jplace distal_length is measured from the child (distal) node (checked: own-tip placements have distal/edge ~0.003).
NSTI-like distance = pendant_length + min(distal + nearest tip below child, (edge - distal) + nearest tip via parent).
Queries are expected in E. coli (sense) orientation; align_queries(orient=True) aligns both strands and keeps the higher bit score.
LOSO: prune_reference() drops tips from tree+MSA (dendropy, unifurcations suppressed, basal trifurcation restored); the model
file from the full tree is reused (no re-optimisation; minor leakage of rate parameters only).
