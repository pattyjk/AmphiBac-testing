PAIRED-STUDY TEST OF THE AMPHIBAC 2025.1 PIPELINE: does the pipeline's call for an ASV match the study's OWN isolate of that ASV?
Studies: walke2015 (= walke2015/2017, one study), rebollar2019, bletz2018, molecol2019 (Ellison et al. 2019).

STEP 1 - UNIFORM ASVs (vsearch 2.32.0)
All studies use the same 150-nt V4 window that starts at the first base after the 515F primer (the AmphiBac/V4-R1 convention).
- V4 R1 data (walke2015, rebollar2019, bletz2018): primers absent from reads. --fastq_filter --fastq_trunclen 150 --fastq_maxee 1 --fastq_maxns 0 (--fastq_qmax 45).
- molecol2019 (no qualities, V3-V4 341F/805R): ONLY merged ~465-nt reads (length >= 400) were used. Each read is oriented so 515F reads forward, the exact 515F site
  (GTGCCAGCMGCCGCGGTAA) is located, and the next 150 nt are kept (no N allowed). The 300-nt reverse reads (~72% of the file) were DROPPED. Their V4 start lies in the
  error-prone 3' tail, only 6.6% (in a 200k-read check) retain an intact 515F site, and without qualities these errors cannot be filtered. The isolate Sanger
  sequences span roughly E. coli 360-750, so a window anchored at the 805R end would not be covered by most isolates. No maxee filter is possible.
- Per-sample dereplication -> pooled dereplication -> --cluster_unoise --minsize 8 -> --uchime3_denovo -> ASVs relabelled <study>_ASVn ->
  map per-sample uniques back with --usearch_global --id 0.97 --strand plus --sizein --otutabout.
- walke2015: POOLED (one column 'pool'). SRR2162774 carries no sample IDs or barcodes. The user-supplied Walke2015_BullfrogExptBFE_mapping_file.xlsx
  was checked: its 8-nt barcodes occur at read starts in 26/200,000 reads (below chance) and anywhere in reads at chance frequency. The sequencing reads
  begin at the V4 base after 515F (barcodes were on the index read and are not in the SRA file). Note that the mapping file describes the BFE bullfrog
  Bd/antibiotic experiment (153 samples, timepoints day0..., Study=BFE), not the 64-animal field survey. Walke stays pooled; no per-sample metrics.
- rebollar2019: demultiplexed with the 8-nt index read SRR8570212 (no public mapping file). Barcodes were tabulated over spots whose 8 index bases are all
  Q>=30 (9,109,123 of 15,789,745 spots; 5,607 unique barcodes). Kept barcodes = those above the largest log10 abundance drop in the ranked counts: 61
  barcodes, break between 20,760 (rank 61) and 4,474 (rank 62) reads. Only exact matches are assigned. 1-mismatch variants of a kept barcode were NOT
  merged and NOT kept separately (those spots stay unassigned). Minimum pairwise Hamming distance among kept barcodes = 2. 8,908,591 spots (56.4%) were
  assigned. Samples are named R01..R61 by descending read count (sheet rebollar_barcodes). Only R1 was used for ASVs, and R2 was not demultiplexed to files
  (it is not used in the uniform V4-R1 pipeline). The groups have NO host labels and MAY INCLUDE NON-STUDY SAMPLES: the SRA design text mentions
  C. fitzingeri from four sites, and 61 groups exceed the paper's 44 frogs.

STEP 2 - OWN-ISOLATE TRUTH
vsearch --usearch_global ASVs vs the study's own scored isolates: --id 1.0 --query_cov 1.0 --maxaccepts 0 --maxrejects 0 --strand both --qmask none, then filtered
to 0 mismatches, 0 gap openings and 100% query coverage (the whole ASV is covered by the isolate at 100%).
Isolate label from score: Inhibitory if score > 80, Facilitating if <= -20, else NoEffect (AmphiBac convention). Per ASV: n isolates, share Inhibitory,
mean score, majority label (Inhibitory if share Inhibitory > 0.5; ties at 0.5 -> NoEffect, flagged in own_label_tie), and conflict rate
(1 - share of the most common 3-class label).
- walke2015: score = (1 - PG_Bd)*100 from AmphiBac (Walke 2017 values; walke2017 table identical to walke2015). 17 NotTested excluded.
- rebollar2019: AmphiBac scores; 4 PossibleContamination isolates excluded (as in the AmphiBac subsets); NotTested excluded.
- bletz2018: Dryad Bd proportional growth, score = (1 - PG_Bd)*100, 14 retested isolates averaged. Bsal handled the same way in separate columns.
  Only 3 of 694 isolates have Bd score > 80 (Dryad FDR status: 15 assay rows 'Inhibitory'), and NO own-matched ASV is Bd-Inhibitory. The Bd kappa for
  bletz2018 is therefore 0 by construction (prevalence 0), not a measured disagreement. The Bsal comparison is the informative one.
- molecol2019: scores DERIVED from raw OD time courses (provisional; no published per-isolate scores). 43 isolates with sequence; only 13 ASVs matched.

STEP 3 - PIPELINE CALLS (AmphiBac 2025.1, label column AntiFungal.Function.with.AP.function)
Study held out: remove FastaIDs whose Reference matches the study DOI, plus FastaIDs listed in the study's isolate_assays, plus Isolate.ID matches,
plus GenBank accession matches. Removed: walke2015 736, rebollar2019 384, bletz2018 694, molecol2019 0 (not in AmphiBac, so 'held out' = 'included').
No ID matched an isolate from another Reference.
q2-vsearch closed-reference emulation: --usearch_global --id 0.99 --strand both --qmask none --minseqlength 1, default maxaccepts 1 / maxrejects 32.
(a) subset_heldout: any hit in the held-out Inhibitory subset -> Inhibitory. (b) tophit_heldout: label of the default top hit in the held-out
FullDatabase (NotTested/PossibleContamination/NoEffect/Facilitating = not Inhibitory). (c) exhaustive_majority: all >=99% hits with 100% query
coverage (--maxaccepts 0 --maxrejects 0), Inhibitory if > 50% of labelled hits (Inhibitory/NoEffect/Facilitating) are Inhibitory.
(d) genus_majority: no RDP training set was available offline, so the genus is that of the best held-out AmphiBac hit at >= 97% (default
heuristics), using genus_assignments.csv (genus_full). The genus call is Inhibitory if > 50% of labelled held-out AmphiBac isolates of that genus are
Inhibitory. (e) subset_included and tophit_included: the same rules with the study's own isolates in the database (as people actually run it).

STEP 4 - AGREEMENT
Unit = ASV. Binary: own majority Inhibitory vs not; pipeline Inhibitory vs not. The evaluable set = ASVs with an own label AND a pipeline call. For the
subset/top-hit rules that means a >=99% hit in the corresponding FullDatabase; 'subset_heldout_allASVs' also counts no-hit ASVs as 'not Inhibitory',
as the pipeline does. Cohen's kappa, sensitivity, specificity, PPV, own prevalence, and read-weighted agreement (reads of agreeing ASVs / reads of
evaluated ASVs). 95% CI: 2,000 bootstrap resamples of ASVs (stratified by study when pooled). Pooled Bd includes bletz2018 Bd ASVs (all own-negative).
Per sample (rebollar2019, bletz2018, molecol2019; samples with >= 100 own-matched reads): pipeline Inhibitory proportion = reads of subset-Inhibitory ASVs /
all reads; own-isolate Inhibitory proportion = reads of own-majority-Inhibitory ASVs / reads of own-matched ASVs; own mean score weighted by reads.
Spearman correlations. Coverage = share of reads in own-matched ASVs vs in ASVs with a >=99% AmphiBac hit.
Bd (molecol2019): frogs only (adult/juvenile/tadpole; water/controls excluded), Bd status known, >= 100 own-matched reads (n=87, 56 positive).
Logistic regression on Bd status and OLS on log10 ZE among infected (n=56), each metric z-scored, unadjusted and + site + life stage; plus Spearman.
bletz2018 Exp1: Mann-Whitney exposed vs control after exposure, and on the after-minus-before change (individual = digits of sample_id; 6 + 6).

DEVIATIONS / LIMITATIONS
1. walke2015 analysed as one pooled sample (no barcodes/sample IDs in the public reads); no per-sample metrics.
2. rebollar2019: reads demultiplexed by index only (no mapping file); 43.6% of spots unassigned (low-quality index or non-kept barcode); no host labels; R1
   only, R2 unused and not demultiplexed to files.
3. molecol2019: merged reads only (reverse reads dropped, see step 1); no quality filtering possible; isolate scores provisional (OD-derived); n = 13 ASVs.
4. bletz2018 Bd: no own-Inhibitory ASVs, so Bd agreement is uninformative; Bsal reported instead (3 own-Inhibitory ASVs).
5. Genus baseline uses the AmphiBac best hit at >= 97% rather than SINTAX/RDP (no RDP training set available offline).
6. Bd tests in walke2015 and rebollar2019 were not assessed (no per-individual Bd data).
7. ASVs are not independent (several ASVs can match the same isolate), so bootstrap CIs over ASVs are approximate.
